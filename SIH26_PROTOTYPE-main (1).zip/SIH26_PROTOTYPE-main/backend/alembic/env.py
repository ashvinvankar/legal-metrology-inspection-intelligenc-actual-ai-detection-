"""Alembic migration environment for SLM-CIP.

Configured to:
- Read DATABASE_URL_SYNC from the application settings (environment variable).
- Import all SQLAlchemy models so autogenerate can detect schema changes.
- Support both SQLite (local dev) and PostgreSQL (production/Docker).
"""

import os
from logging.config import fileConfig

from sqlalchemy import engine_from_config, pool
from alembic import context

# ─── Alembic Config ───────────────────────────────────────────────────────────
config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# ─── Override sqlalchemy.url from environment (takes precedence over alembic.ini) ──
from app.core.config import settings  # noqa: E402

# Prefer an explicit Alembic/test URL, then environment, then application
# settings. This avoids migration tests silently using a developer database.
configured_url = config.get_main_option("sqlalchemy.url")
database_url = os.getenv("DATABASE_URL_SYNC") or (
    configured_url if configured_url and not configured_url.startswith("driver://") else settings.DATABASE_URL_SYNC
)
config.set_main_option("sqlalchemy.url", database_url)

# ─── Import all models so autogenerate can detect table definitions ───────────
from app.core.database import Base  # noqa: E402
import app.models.user          # noqa: F401, E402
import app.models.inspection    # noqa: F401, E402
import app.models.vision        # noqa: F401, E402
import app.models.compliance    # noqa: F401, E402
import app.models.rule          # noqa: F401, E402
import app.models.audit         # noqa: F401, E402
import app.models.product       # noqa: F401, E402
import app.models.report        # noqa: F401, E402

target_metadata = Base.metadata


# ─── Migration runners ────────────────────────────────────────────────────────

def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode (no DB connection required)."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode (active DB connection)."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
