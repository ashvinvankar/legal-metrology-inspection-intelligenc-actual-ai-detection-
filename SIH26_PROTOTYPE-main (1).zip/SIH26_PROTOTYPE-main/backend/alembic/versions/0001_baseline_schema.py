"""Create the complete SLM-CIP baseline schema.

Revision ID: 0001_baseline_schema
Revises: None
"""

from typing import Sequence, Union

from alembic import op

# Import every model before reading metadata. This intentional baseline approach
# keeps the schema portable across SQLite test databases and PostgreSQL.
import app.models  # noqa: F401
from app.core.database import Base


revision: str = "0001_baseline_schema"
down_revision: Union[str, Sequence[str], None] = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    Base.metadata.create_all(bind=op.get_bind(), checkfirst=True)


def downgrade() -> None:
    Base.metadata.drop_all(bind=op.get_bind(), checkfirst=True)
