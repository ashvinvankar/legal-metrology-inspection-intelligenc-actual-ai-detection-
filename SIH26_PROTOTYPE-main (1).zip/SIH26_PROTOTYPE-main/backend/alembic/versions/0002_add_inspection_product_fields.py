"""Add product_name and category to inspections table.

Revision ID: 0002_add_inspection_product_fields
Revises: 0001_baseline_schema
"""

from typing import Sequence, Union
from alembic import op
import sqlalchemy as sa


revision: str = "0002_add_inspection_product_fields"
down_revision: Union[str, Sequence[str], None] = "0001_baseline_schema"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("inspections") as batch_op:
        batch_op.add_column(sa.Column("product_name", sa.String(255), nullable=True))
        batch_op.add_column(sa.Column("category", sa.String(100), server_default="Packaged Food", nullable=False))


def downgrade() -> None:
    with op.batch_alter_table("inspections") as batch_op:
        batch_op.drop_column("category")
        batch_op.drop_column("product_name")
