"""Smart Legal Metrology Compliance Inspection Platform (SLM-CIP) Backend Package."""

__version__ = "1.0.0"
