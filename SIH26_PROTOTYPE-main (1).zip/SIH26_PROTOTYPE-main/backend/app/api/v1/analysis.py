import logging
from typing import List
from uuid import UUID, uuid4

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_role
from app.models.inspection import Inspection, InspectionAnalysisTask
from app.schemas.inspection import AnalysisStatusResponse
from app.schemas.vision import (
    DetectedRegionDTO,
    EvidenceDetailResponse,
    OCRResultDTO,
    RegionEvidenceItem,
)
from app.workers.pipeline_tasks import run_inspection_pipeline

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/inspections/{id}", tags=["Analysis"])


async def _get_authorized_inspection(db: AsyncSession, inspection_id: UUID, current_user: dict) -> Inspection:
    inspection = (await db.execute(select(Inspection).where(Inspection.id == inspection_id))).scalar_one_or_none()
    if not inspection:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Inspection not found")
    if current_user.get("role") == "Officer" and str(inspection.officer_id) != current_user["id"]:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied to this inspection")
    return inspection


def _as_response(task: InspectionAnalysisTask) -> AnalysisStatusResponse:
    return AnalysisStatusResponse(
        inspection_id=task.inspection_id,
        task_id=task.celery_task_id,
        status=task.status,
        stage=task.stage,
        progress_percent=task.progress_percent,
        attempt=task.attempt,
        error_message=task.error_message,
        completed=task.status == "completed",
    )


@router.post("/analyze", status_code=status.HTTP_202_ACCEPTED)
async def trigger_analysis(
    id: UUID,
    background_tasks: BackgroundTasks,
    current_user: dict = Depends(require_role(["Officer", "Reviewer"])),
    db: AsyncSession = Depends(get_db),
):
    """Persist a queued job and run via Celery, falling back to local background execution if Celery broker is offline."""
    await _get_authorized_inspection(db, id, current_user)
    task_id = str(uuid4())
    task = InspectionAnalysisTask(id=uuid4(), inspection_id=id, celery_task_id=task_id, status="queued", stage="QUEUED")
    db.add(task)
    await db.commit()  # Must be durable before worker can process the supplied id.

    queued_via_celery = False
    try:
        run_inspection_pipeline.apply_async(args=[str(id), task_id], task_id=task_id)
        queued_via_celery = True
    except Exception as exc:
        logger.warning(
            "Celery broker/Redis is offline (%s). Executing inspection pipeline in background task fallback.",
            exc,
        )
        task.status = "running"
        task.stage = "PREPROCESSING"
        await db.commit()
        background_tasks.add_task(run_inspection_pipeline.run, str(id), task_id)

    return {
        "inspection_id": str(id),
        "task_id": task_id,
        "status": "QUEUED" if queued_via_celery else "RUNNING",
        "executor": "celery" if queued_via_celery else "background_fallback",
    }


@router.post("/re-analyze", status_code=status.HTTP_202_ACCEPTED)
async def re_trigger_analysis(
    id: UUID,
    background_tasks: BackgroundTasks,
    current_user: dict = Depends(require_role(["Officer", "Reviewer", "SysAdmin"])),
    db: AsyncSession = Depends(get_db),
):
    """
    Re-queue a fresh pipeline run for an already-processed inspection.

    Resets the inspection status to 'pending' so the pipeline is allowed to
    overwrite existing compliance/OCR data.
    """
    inspection = await _get_authorized_inspection(db, id, current_user)

    # Check if there's an active, unfinished task before rejecting
    active_task = (await db.execute(
        select(InspectionAnalysisTask)
        .where(
            InspectionAnalysisTask.inspection_id == id,
            InspectionAnalysisTask.status.in_(["queued", "running"]),
        )
        .order_by(InspectionAnalysisTask.created_at.desc())
        .limit(1)
    )).scalar_one_or_none()

    if active_task and inspection.status in ("analyzing", "queued"):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Inspection is already being analyzed. Wait for the active task to complete before re-analyzing.",
        )

    # Reset inspection to pending so the pipeline cleanup guard doesn't skip it
    inspection.status = "pending"
    inspection.overall_result = None

    task_id = str(uuid4())
    task = InspectionAnalysisTask(id=uuid4(), inspection_id=id, celery_task_id=task_id, status="queued", stage="QUEUED")
    db.add(task)
    await db.commit()

    queued_via_celery = False
    try:
        run_inspection_pipeline.apply_async(args=[str(id), task_id], task_id=task_id)
        queued_via_celery = True
    except Exception as exc:
        logger.warning(
            "Celery broker/Redis is offline (%s). Executing inspection pipeline in background task fallback for re-analysis.",
            exc,
        )
        task.status = "running"
        task.stage = "PREPROCESSING"
        await db.commit()
        background_tasks.add_task(run_inspection_pipeline.run, str(id), task_id)

    return {
        "inspection_id": str(id),
        "task_id": task_id,
        "status": "QUEUED" if queued_via_celery else "RUNNING",
        "re_analysis": True,
        "executor": "celery" if queued_via_celery else "background_fallback",
    }


@router.get("/analysis", response_model=AnalysisStatusResponse)
async def get_analysis_status(
    id: UUID,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Return the latest persisted state for an authorized inspection."""
    await _get_authorized_inspection(db, id, current_user)
    task = (await db.execute(
        select(InspectionAnalysisTask)
        .where(InspectionAnalysisTask.inspection_id == id)
        .order_by(InspectionAnalysisTask.created_at.desc())
        .limit(1)
    )).scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No analysis task found for inspection")
    return _as_response(task)


@router.get("/evidence", response_model=List[EvidenceDetailResponse])
async def get_inspection_evidence(
    id: UUID,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Retrieve all visual evidence for an inspection: images, detected bounding boxes,
    and associated OCR spans (PRD Section 12 & Screen 7).
    """
    await _get_authorized_inspection(db, id, current_user)
    from app.models.inspection import ProductImage
    from app.models.vision import DetectedRegion, OCRResult
    from app.services.image_service import ImageService
    from app.services.storage_service import StorageService

    images = list(
        (await db.execute(select(ProductImage).where(ProductImage.inspection_id == id))).scalars().all()
    )

    evidence_list: List[EvidenceDetailResponse] = []
    storage = StorageService()

    for img in images:
        browser_img_url = await ImageService.get_browser_uri(img.original_uri)
        regions = list(
            (await db.execute(select(DetectedRegion).where(DetectedRegion.image_id == img.id))).scalars().all()
        )

        region_items: List[RegionEvidenceItem] = []
        for reg in regions:
            ocr_spans = list(
                (await db.execute(select(OCRResult).where(OCRResult.region_id == reg.id))).scalars().all()
            )
            crop_uri = f"/storage/crops/crop_{reg.id}.jpg"
            region_items.append(
                RegionEvidenceItem(
                    region=DetectedRegionDTO.model_validate(reg),
                    ocr_spans=[OCRResultDTO.model_validate(span) for span in ocr_spans],
                    crop_uri=crop_uri,
                )
            )

        evidence_list.append(
            EvidenceDetailResponse(
                inspection_id=id,
                image_id=img.id,
                image_uri=browser_img_url,
                image_type=img.image_type,
                quality_score=img.quality_score,
                regions=region_items,
            )
        )

    return evidence_list


@router.post("/ai-inspect", status_code=status.HTTP_200_OK)
async def run_fast_ai_inspection(
    id: UUID,
    current_user: dict = Depends(require_role(["Officer", "Reviewer"])),
    db: AsyncSession = Depends(get_db),
):
    """
    Direct synchronous AI CV/OCR pipeline run.
    Uses Gemini 3.8 Flash Multimodal Vision (when API key present) + local CV/OCR fallback
    to extract all declarations and evaluate compliance rules immediately.
    """
    import asyncio
    from datetime import datetime
    from app.workers.pipeline_tasks import run_inspection_pipeline

    inspection = await _get_authorized_inspection(db, id, current_user)
    task_id = str(uuid4())

    # Create task record
    task = InspectionAnalysisTask(
        id=uuid4(),
        inspection_id=id,
        celery_task_id=task_id,
        status="running",
        stage="PREPROCESSING",
        progress_percent=10,
        started_at=datetime.utcnow(),
    )
    db.add(task)
    await db.commit()

    # Run the full pipeline in worker thread synchronously
    result = await asyncio.to_thread(run_inspection_pipeline, str(id), task_id)

    # Refresh task
    await db.refresh(task)
    return {
        "inspection_id": str(id),
        "task_id": task_id,
        "status": task.status,
        "result": result,
    }
