"""Aggregated API Router for v1 Endpoints (PRD Section 23)."""

from fastapi import APIRouter

from app.api.v1.auth import router as auth_router
from app.api.v1.inspections import router as inspections_router
from app.api.v1.images import router as images_router
from app.api.v1.analysis import router as analysis_router
from app.api.v1.compliance import router as compliance_router
from app.api.v1.rules import router as rules_router
from app.api.v1.reports import router as reports_router
from app.api.v1.dashboard import router as dashboard_router
from app.api.v1.users import router as users_router
from app.api.v1.audit import router as audit_router

from app.api.v1.declarations import router as declarations_router
from app.api.v1.copilot import router as copilot_router
from app.api.v1.storage import router as storage_router

api_router = APIRouter()

api_router.include_router(auth_router)
api_router.include_router(inspections_router)
api_router.include_router(images_router)
api_router.include_router(analysis_router)
api_router.include_router(declarations_router)
api_router.include_router(copilot_router)
api_router.include_router(compliance_router)
api_router.include_router(rules_router)
api_router.include_router(reports_router)
api_router.include_router(dashboard_router)
api_router.include_router(users_router)
api_router.include_router(audit_router)
api_router.include_router(storage_router)
