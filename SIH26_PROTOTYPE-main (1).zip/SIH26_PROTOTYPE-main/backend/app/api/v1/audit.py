"""Audit Log Explorer Endpoints (PRD Section 16 & 23)."""

from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_role
from app.models.audit import AuditLog

router = APIRouter(prefix="/audit-logs", tags=["Audit Logs"])


@router.get("", response_model=List[Dict[str, Any]])
async def query_audit_logs(
    actor_id: Optional[UUID] = Query(None, description="Filter by actor user ID"),
    action: Optional[str] = Query(None, description="Filter by action type (e.g. INSPECTION_CREATED)"),
    target_entity: Optional[str] = Query(None, description="Filter by entity type (Inspection, ComplianceCheck, etc.)"),
    target_id: Optional[UUID] = Query(None, description="Filter by specific target entity UUID"),
    from_date: Optional[datetime] = Query(None, description="Filter logs from this UTC datetime"),
    to_date: Optional[datetime] = Query(None, description="Filter logs up to this UTC datetime"),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=500),
    current_user: dict = Depends(require_role(["DeptAdmin", "SysAdmin", "Reviewer"])),
    db: AsyncSession = Depends(get_db),
):
    """
    Query immutable audit records. All mutating actions in the platform produce an audit row.
    Access is restricted to Reviewer, DeptAdmin, and SysAdmin roles (PRD Section 16).
    """
    stmt = select(AuditLog).offset(skip).limit(limit).order_by(AuditLog.created_at.desc())
    filters = []

    if actor_id:
        filters.append(AuditLog.actor_id == actor_id)
    if action:
        filters.append(AuditLog.action.ilike(f"%{action}%"))
    if target_entity:
        filters.append(AuditLog.target_entity == target_entity)
    if target_id:
        filters.append(AuditLog.target_id == target_id)
    if from_date:
        filters.append(AuditLog.created_at >= from_date)
    if to_date:
        filters.append(AuditLog.created_at <= to_date)

    if filters:
        stmt = stmt.where(and_(*filters))

    rows = list((await db.execute(stmt)).scalars().all())

    return [
        {
            "id": str(row.id),
            "actor_id": str(row.actor_id) if row.actor_id else None,
            "action": row.action,
            "target_entity": row.target_entity,
            "target_id": str(row.target_id) if row.target_id else None,
            "before_value": row.before_value,
            "after_value": row.after_value,
            "ip_address": row.ip_address,
            "created_at": row.created_at.isoformat(),
        }
        for row in rows
    ]
