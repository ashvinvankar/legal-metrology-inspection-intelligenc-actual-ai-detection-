"""Authentication Endpoints (PRD Section 23)."""

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from sqlalchemy.ext.asyncio import AsyncSession
from jose import JWTError, jwt

from app.core.config import settings
from app.core.database import get_db
from app.schemas.auth import LoginRequest, RefreshRequest, Token, UserRegisterRequest
from app.services.auth_service import AuthService

router = APIRouter(prefix="/auth", tags=["Authentication"])

from fastapi.security import OAuth2PasswordRequestForm

@router.post("/login", response_model=Token)
async def login(
    request: Request,
    response: Response,
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db)
):
    """Authenticate user with username and password, returns JWT tokens (PRD Section 22.4)."""
    from app.services.audit_service import AuditService
    from app.schemas.auth import LoginRequest
    
    login_data = LoginRequest(username=form_data.username, password=form_data.password)
    token = await AuthService.authenticate_user(db, login_data)
    if not token:
        # Log failed login attempt — best-effort, non-blocking
        try:
            from app.models.audit import AuditLog
            import uuid
            log = AuditLog(
                id=uuid.uuid4(),
                actor_id=None,
                action="LOGIN_FAILURE",
                target_entity="User",
                after_value={"username": login_data.username},
                ip_address=request.client.host if request.client else None,
            )
            db.add(log)
            await db.commit()
        except Exception:
            pass
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    response.set_cookie(
        key="refresh_token",
        value=token.refresh_token,
        httponly=True,
        secure=True,
        samesite="strict",
        max_age=settings.REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60,
    )
    # Don't send refresh token in JSON body
    token.refresh_token = ""
    return token

@router.post("/register", response_model=dict, status_code=status.HTTP_201_CREATED)
async def register(
    request: Request,
    user_in: UserRegisterRequest,
    db: AsyncSession = Depends(get_db)
):
    """Register a new user (PRD Section 22.4)."""
    user = await AuthService.register_user(db, user_in)
    
    # Log successful registration
    try:
        from app.models.audit import AuditLog
        import uuid
        log = AuditLog(
            id=uuid.uuid4(),
            actor_id=user.id,
            action="USER_REGISTERED",
            target_entity="User",
            after_value={"username": user.username, "email": user.email},
            ip_address=request.client.host if request.client else None,
        )
        db.add(log)
        await db.commit()
    except Exception:
        pass
        
    return {"message": "User registered successfully"}

@router.post("/refresh", response_model=Token)
async def refresh_token(request: Request, response: Response, db: AsyncSession = Depends(get_db)):
    """Exchange a valid refresh token cookie for a new access token."""
    refresh_token = request.cookies.get("refresh_token")
    if not refresh_token:
        # Try to fallback to JSON body if provided for backward compatibility during transition
        try:
            body = await request.json()
            refresh_token = body.get("refresh_token")
        except:
            pass
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired refresh token",
        headers={"WWW-Authenticate": "Bearer"},
    )
    if not refresh_token:
        raise credentials_exception
    try:
        payload = jwt.decode(
            refresh_token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM],
        )
        if payload.get("type") != "refresh":
            raise credentials_exception
        user_id: str = payload.get("sub")
        if not user_id:
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    import uuid as _uuid
    user = await AuthService.get_user_by_id(db, _uuid.UUID(user_id))
    if not user:
        raise credentials_exception

    from app.core.security import create_access_token
    token_data = {
        "sub": str(user.id),
        "username": user.username,
        "role": user.role.name if user.role else "Officer",
        "department_id": str(user.department_id) if user.department_id else None,
    }
    new_access_token = create_access_token(subject=str(user.id), extra_claims=token_data)
    response.set_cookie(
        key="refresh_token",
        value=refresh_token,
        httponly=True,
        secure=True,
        samesite="strict",
        max_age=settings.REFRESH_TOKEN_EXPIRE_DAYS * 24 * 60 * 60,
    )
    return Token(
        access_token=new_access_token,
        refresh_token="",
        token_type="bearer",
    )

@router.post("/logout")
async def logout(response: Response):
    """Clear refresh token cookie."""
    response.delete_cookie("refresh_token", secure=True, samesite="strict", httponly=True)
    return {"status": "ok"}
