"""Compliance Results and Officer Review Endpoints (PRD Section 23)."""

from typing import List
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_role, require_inspection_access
from app.schemas.compliance import ComplianceCheckDTO, ComplianceReviewRequest, ViolationDTO, EvidenceDTO
from app.services.compliance_service import ComplianceService
from app.services.audit_service import AuditService
from app.services.image_service import ImageService

router = APIRouter(tags=["Compliance"])


@router.get("/inspections/{inspection_id}/compliance", response_model=List[ComplianceCheckDTO])
async def get_inspection_compliance(
    inspection_id: UUID,
    current_user: dict = Depends(require_inspection_access),
    db: AsyncSession = Depends(get_db),
):
    """Retrieve 4-state legal compliance findings for the inspection (PRD Screen 7)."""
    checks = await ComplianceService.get_compliance_results(db, inspection_id)

    # Enrich with rule metadata for the response DTO
    results: List[ComplianceCheckDTO] = []
    for check in checks:
        rv = check.rule_version
        rule_key = rv.rule.rule_key if (rv and hasattr(rv, "rule") and rv.rule) else None
        requirement = rv.rule.requirement if (rv and hasattr(rv, "rule") and rv.rule) else None
        legal_ref = rv.rule.legal_reference if (rv and hasattr(rv, "rule") and rv.rule) else None

        results.append(
            ComplianceCheckDTO(
                id=check.id,
                inspection_id=check.inspection_id,
                rule_version_id=check.rule_version_id,
                rule_key=rule_key,
                requirement=requirement,
                legal_reference=legal_ref,
                input_fields=rv.input_fields if rv and hasattr(rv, "input_fields") else [],
                result=check.result,
                confidence=check.confidence,
                system_generated=check.system_generated,
                officer_decision=check.officer_decision,
                override_justification=check.override_justification,
                violations=[ViolationDTO(id=v.id, severity=v.severity, description=v.description) for v in check.violations],
                evidence_items=[
                    EvidenceDTO(
                        id=e.id,
                        image_id=e.image_id,
                        region_id=e.region_id,
                        ocr_result_id=e.ocr_result_id,
                        cropped_image_uri=await ImageService.get_browser_uri(e.cropped_image_uri) if e.cropped_image_uri else None,
                    )
                    for e in check.evidence_items
                ],
                created_at=check.created_at,
            )
        )
    return results


@router.patch("/compliance/{compliance_id}/review", response_model=ComplianceCheckDTO)
async def review_compliance_finding(
    compliance_id: UUID,
    payload: ComplianceReviewRequest,
    current_user: dict = Depends(require_role(["Officer", "Reviewer"])),
    db: AsyncSession = Depends(get_db),
):
    """
    Confirm or override a compliance finding (PRD Section 12).
    - decision=confirmed: officer agrees with system result
    - decision=overridden: officer overrides system result; justification is MANDATORY
    """
    if payload.decision == "overridden" and not (payload.justification or "").strip():
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="A detailed justification is mandatory when overriding a compliance finding.",
        )

    reviewer_id = UUID(current_user["id"])
    
    # Secure: finding -> inspection -> authorization
    from app.models.compliance import ComplianceCheck
    from sqlalchemy import select
    check_model = (await db.execute(select(ComplianceCheck).where(ComplianceCheck.id == compliance_id))).scalar_one_or_none()
    if not check_model:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Compliance check not found")
        
    from app.services.inspection_service import InspectionService
    inspection = await InspectionService.get_inspection(db, check_model.inspection_id)
    if not inspection:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Inspection not found")
    
    if current_user["role"] not in ["SysAdmin", "Reviewer", "DeptAdmin"] and str(inspection.officer_id) != current_user["id"]:
         raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="You do not have permission to review this inspection")

    try:
        check = await ComplianceService.review_finding(db, compliance_id, reviewer_id, payload)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e))

    if not check:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Compliance check not found")

    # Audit the review action (before/after state captured)
    action = "FINDING_OVERRIDDEN" if payload.decision == "overridden" else "FINDING_CONFIRMED"
    await AuditService.log_action(
        db,
        actor_id=reviewer_id,
        action=action,
        target_entity="ComplianceCheck",
        target_id=compliance_id,
        after_value={
            "decision": payload.decision,
            "justification": payload.justification,
            "result": check.result,
        },
    )

    return ComplianceCheckDTO(
        id=check.id,
        inspection_id=check.inspection_id,
        rule_version_id=check.rule_version_id,
        result=check.result,
        confidence=check.confidence,
        system_generated=check.system_generated,
        officer_decision=check.officer_decision,
        override_justification=check.override_justification,
        violations=[],
        evidence_items=[],
        created_at=check.created_at,
    )


@router.post("/inspections/{inspection_id}/compliance/evaluate", response_model=List[ComplianceCheckDTO])
async def trigger_compliance_evaluation(
    inspection_id: UUID,
    current_user: dict = Depends(require_inspection_access),
    db: AsyncSession = Depends(get_db),
):
    """
    Manually trigger compliance evaluation (async fallback if Celery pipeline not running).
    Evaluates all extracted fields against active rule versions, persists ComplianceCheck rows.
    """
    checks = await ComplianceService.run_rule_evaluation(db, inspection_id)
    if not checks:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="No extracted fields found. Run the analysis pipeline first.",
        )
    await AuditService.log_action(
        db,
        actor_id=UUID(current_user["id"]),
        action="COMPLIANCE_EVALUATED",
        target_entity="Inspection",
        target_id=inspection_id,
        after_value={"checks_created": len(checks)},
    )
    # Return simplified DTOs
    return [
        ComplianceCheckDTO(
            id=c.id,
            inspection_id=c.inspection_id,
            rule_version_id=c.rule_version_id,
            result=c.result,
            confidence=c.confidence,
            system_generated=c.system_generated,
            violations=[],
            evidence_items=[],
            created_at=c.created_at,
        )
        for c in checks
    ]
