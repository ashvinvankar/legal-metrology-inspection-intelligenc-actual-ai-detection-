"""Interactive AI Copilot Endpoint (PRD Section 12 & 23)."""

from typing import Any, Dict, List
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_inspection_access
from app.models.compliance import ComplianceCheck
from app.models.inspection import Inspection, ProductImage
from app.models.vision import ExtractedField
from app.pipeline.gemini_vision import GeminiVisionInspector
from app.schemas.vision import CopilotRequest, CopilotResponse
from app.services.image_service import ImageService

router = APIRouter(prefix="/inspections/{inspection_id}/copilot", tags=["AI Copilot"])


@router.post("", response_model=CopilotResponse)
async def query_ai_copilot(
    inspection_id: UUID,
    payload: CopilotRequest,
    current_user: dict = Depends(require_inspection_access),
    db: AsyncSession = Depends(get_db),
):
    """
    Query the Legal Metrology AI Copilot (Gemini 3.8 Flash).
    Grounded in the inspection's packaging photographs, extracted declarations, and rule findings.
    """
    inspection = (
        await db.execute(select(Inspection).where(Inspection.id == inspection_id))
    ).scalar_one_or_none()
    if not inspection:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Inspection not found")
        
    if inspection.ai_consent_granted != "granted":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, 
            detail="Explicit AI consent has not been granted for this inspection. Please update consent settings."
        )

    # Load extracted fields for grounding
    extracted_fields = list(
        (
            await db.execute(
                select(ExtractedField).where(ExtractedField.inspection_id == inspection_id)
            )
        )
        .scalars()
        .all()
    )

    # Load compliance checks
    checks = list(
        (
            await db.execute(
                select(ComplianceCheck).where(ComplianceCheck.inspection_id == inspection_id)
            )
        )
        .scalars()
        .all()
    )

    # Load first packaging image for visual grounding
    images = list(
        (
            await db.execute(
                select(ProductImage).where(ProductImage.inspection_id == inspection_id)
            )
        )
        .scalars()
        .all()
    )

    image_bytes = None
    if images:
        # Prefer label image if available
        label_img = next((img for img in images if img.image_type in ("label", "front")), images[0])
        image_bytes = await ImageService.get_image_bytes(label_img)

    context: Dict[str, Any] = {
        "inspection_id": str(inspection.id),
        "status": inspection.status,
        "overall_result": inspection.overall_result,
        "category": inspection.category,
        "extracted_declarations": {
            f.field_name: {
                "raw_value": f.raw_value,
                "normalized": f.normalized_value,
                "confidence": f.confidence,
                "officer_confirmed": f.officer_confirmed,
            }
            for f in extracted_fields
        },
        "compliance_findings": [
            {
                "rule_id": str(c.rule_version_id),
                "result": c.result,
                "confidence": c.confidence,
                "officer_decision": c.officer_decision,
            }
            for c in checks
        ],
    }
    
    from app.services.audit_service import AuditService
    await AuditService.log_action(
        db,
        actor_id=UUID(current_user["id"]),
        action="AI_COPILOT_QUERY",
        target_entity="Inspection",
        target_id=inspection_id,
        after_value={
            "query": payload.query,
            "provider": "gemini-3.8-flash" if GeminiVisionInspector.is_available() else "local-rule-assistant",
            "data_shared": {
                "extracted_declarations_count": len(extracted_fields),
                "compliance_findings_count": len(checks),
                "image_included": image_bytes is not None
            }
        }
    )

    answer = await GeminiVisionInspector.chat_copilot(
        query=payload.query,
        image_bytes=image_bytes,
        context=context,
        history=payload.history,
    )

    # Detect legal citations in answer
    references: List[str] = []
    if "Rule 6" in answer or "rule 6" in answer.lower():
        references.append("Legal Metrology (Packaged Commodities) Rules, 2011 - Rule 6")
    if "6(11)" in answer:
        references.append("Rule 6(11) - Unit Sale Price Declaration")
    if "Section 18" in answer:
        references.append("Legal Metrology Act, 2009 - Section 18")

    return CopilotResponse(
        answer=answer,
        source="gemini-3.8-flash" if GeminiVisionInspector.is_available() else "local-rule-assistant",
        rule_references=references or ["Legal Metrology (Packaged Commodities) Rules, 2011"],
    )
