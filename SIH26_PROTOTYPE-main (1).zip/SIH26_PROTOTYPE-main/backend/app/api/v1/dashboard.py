"""Dashboard Metrics & Repeat Violations Endpoints (PRD Section 15 & 23)."""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.dependencies import get_current_user
from app.schemas.dashboard import (
    DashboardSummary,
    DashboardTrendsResponse,
    ManufacturerTrend,
    ViolationCategoryBreakdown,
)
from app.services.dashboard_service import DashboardService

router = APIRouter(prefix="/dashboard", tags=["Dashboard"])


@router.get("/summary", response_model=DashboardSummary)
async def get_dashboard_summary(
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Overall enforcement metrics: total, compliant, non-compliant, needs-review (PRD Section 15)."""
    role = current_user.get("role")
    # Officers see only their own; all other roles see platform-wide
    officer_scope = UUID(current_user["id"]) if role == "Officer" else None
    summary = await DashboardService.get_summary(db, officer_id=officer_scope)
    return DashboardSummary(**summary)


@router.get("/violations", response_model=List[ViolationCategoryBreakdown])
async def get_top_violations(
    limit: int = Query(10, ge=1, le=50),
    severity: Optional[str] = Query(None, description="Filter by severity: Critical/Major/Minor"),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Ranked breakdown of top violations by Legal Metrology rule (PRD Section 15.3)."""
    rows = await DashboardService.get_violation_breakdown(db, limit=limit, severity=severity)
    return [ViolationCategoryBreakdown(**r) for r in rows]


@router.get("/trends", response_model=DashboardTrendsResponse)
async def get_enforcement_trends(
    days: int = Query(30, ge=7, le=365),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Time-series trend data for inspections and compliance rates (PRD Section 15.2)."""
    trends = await DashboardService.get_trends(db, days=days)
    return DashboardTrendsResponse(**trends)
