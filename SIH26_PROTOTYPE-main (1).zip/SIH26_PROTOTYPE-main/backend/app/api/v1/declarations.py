"""Extracted Mandatory Declarations Endpoints (PRD Section 9.E & Section 23)."""

from typing import List
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_role
from app.models.inspection import Inspection
from app.models.vision import ExtractedField
from app.schemas.vision import DeclarationUpdatePayload, ExtractedFieldDTO
from app.services.audit_service import AuditService

router = APIRouter(prefix="/inspections/{inspection_id}/declarations", tags=["Declarations"])


async def _get_authorized_inspection(db: AsyncSession, inspection_id: UUID, current_user: dict) -> Inspection:
    inspection = (await db.execute(select(Inspection).where(Inspection.id == inspection_id))).scalar_one_or_none()
    if not inspection:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Inspection not found")
    if current_user.get("role") == "Officer" and str(inspection.officer_id) != current_user["id"]:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied to this inspection")
    return inspection


@router.get("", response_model=List[ExtractedFieldDTO])
async def get_extracted_declarations(
    inspection_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Retrieve all structured declaration fields extracted from packaging labels (PRD Section 9.E)."""
    await _get_authorized_inspection(db, inspection_id, current_user)

    stmt = (
        select(ExtractedField)
        .where(ExtractedField.inspection_id == inspection_id)
        .order_by(ExtractedField.created_at.asc())
    )
    results = list((await db.execute(stmt)).scalars().all())
    return [ExtractedFieldDTO.model_validate(f) for f in results]


@router.patch("/{field_id}", response_model=ExtractedFieldDTO)
async def update_extracted_declaration(
    inspection_id: UUID,
    field_id: UUID,
    payload: DeclarationUpdatePayload,
    current_user: dict = Depends(require_role(["Officer", "Reviewer"])),
    db: AsyncSession = Depends(get_db),
):
    """
    Officer review/correction of an extracted declaration (PRD Section 12).
    Allows setting officer_confirmed=True and providing corrected raw/normalized values.
    Immutably logged in audit trail.
    """
    await _get_authorized_inspection(db, inspection_id, current_user)

    field = (
        await db.execute(
            select(ExtractedField).where(
                ExtractedField.id == field_id,
                ExtractedField.inspection_id == inspection_id,
            )
        )
    ).scalar_one_or_none()

    if not field:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Extracted declaration not found")

    officer_id = UUID(current_user["id"])
    before_state = {
        "raw_value": field.raw_value,
        "normalized_value": field.normalized_value,
        "officer_confirmed": field.officer_confirmed,
    }

    if payload.raw_value is not None:
        field.raw_value = payload.raw_value
    if payload.normalized_value is not None:
        field.officer_corrected_value = payload.normalized_value
        field.normalized_value = payload.normalized_value
    field.officer_confirmed = payload.officer_confirmed

    await db.commit()
    await db.refresh(field)

    await AuditService.log_action(
        db,
        actor_id=officer_id,
        action="DECLARATION_UPDATED",
        target_entity="ExtractedField",
        target_id=field.id,
        before_value=before_state,
        after_value={
            "raw_value": field.raw_value,
            "normalized_value": field.normalized_value,
            "officer_confirmed": field.officer_confirmed,
            "justification": payload.justification,
        },
    )

    return ExtractedFieldDTO.model_validate(field)
