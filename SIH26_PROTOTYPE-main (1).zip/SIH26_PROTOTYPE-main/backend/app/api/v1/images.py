"""Product and Label Images Endpoints (PRD Section 23)."""

from typing import List
from uuid import UUID
from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.dependencies import get_current_user, require_role, require_inspection_access
from app.pipeline.quality import ImageQualityAssessor
from app.schemas.image import ImageUploadResponse
from app.services.audit_service import AuditService
from app.services.image_service import ImageService
from app.services.inspection_service import InspectionService

router = APIRouter(prefix="/inspections/{inspection_id}/images", tags=["Images"])

_quality_assessor = ImageQualityAssessor(min_quality_score=settings.IMAGE_QUALITY_MIN_SCORE)


@router.post("", response_model=ImageUploadResponse, status_code=status.HTTP_201_CREATED)
async def upload_inspection_image(
    inspection_id: UUID,
    image_type: str = Form("label"),  # front, back, side, label, ecommerce
    file: UploadFile = File(...),
    current_user: dict = Depends(require_inspection_access),
    db: AsyncSession = Depends(get_db),
):
    """
    Upload an inspection image.
    Validates file type (magic bytes), runs Image Quality Assessment (PRD Section 9.A),
    persists to storage and DB, and returns quality result to the caller.
    """
    # Ensure inspection exists
    inspection = await InspectionService.get_inspection(db, inspection_id)
    if not inspection:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Inspection not found")

    officer_id = UUID(current_user["id"])

    # Save file (includes magic byte validation and size check)
    image, error = await ImageService.save_image(
        db, inspection_id, officer_id, file, image_type
    )
    if error:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=error["error"])

    # Run image quality assessment (PRD Section 9.A)
    image_bytes = await ImageService.get_image_bytes(image)
    quality_result = _quality_assessor.assess(image_bytes or b"", file.filename or "")

    # Persist quality score to the image record
    image.quality_score = quality_result["quality_score"]
    image.quality_issues = quality_result
    await db.flush()

    await AuditService.log_action(
        db,
        actor_id=officer_id,
        action="IMAGE_UPLOADED",
        target_entity="ProductImage",
        target_id=image.id,
        after_value={
            "inspection_id": str(inspection_id),
            "image_type": image_type,
            "quality_score": quality_result["quality_score"],
            "quality_passed": quality_result["passed"],
        },
    )

    # Preserve an opaque S3 URI in the database but return a short-lived URL
    # for immediate browser use.
    response = ImageUploadResponse.model_validate(image)
    response.original_uri = await ImageService.get_browser_uri(image.original_uri)
    return response


@router.get("", response_model=List[ImageUploadResponse])
async def list_inspection_images(
    inspection_id: UUID,
    current_user: dict = Depends(require_inspection_access),
    db: AsyncSession = Depends(get_db),
):
    """List all product and label images for an inspection."""
    images = await ImageService.get_images_for_inspection(db, inspection_id)
    responses = []
    for image in images:
        response = ImageUploadResponse.model_validate(image)
        response.original_uri = await ImageService.get_browser_uri(image.original_uri)
        if image.processed_uri:
            response.processed_uri = await ImageService.get_browser_uri(image.processed_uri)
        responses.append(response)
    return responses


