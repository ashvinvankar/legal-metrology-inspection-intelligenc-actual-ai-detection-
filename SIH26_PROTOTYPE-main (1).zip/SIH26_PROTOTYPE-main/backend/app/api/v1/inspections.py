"""Inspections Endpoints (PRD Section 23)."""

from typing import List, Optional
from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_role
from app.schemas.inspection import InspectionCreate, InspectionResponse, InspectionUpdate
from app.services.inspection_service import InspectionService
from app.services.audit_service import AuditService

router = APIRouter(prefix="/inspections", tags=["Inspections"])


@router.post("", response_model=InspectionResponse, status_code=status.HTTP_201_CREATED)
async def create_inspection(
    payload: InspectionCreate,
    current_user: dict = Depends(require_role(["Officer", "Reviewer"])),
    db: AsyncSession = Depends(get_db),
):
    """Create a new inspection record in draft state (PRD Section 7)."""
    officer_id = UUID(current_user["id"])
    inspection = await InspectionService.create_inspection(db, officer_id, payload)
    await AuditService.log_action(
        db,
        actor_id=officer_id,
        action="INSPECTION_CREATED",
        target_entity="Inspection",
        target_id=inspection.id,
        after_value={"category": inspection.category, "location": inspection.location},
    )
    return inspection


@router.get("", response_model=List[InspectionResponse])
async def list_inspections(
    status: Optional[str] = Query(None, description="Filter by status: draft/analyzing/completed/reported"),
    category: Optional[str] = Query(None),
    overall_result: Optional[str] = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=200),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Search & filter inspections. Officers see only their own; Reviewers/Admins see all (PRD Section 14)."""
    role = current_user.get("role")
    officer_filter = UUID(current_user["id"]) if role == "Officer" else None
    return await InspectionService.list_inspections(
        db,
        officer_id=officer_filter,
        status=status,
        category=category,
        overall_result=overall_result,
        skip=skip,
        limit=limit,
    )


@router.get("/{inspection_id}", response_model=InspectionResponse)
async def get_inspection(
    inspection_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get full inspection detail by UUID."""
    inspection = await InspectionService.get_inspection(db, inspection_id)
    if not inspection:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Inspection not found")
    # Officers can only view their own inspections
    role = current_user.get("role")
    if role == "Officer" and str(inspection.officer_id) != current_user["id"]:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied to this inspection")
    return inspection


@router.patch("/{inspection_id}", response_model=InspectionResponse)
async def update_inspection(
    inspection_id: UUID,
    payload: InspectionUpdate,
    current_user: dict = Depends(require_role(["Officer", "Reviewer", "DeptAdmin", "SysAdmin"])),
    db: AsyncSession = Depends(get_db),
):
    """Update inspection metadata or workflow status."""
    existing = await InspectionService.get_inspection(db, inspection_id)
    if not existing:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Inspection not found")
    # Officers are deliberately restricted to their own inspections.  Reviewer
    # and administrator roles retain their workflow-level access.
    if current_user.get("role") == "Officer" and str(existing.officer_id) != current_user["id"]:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied to this inspection")
    inspection = await InspectionService.update_inspection(db, inspection_id, payload)
    if not inspection:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Inspection not found")
    await AuditService.log_action(
        db,
        actor_id=UUID(current_user["id"]),
        action="INSPECTION_UPDATED",
        target_entity="Inspection",
        target_id=inspection_id,
        after_value={"status": payload.status, "overall_result": payload.overall_result},
    )
    return inspection
