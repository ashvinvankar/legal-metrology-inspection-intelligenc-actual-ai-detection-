"""Report Generation and Download Endpoints (PRD Section 13 & 23)."""

from pathlib import Path
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import FileResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.dependencies import get_current_user, require_role, require_inspection_access
from app.schemas.report import ReportRequest, ReportResponse
from app.services.audit_service import AuditService
from app.services.report_service import ReportService

router = APIRouter(tags=["Reports"])


@router.post("/inspections/{inspection_id}/report", response_model=ReportResponse, status_code=status.HTTP_201_CREATED)
async def generate_report(
    inspection_id: UUID,
    payload: ReportRequest,
    current_user: dict = Depends(require_inspection_access),
    db: AsyncSession = Depends(get_db),
):
    """
    Generate official inspection compliance report (PDF + optional DOCX).
    Aggregates all inspection data, compliance findings, violations, and officer review notes.
    Persists report metadata and returns URIs for download.
    """
    generated_by = UUID(current_user["id"])
    try:
        report = await ReportService.generate_report(
            db,
            inspection_id=inspection_id,
            report_type=payload.report_type,
            generated_by=generated_by,
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Report generation failed: {str(e)}",
        )

    await AuditService.log_action(
        db,
        actor_id=generated_by,
        action="REPORT_GENERATED",
        target_entity="Report",
        target_id=report.id,
        after_value={"inspection_id": str(inspection_id), "report_type": payload.report_type, "pdf_uri": report.pdf_uri},
    )
    return report


@router.get("/reports/{report_id}", response_model=ReportResponse)
async def get_report_metadata(
    report_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get report metadata by report UUID."""
    report = await ReportService.get_report(db, report_id)
    if not report:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Report not found")
        
    from app.services.inspection_service import InspectionService
    inspection = await InspectionService.get_inspection(db, report.inspection_id)
    if not inspection:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Inspection not found")
        
    if current_user["role"] not in ["SysAdmin", "Reviewer", "DeptAdmin"] and str(inspection.officer_id) != current_user["id"]:
         raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="You do not have permission to access this report")
         
    return report


@router.get("/reports/{report_id}/download")
async def download_report(
    report_id: UUID,
    file_type: str = "pdf",  # pdf or docx
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """
    Stream report file (PDF or DOCX) for download.
    Audit-logs every download event.
    """
    report = await ReportService.get_report(db, report_id)
    if not report:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Report not found")

    from app.services.inspection_service import InspectionService
    inspection = await InspectionService.get_inspection(db, report.inspection_id)
    if not inspection:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Inspection not found")
        
    if current_user["role"] not in ["SysAdmin", "Reviewer", "DeptAdmin"] and str(inspection.officer_id) != current_user["id"]:
         raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="You do not have permission to download this report")

    file_path = ReportService.get_report_file_path(report, file_type)
    if not file_path or not file_path.exists():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Report file ({file_type.upper()}) not found on server. Regenerate the report.",
        )

    await AuditService.log_action(
        db,
        actor_id=UUID(current_user["id"]),
        action="REPORT_DOWNLOADED",
        target_entity="Report",
        target_id=report_id,
        after_value={"file_type": file_type},
    )

    media_type = "application/pdf" if file_type == "pdf" else (
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )
    filename = f"compliance_report_{str(report.inspection_id)[:8]}.{file_type}"
    return FileResponse(path=str(file_path), media_type=media_type, filename=filename)
