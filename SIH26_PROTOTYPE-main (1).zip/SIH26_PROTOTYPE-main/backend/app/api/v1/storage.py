import mimetypes
from pathlib import Path
from fastapi import APIRouter, HTTPException, Query, status
from fastapi.responses import FileResponse
from jose import jwt, JWTError

from app.core.config import settings

router = APIRouter(prefix="/storage", tags=["Storage"])

@router.get("/{key:path}")
async def get_local_storage_file(key: str, token: str = Query(...)):
    """Serve local files securely using short-lived signed tokens."""
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        if payload.get("type") != "access" or payload.get("sub") != "storage":
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
        if payload.get("file_key") != key:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Token not valid for this file")
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token")

    file_path = Path(settings.STORAGE_DIR) / key
    if not file_path.exists() or not file_path.is_file():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="File not found")

    content_type, _ = mimetypes.guess_type(str(file_path))
    return FileResponse(str(file_path), media_type=content_type or "application/octet-stream")
