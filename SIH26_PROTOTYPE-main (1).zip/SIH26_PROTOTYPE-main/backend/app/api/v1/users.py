"""User Management Endpoints (DeptAdmin / SysAdmin)."""

from typing import List
from uuid import UUID
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import get_db
from app.core.dependencies import require_role
from app.schemas.auth import UserCreate, UserResponse

router = APIRouter(prefix="/users", tags=["User Management"])


@router.get("", response_model=List[UserResponse])
async def list_users(
    current_user: dict = Depends(require_role(["DeptAdmin", "SysAdmin"])),
    db: AsyncSession = Depends(get_db)
):
    """List users within department or globally."""
    return []


@router.post("", response_model=UserResponse)
async def create_user(
    payload: UserCreate,
    current_user: dict = Depends(require_role(["DeptAdmin", "SysAdmin"])),
    db: AsyncSession = Depends(get_db)
):
    """Onboard officer or reviewer."""
    return {
        "id": "55555555-5555-5555-5555-555555555555",
        "username": payload.username,
        "email": payload.email,
        "role_id": payload.role_id,
        "department_id": payload.department_id,
        "status": "active"
    }
