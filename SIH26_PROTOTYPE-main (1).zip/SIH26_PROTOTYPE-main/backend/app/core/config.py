"""Application Settings & Configuration."""

from typing import List, Optional, Union
from pydantic import AnyHttpUrl, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    # Application Info
    PROJECT_NAME: str = "Smart Legal Metrology Compliance Inspection Platform"
    ENVIRONMENT: str = "development"
    API_V1_STR: str = "/api/v1"

    # Security & Tokens
    SECRET_KEY: str
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # CORS
    BACKEND_CORS_ORIGINS: List[str] = ["http://localhost:3000", "http://127.0.0.1:3000"]

    # Database (Default to SQLite for local development, or PostgreSQL via env)
    DATABASE_URL: str = "sqlite+aiosqlite:///./slm_cip.db"
    DATABASE_URL_SYNC: str = "sqlite:///./slm_cip.db"

    # Redis & Celery
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    CELERY_BROKER_URL: str = "redis://localhost:6379/0"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/0"

    # Storage Settings
    STORAGE_DIR: str = "storage_data"
    STORAGE_BACKEND: str = "local"  # local for developer mode, s3 for MinIO/S3 deployments
    STORAGE_ENDPOINT: str = "localhost:9000"
    STORAGE_ACCESS_KEY: str
    STORAGE_SECRET_KEY: str
    STORAGE_BUCKET_NAME: str = "slm-evidence"
    STORAGE_USE_SSL: bool = False
    STORAGE_PUBLIC_URL: str = "/storage"

    # AI & Uncertainty Thresholds (PRD Section 9.F & Section 10)
    OCR_HIGH_CONFIDENCE_THRESHOLD: float = 0.90
    OCR_MEDIUM_CONFIDENCE_THRESHOLD: float = 0.60
    IMAGE_QUALITY_MIN_SCORE: float = 0.65

    # ML Model Mode & Safety Controls
    # DEMO_MODE must be explicitly set to True to allow mock fallbacks.
    # In production (DEMO_MODE=False), the platform runs real inference only and fails safely.
    # USE_REAL_MODELS=true requires verified weights at backend/models/slm_detector.pt
    # and AI dependencies from requirements-ai.txt. Worker startup will fail clearly
    # with a logged error if these are missing.
    DEMO_MODE: bool = False
    USE_REAL_MODELS: bool = True

    # Detector settings (YOLOv8 / YOLO11)
    MODEL_PATH: str = "models/slm_detector.pt"
    MODEL_METADATA_PATH: str = "models/model_metadata.json"
    DETECTOR_CONF_THRESHOLD: float = 0.25
    DETECTOR_IOU_THRESHOLD: float = 0.45

    # OCR settings (EasyOCR)
    # Supports English (en) and Hindi/Devanagari (hi) for Indian packaged goods.
    # Benchmark note: PaddleOCR may replace EasyOCR for dense-text labels in a future release.
    OCR_LANGUAGES: List[str] = ["en", "hi"]

    # Multimodal Vision AI & Copilot Settings (Google Gemini 3.8 Flash)
    GEMINI_API_KEY: Optional[str] = None
    GEMINI_MODEL: str = "gemini-3.8-flash"
    AI_VISION_PROVIDER: str = "hybrid"  # "gemini", "local", or "hybrid"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore"
    )


settings = Settings()
