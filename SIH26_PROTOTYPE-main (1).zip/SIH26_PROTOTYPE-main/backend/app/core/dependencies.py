"""FastAPI Dependency injection helpers (Authentication, DB, RBAC)."""

from typing import List, Optional
import uuid
from fastapi import Depends, HTTPException, status, Request
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.services.inspection_service import InspectionService

oauth2_scheme = OAuth2PasswordBearer(
    tokenUrl=f"{settings.API_V1_STR}/auth/login",
    auto_error=False
)


async def get_current_user(
    token: Optional[str] = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db)
) -> dict:
    """
    Validate bearer token, look up user in DB, and return user context dict.
    Raises HTTP 401 on any token or DB lookup failure — no bypass in any environment.
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    if not token:
        raise credentials_exception

    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        if payload.get("type") != "access":
            raise credentials_exception
        user_id: str = payload.get("sub")
        if user_id is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    # DB lookup to ensure user is still active (catches disabled/deleted users)
    from app.services.auth_service import AuthService
    try:
        user = await AuthService.get_user_by_id(db, uuid.UUID(user_id))
    except (ValueError, Exception):
        raise credentials_exception

    if not user:
        raise credentials_exception

    role_name = user.role.name if user.role else payload.get("role", "Officer")
    return {
        "id": str(user.id),
        "username": user.username,
        "role": role_name,
        "department_id": str(user.department_id) if user.department_id else None,
    }


def require_role(allowed_roles: List[str]):
    """Dependency factory to enforce server-side RBAC (PRD Section 6.5)."""
    async def role_checker(current_user: dict = Depends(get_current_user)) -> dict:
        user_role = current_user.get("role")
        if user_role not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Operation not permitted. Required roles: {allowed_roles}. Your role: {user_role}",
            )
        return current_user
    return role_checker

async def require_inspection_access(
    inspection_id: uuid.UUID,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
) -> dict:
    """Ensure the user owns the inspection or is an authorized admin/reviewer."""
    inspection = await InspectionService.get_inspection(db, inspection_id)
    if not inspection:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Inspection not found")

    user_role = current_user.get("role")
    
    if user_role == "SysAdmin":
        return current_user
        
    if current_user["id"] == str(inspection.officer_id):
        return current_user
        
    if user_role in ["Reviewer", "DeptAdmin"]:
        # TODO: Add specific department matching here
        return current_user

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="You do not have permission to access this inspection.",
    )
