"""Database Initialization & Seed Data (Rules, Roles, Default Users)."""

import json
import logging
import uuid
from datetime import date, datetime
from pathlib import Path
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import Base, async_engine, AsyncSessionLocal
from app.core.security import get_password_hash
from app.models.user import Role, User
from app.models.rule import Rule, RuleVersion

logger = logging.getLogger(__name__)

DEFAULT_ROLES = [
    {"name": "Officer", "description": "Legal Metrology Enforcement Officer"},
    {"name": "Reviewer", "description": "Senior Reviewer / Quality Officer"},
    {"name": "DeptAdmin", "description": "Departmental Administrator"},
    {"name": "SysAdmin", "description": "System Administrator"},
]

DEFAULT_OFFICER_ID = uuid.UUID("11111111-1111-1111-1111-111111111111")


async def init_db():
    """Create all tables and seed initial roles, users, and legal rules."""
    # Create tables
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

        # Ensure newly added columns exist in legacy or existing database tables
        def _ensure_schema_columns(sync_conn):
            from sqlalchemy import inspect, text
            inspector = inspect(sync_conn)
            table_names = inspector.get_table_names()
            if "inspections" in table_names:
                cols = {c["name"] for c in inspector.get_columns("inspections")}
                if "product_name" not in cols:
                    sync_conn.execute(text("ALTER TABLE inspections ADD COLUMN product_name VARCHAR(255)"))
                if "category" not in cols:
                    sync_conn.execute(text("ALTER TABLE inspections ADD COLUMN category VARCHAR(100) DEFAULT 'Packaged Food'"))
                if "ai_consent_granted" not in cols:
                    sync_conn.execute(text("ALTER TABLE inspections ADD COLUMN ai_consent_granted VARCHAR(50) DEFAULT 'pending'"))

        await conn.run_sync(_ensure_schema_columns)


    # Seed data
    async with AsyncSessionLocal() as session:
        try:
            await _seed_roles_and_users(session)
            await _seed_rules(session)
            await session.commit()
            logger.info("Database initialized and seeded successfully.")
        except Exception as e:
            await session.rollback()
            logger.error(f"Error during database initialization: {e}")
            raise


async def _seed_roles_and_users(session: AsyncSession):
    # Seed roles
    role_map = {}
    for r in DEFAULT_ROLES:
        stmt = select(Role).where(Role.name == r["name"])
        existing = (await session.execute(stmt)).scalar_one_or_none()
        if not existing:
            new_role = Role(id=uuid.uuid4(), name=r["name"], description=r["description"])
            session.add(new_role)
            await session.flush()
            role_map[r["name"]] = new_role.id
        else:
            role_map[r["name"]] = existing.id

    # Seed default officer
    officer_stmt = select(User).where(User.username == "officer_sharma")
    officer = (await session.execute(officer_stmt)).scalar_one_or_none()
    if not officer:
        new_officer = User(
            id=DEFAULT_OFFICER_ID,
            username="officer_sharma",
            email="officer.sharma@doca.gov.in",
            password_hash=get_password_hash("password123"),
            role_id=role_map["Officer"],
            status="active"
        )
        session.add(new_officer)

    # Seed default admin
    admin_stmt = select(User).where(User.username == "admin")
    admin = (await session.execute(admin_stmt)).scalar_one_or_none()
    if not admin:
        new_admin = User(
            id=uuid.UUID("99999999-9999-9999-9999-999999999999"),
            username="admin",
            email="admin@doca.gov.in",
            password_hash=get_password_hash("admin123"),
            role_id=role_map["SysAdmin"],
            status="active"
        )
        session.add(new_admin)

    await session.flush()


async def _seed_rules(session: AsyncSession):
    # Find rules file
    possible_paths = [
        Path("rules/pc_rules_2011_v1.json"),
        Path(__file__).resolve().parents[3] / "rules" / "pc_rules_2011_v1.json",
    ]
    rule_file = None
    for p in possible_paths:
        if p.exists():
            rule_file = p
            break

    if not rule_file:
        logger.warning("Rules seed file pc_rules_2011_v1.json not found.")
        return

    with open(rule_file, "r", encoding="utf-8") as f:
        rules_data = json.load(f)

    for item in rules_data:
        rule_key = item.get("rule_key")
        if not rule_key:
            continue

        stmt = select(Rule).where(Rule.rule_key == rule_key)
        existing_rule = (await session.execute(stmt)).scalar_one_or_none()
        if not existing_rule:
            rule_obj = Rule(
                id=uuid.uuid4(),
                rule_key=rule_key,
                legal_reference=item.get("legal_reference", ""),
                requirement=item.get("requirement", ""),
                severity=item.get("severity", "Major"),
                source_document=item.get("source_document", ""),
                created_by=DEFAULT_OFFICER_ID
            )
            session.add(rule_obj)
            await session.flush()

            version_obj = RuleVersion(
                id=uuid.uuid4(),
                rule_id=rule_obj.id,
                version=item.get("version", 1),
                applicability_conditions=item.get("applicability_conditions", {}),
                input_fields=item.get("input_fields", []),
                validation_logic=item.get("validation_logic", {}),
                evidence_requirements=item.get("evidence_requirements", []),
                explanation_template=item.get("explanation_template", ""),
                active_from=date.today(),
                status="published",
                published_by=DEFAULT_OFFICER_ID
            )
            session.add(version_obj)
