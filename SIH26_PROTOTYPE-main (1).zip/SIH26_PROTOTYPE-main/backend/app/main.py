"""FastAPI Application Entrypoint (PRD Section 21 & 22)."""

import os
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.init_db import init_db
from app.api.v1.api_router import api_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup and shutdown events."""
    # Ensure storage directories exist
    storage_path = Path(settings.STORAGE_DIR)
    storage_path.mkdir(parents=True, exist_ok=True)
    (storage_path / "images").mkdir(parents=True, exist_ok=True)
    (storage_path / "reports").mkdir(parents=True, exist_ok=True)

    # Initialize database tables & seed initial data
    await init_db()
    yield


app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Backend API for Smart Legal Metrology Compliance Inspection Platform (SIH Problem Statement 26034)",
    version="1.0.0",
    openapi_url=f"{settings.API_V1_STR}/openapi.json",
    docs_url=f"{settings.API_V1_STR}/docs",
    redoc_url=f"{settings.API_V1_STR}/redoc",
    lifespan=lifespan,
)

# Set CORS middleware
if settings.BACKEND_CORS_ORIGINS:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.BACKEND_CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

# Static file serving removed for security. Local files now served via authenticated /storage endpoints.
storage_dir = Path(settings.STORAGE_DIR)
storage_dir.mkdir(parents=True, exist_ok=True)

# Include API v1 Router
app.include_router(api_router, prefix=settings.API_V1_STR)


@app.get("/health", tags=["System"])
async def health_check():
    """Health check endpoint for container orchestrators and load balancers."""
    return {
        "status": "healthy",
        "service": "SLM-CIP Backend API",
        "environment": settings.ENVIRONMENT,
        "version": "1.0.0"
    }

@app.get("/", include_in_schema=False)
async def root_redirect():
    from fastapi.responses import RedirectResponse
    return RedirectResponse(url=f"{settings.API_V1_STR}/docs")
