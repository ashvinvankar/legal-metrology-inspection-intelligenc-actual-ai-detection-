"""Aggregate export of all SQLAlchemy ORM models."""

from app.core.database import Base
from app.models.user import User, Role, Permission, role_permissions
from app.models.product import Product, Manufacturer
from app.models.inspection import Inspection, InspectionAnalysisTask, ProductImage
from app.models.vision import DetectedRegion, OCRResult, ExtractedField
from app.models.rule import Rule, RuleVersion
from app.models.compliance import ComplianceCheck, Violation, Evidence
from app.models.report import Report
from app.models.audit import AuditLog

__all__ = [
    "Base",
    "User",
    "Role",
    "Permission",
    "role_permissions",
    "Product",
    "Manufacturer",
    "Inspection",
    "InspectionAnalysisTask",
    "ProductImage",
    "DetectedRegion",
    "OCRResult",
    "ExtractedField",
    "Rule",
    "RuleVersion",
    "ComplianceCheck",
    "Violation",
    "Evidence",
    "Report",
    "AuditLog"
]
