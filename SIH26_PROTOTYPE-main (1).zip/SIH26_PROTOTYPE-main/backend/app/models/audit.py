"""Immutable Audit Log Models (PRD Section 16 & 24)."""

import uuid
from datetime import datetime
from sqlalchemy import Column, DateTime, ForeignKey, Index, String
from app.core.types import JSONB, UUID

from app.core.database import Base


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    actor_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True, index=True)  # Nullable for anonymous actions (login failures, system events)
    action = Column(String(100), nullable=False, index=True)  # login/upload/create/override/publish_rule/etc.
    target_entity = Column(String(100), nullable=False)  # inspection/image/compliance_check/rule/user
    target_id = Column(UUID(as_uuid=True), nullable=True)
    before_value = Column(JSONB, nullable=True)
    after_value = Column(JSONB, nullable=True)
    ip_address = Column(String(50), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
