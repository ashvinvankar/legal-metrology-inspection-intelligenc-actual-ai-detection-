"""Compliance Findings, Violations, and Evidence Models (PRD Section 12 & 24)."""

import uuid
from datetime import datetime
from sqlalchemy import Boolean, Column, DateTime, Float, ForeignKey, Index, String, Text
from app.core.types import UUID
from sqlalchemy.orm import relationship

from app.core.database import Base


class ComplianceCheck(Base):
    __tablename__ = "compliance_checks"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    inspection_id = Column(UUID(as_uuid=True), ForeignKey("inspections.id", ondelete="CASCADE"), nullable=False, index=True)
    rule_version_id = Column(UUID(as_uuid=True), ForeignKey("rule_versions.id"), nullable=False, index=True)
    result = Column(String(50), nullable=False, index=True)  # COMPLIANT/NON_COMPLIANT/NEEDS_REVIEW/NOT_APPLICABLE
    confidence = Column(Float, nullable=True)
    system_generated = Column(Boolean, default=True, nullable=False)
    officer_decision = Column(String(50), nullable=True)  # confirmed/overridden
    officer_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    override_justification = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    inspection = relationship("Inspection", back_populates="compliance_checks")
    rule_version = relationship("RuleVersion", back_populates="compliance_checks")
    violations = relationship("Violation", back_populates="compliance_check", cascade="all, delete-orphan")
    evidence_items = relationship("Evidence", back_populates="compliance_check", cascade="all, delete-orphan")


class Violation(Base):
    __tablename__ = "violations"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    compliance_check_id = Column(UUID(as_uuid=True), ForeignKey("compliance_checks.id", ondelete="CASCADE"), nullable=False, index=True)
    severity = Column(String(50), nullable=False)  # Critical / Major / Minor
    description = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    compliance_check = relationship("ComplianceCheck", back_populates="violations")


class Evidence(Base):
    __tablename__ = "evidence"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    compliance_check_id = Column(UUID(as_uuid=True), ForeignKey("compliance_checks.id", ondelete="CASCADE"), nullable=False, index=True)
    image_id = Column(UUID(as_uuid=True), ForeignKey("product_images.id", ondelete="SET NULL"), nullable=True)
    region_id = Column(UUID(as_uuid=True), ForeignKey("detected_regions.id", ondelete="SET NULL"), nullable=True)
    ocr_result_id = Column(UUID(as_uuid=True), ForeignKey("ocr_results.id", ondelete="SET NULL"), nullable=True)
    cropped_image_uri = Column(String(512), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    compliance_check = relationship("ComplianceCheck", back_populates="evidence_items")
