"""Inspection and Product Image Models (PRD Section 24)."""

import uuid
from datetime import datetime
from sqlalchemy import Column, DateTime, Float, ForeignKey, Index, Integer, String, Text
from app.core.types import JSONB, UUID
from sqlalchemy.orm import relationship

from app.core.database import Base


class Inspection(Base):
    __tablename__ = "inspections"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    product_id = Column(UUID(as_uuid=True), ForeignKey("products.id"), nullable=True)
    product_name = Column(String(255), nullable=True)
    category = Column(String(100), default="Packaged Food", nullable=False)
    officer_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False, index=True)
    reviewer_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    status = Column(String(50), default="draft", nullable=False, index=True)  # draft/analyzing/needs_review/completed/reported
    location = Column(String(255), nullable=True)
    overall_result = Column(String(50), nullable=True)  # COMPLIANT/NON_COMPLIANT/NEEDS_REVIEW
    ai_consent_granted = Column(String(50), default="pending", nullable=False) # pending/granted/denied
    inspection_date = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    product = relationship("Product", back_populates="inspections")
    images = relationship("ProductImage", back_populates="inspection", cascade="all, delete-orphan")
    extracted_fields = relationship("ExtractedField", back_populates="inspection", cascade="all, delete-orphan")
    compliance_checks = relationship("ComplianceCheck", back_populates="inspection", cascade="all, delete-orphan")
    reports = relationship("Report", back_populates="inspection", cascade="all, delete-orphan")
    analysis_tasks = relationship("InspectionAnalysisTask", back_populates="inspection", cascade="all, delete-orphan")


class InspectionAnalysisTask(Base):
    """Durable state for an asynchronous inspection analysis job.

    Celery result backends are transient operational infrastructure.  This row is
    the API's source of truth and supplies the idempotency boundary for retries.
    """
    __tablename__ = "inspection_analysis_tasks"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    inspection_id = Column(UUID(as_uuid=True), ForeignKey("inspections.id", ondelete="CASCADE"), nullable=False, index=True)
    celery_task_id = Column(String(100), nullable=False, unique=True, index=True)
    status = Column(String(30), nullable=False, default="queued", index=True)  # queued/running/retrying/failed/completed
    stage = Column(String(50), nullable=False, default="QUEUED")
    progress_percent = Column(Integer, nullable=False, default=0)
    attempt = Column(Integer, nullable=False, default=0)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    inspection = relationship("Inspection", back_populates="analysis_tasks")


class ProductImage(Base):
    __tablename__ = "product_images"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    inspection_id = Column(UUID(as_uuid=True), ForeignKey("inspections.id", ondelete="CASCADE"), nullable=False, index=True)
    image_type = Column(String(50), nullable=False)  # front/back/side/label/ecommerce
    original_uri = Column(String(512), nullable=False)
    processed_uri = Column(String(512), nullable=True)
    quality_score = Column(Float, nullable=True)
    quality_issues = Column(JSONB, nullable=True)  # {blur: bool, glare: bool, issues: []}
    uploaded_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    inspection = relationship("Inspection", back_populates="images")
    detected_regions = relationship("DetectedRegion", back_populates="image", cascade="all, delete-orphan")
