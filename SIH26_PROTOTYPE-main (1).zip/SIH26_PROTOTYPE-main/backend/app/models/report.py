"""Report Generation Models (PRD Section 13 & 24)."""

import uuid
from datetime import datetime
from sqlalchemy import Column, DateTime, ForeignKey, Index, String
from app.core.types import UUID
from sqlalchemy.orm import relationship

from app.core.database import Base


class Report(Base):
    __tablename__ = "reports"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    inspection_id = Column(UUID(as_uuid=True), ForeignKey("inspections.id", ondelete="CASCADE"), nullable=False, index=True)
    report_type = Column(String(50), default="summary", nullable=False)  # summary/detailed
    pdf_uri = Column(String(512), nullable=True)
    docx_uri = Column(String(512), nullable=True)
    qr_reference = Column(String(100), unique=True, nullable=False, index=True)
    generated_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    generated_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    inspection = relationship("Inspection", back_populates="reports")
