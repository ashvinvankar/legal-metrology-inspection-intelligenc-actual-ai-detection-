"""Legal Metrology Rule Engine Versioned Models (PRD Section 10 & 24)."""

import uuid
from datetime import date, datetime
from sqlalchemy import Column, Date, DateTime, ForeignKey, Integer, String, Text
from app.core.types import JSONB, UUID
from sqlalchemy.orm import relationship

from app.core.database import Base


class Rule(Base):
    __tablename__ = "rules"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    rule_key = Column(String(100), unique=True, nullable=False, index=True)  # stable business key across versions
    legal_reference = Column(String(255), nullable=False)
    requirement = Column(Text, nullable=False)
    severity = Column(String(50), default="Major", nullable=False)  # Critical / Major / Minor
    source_document = Column(String(255), nullable=True)
    created_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    versions = relationship("RuleVersion", back_populates="rule", cascade="all, delete-orphan")


class RuleVersion(Base):
    __tablename__ = "rule_versions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    rule_id = Column(UUID(as_uuid=True), ForeignKey("rules.id", ondelete="CASCADE"), nullable=False, index=True)
    version = Column(Integer, default=1, nullable=False)
    applicability_conditions = Column(JSONB, nullable=False)
    input_fields = Column(JSONB, nullable=False)
    validation_logic = Column(JSONB, nullable=False)
    evidence_requirements = Column(JSONB, nullable=False)
    explanation_template = Column(Text, nullable=False)
    active_from = Column(Date, default=date.today, nullable=False, index=True)
    active_until = Column(Date, nullable=True, index=True)
    status = Column(String(50), default="published", nullable=False)  # draft/published/superseded
    published_by = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    rule = relationship("Rule", back_populates="versions")
    compliance_checks = relationship("ComplianceCheck", back_populates="rule_version")
