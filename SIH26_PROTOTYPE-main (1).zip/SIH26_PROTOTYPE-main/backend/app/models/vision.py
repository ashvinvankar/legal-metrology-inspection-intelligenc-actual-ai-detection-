"""Computer Vision and OCR Pipeline Models (PRD Section 24)."""

import uuid
from datetime import datetime
from sqlalchemy import Boolean, Column, DateTime, Float, ForeignKey, Index, String, Text
from app.core.types import JSONB, UUID
from sqlalchemy.orm import relationship

from app.core.database import Base


class DetectedRegion(Base):
    __tablename__ = "detected_regions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    image_id = Column(UUID(as_uuid=True), ForeignKey("product_images.id", ondelete="CASCADE"), nullable=False, index=True)
    region_type = Column(String(50), nullable=False)  # mrp/net_quantity/manufacturer/etc.
    bbox = Column(JSONB, nullable=False)  # [x1, y1, x2, y2]
    confidence = Column(Float, nullable=False)
    model_version = Column(String(50), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    image = relationship("ProductImage", back_populates="detected_regions")
    ocr_results = relationship("OCRResult", back_populates="region", cascade="all, delete-orphan")


class OCRResult(Base):
    __tablename__ = "ocr_results"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    region_id = Column(UUID(as_uuid=True), ForeignKey("detected_regions.id", ondelete="CASCADE"), nullable=False, index=True)
    text = Column(Text, nullable=False)
    confidence = Column(Float, nullable=False)
    bbox = Column(JSONB, nullable=True)
    language = Column(String(20), default="en", nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    region = relationship("DetectedRegion", back_populates="ocr_results")


class ExtractedField(Base):
    __tablename__ = "extracted_fields"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    inspection_id = Column(UUID(as_uuid=True), ForeignKey("inspections.id", ondelete="CASCADE"), nullable=False, index=True)
    field_name = Column(String(100), nullable=False, index=True)  # mrp/net_quantity/manufacturer_name/etc.
    raw_value = Column(Text, nullable=True)
    normalized_value = Column(JSONB, nullable=True)
    confidence = Column(Float, nullable=False)
    source_ocr_id = Column(UUID(as_uuid=True), ForeignKey("ocr_results.id"), nullable=True)
    officer_confirmed = Column(Boolean, default=False, nullable=False)
    officer_corrected_value = Column(JSONB, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    inspection = relationship("Inspection", back_populates="extracted_fields")
