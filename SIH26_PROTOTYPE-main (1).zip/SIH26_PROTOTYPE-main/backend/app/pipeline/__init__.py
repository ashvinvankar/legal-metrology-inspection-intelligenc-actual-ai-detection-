"""AI / Computer Vision & OCR Pipeline package."""

from app.pipeline.quality import ImageQualityAssessor
from app.pipeline.preprocessor import ImagePreprocessor
from app.pipeline.detector import RegionDetector, DetectedBoundingBox
from app.pipeline.ocr_engine import OCREngine, OCRSpan
from app.pipeline.extractor import InformationExtractor, NormalizedField
from app.pipeline.confidence import ConfidenceBand, UncertaintyHandler

__all__ = [
    "ImageQualityAssessor",
    "ImagePreprocessor",
    "RegionDetector",
    "DetectedBoundingBox",
    "OCREngine",
    "OCRSpan",
    "InformationExtractor",
    "NormalizedField",
    "ConfidenceBand",
    "UncertaintyHandler"
]
