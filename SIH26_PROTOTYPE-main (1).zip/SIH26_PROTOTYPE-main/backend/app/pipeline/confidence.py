"""Confidence Scoring and Uncertainty Routing (PRD Section 9.F)."""

from enum import Enum


class ConfidenceBand(str, Enum):
    HIGH = "HIGH"        # >= 0.90: Auto-process downstream
    MEDIUM = "MEDIUM"    # 0.60 - 0.90: Flag for officer confirmation; routes to NEEDS_REVIEW
    LOW = "LOW"          # < 0.60: Not reliably extracted; prompt manual entry/recapture


class UncertaintyHandler:
    """Routes extracted fields to downstream processing or officer review."""

    def __init__(self, high_threshold: float = 0.90, medium_threshold: float = 0.60):
        self.high_threshold = high_threshold
        self.medium_threshold = medium_threshold

    def determine_band(self, confidence: float) -> ConfidenceBand:
        if confidence >= self.high_threshold:
            return ConfidenceBand.HIGH
        elif confidence >= self.medium_threshold:
            return ConfidenceBand.MEDIUM
        return ConfidenceBand.LOW
