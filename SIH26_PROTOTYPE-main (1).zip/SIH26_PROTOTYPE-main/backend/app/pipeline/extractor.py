"""Structured Declaration Information Extraction & Normalization (PRD Section 9.E).

Converts raw OCR spans into typed, normalized, structured fields adhering to the
single canonical field vocabulary:
- mrp → {value, normalized_value (float), currency}
- net_quantity → {value, normalized_value (float), unit}
- date_of_manufacture → {value, month, year}
- consumer_care_contact → {value, phone, email, present}
- manufacturer_address → {value, pincode, present}
- unit_sale_price → {value, normalized_value (float), unit, currency}
- manufacturer_name / packer_name / importer_name / country_of_origin → {value, present}
"""

import re
from typing import Any, Dict, List, Optional
from pydantic import BaseModel

from app.core.config import settings

# ─── Canonical Field Vocabulary ───────────────────────────────────────────────
CANONICAL_FIELDS: List[str] = [
    "mrp",
    "net_quantity",
    "manufacturer_name",
    "manufacturer_address",
    "packer_name",
    "consumer_care_contact",
    "date_of_manufacture",
    "country_of_origin",
    "unit_sale_price",
    "importer_name",
]

# Aliases to guarantee contract backward compatibility
FIELD_ALIASES: Dict[str, str] = {
    "date_declaration": "date_of_manufacture",
    "consumer_care": "consumer_care_contact",
    "manufacturer": "manufacturer_name",
    "packer": "packer_name",
    "importer": "importer_name",
    "usp": "unit_sale_price",
}


class NormalizedField(BaseModel):
    field_name: str
    raw_value: str
    normalized_value: Dict[str, Any]
    confidence: float
    bbox: List[float]


class InformationExtractor:
    """
    Converts raw OCR spans into typed structured fields with canonical naming.
    Applies confidence-band logic per PRD Section 9.F:
      - High (≥0.90): use directly
      - Medium (0.60–0.90): flag for officer confirmation
      - Low (<0.60): mark unreliable
    """

    # --- MRP normalization ---
    _MRP_PATTERN = re.compile(
        r"(?:M\.?R\.?P\.?|मूल्य)[\s:]*(?:Rs\.?|₹|INR)?\s*(\d+(?:[.,]\d+)?)",
        re.IGNORECASE
    )
    _CURRENCY_PATTERN = re.compile(r"(?:Rs\.?|₹|INR)\s*(\d+(?:[.,]\d+)?)", re.IGNORECASE)

    # --- Net Quantity normalization ---
    _QTY_PATTERN = re.compile(
        r"(?:Net\s+(?:Qty|Quantity|Content|Wt\.?|Weight|Volume))?[\s:]*(\d+(?:[.,]\d+)?)\s*(g|gm|gms|gram|grams|kg|ml|l|litre|liter|ltr|litres|pcs|pieces|no\.?|unit|units|nos)",
        re.IGNORECASE
    )
    _UNIT_MAP = {
        "g": "g", "gm": "g", "gms": "g", "gram": "g", "grams": "g",
        "kg": "kg", "ml": "ml", "l": "l", "litre": "l", "liter": "l", "ltr": "l", "litres": "l",
        "pcs": "pcs", "pieces": "pcs", "no.": "pcs", "no": "pcs", "unit": "pcs",
        "units": "pcs", "nos": "pcs"
    }

    # --- Date normalization ---
    _DATE_PATTERN = re.compile(
        r"(?:Mfg\.?\s*Date|Manufactured|Best\s*Before|Mfg\.|B\.B\.|PKD|Packed)?[\s:]*(\d{1,2})[/\-\.](\d{2,4})",
        re.IGNORECASE
    )
    _DATE_TEXT_PATTERN = re.compile(
        r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*[\s\.,\-/]+(20\d{2}|\d{2})",
        re.IGNORECASE
    )

    # --- Contact details normalization ---
    _PHONE_PATTERN = re.compile(r"(?:1800[\s\-]?\d{3}[\s\-]?\d{3,4}|(?:\+?91[\s\-]?)?[6-9]\d{4}[\s\-]?\d{5}|\d{3,5}[\s\-]?\d{6,8})")
    _EMAIL_PATTERN = re.compile(r"([a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)")

    # --- Unit Sale Price normalization ---
    _USP_PATTERN = re.compile(
        r"(?:(?:Unit\s+Sale\s+Price|USP|U\.S\.P\.)[\s:]*)?(?:Rs\.?|₹|INR)?\s*(\d+(?:[.,]\d+)?)\s*(?:/|per)\s*(?:(\d+)\s*)?(g|kg|ml|l|litre|liter|pcs|piece|unit|item|no)",
        re.IGNORECASE
    )

    # --- PIN code normalization for address ---
    _PINCODE_PATTERN = re.compile(r"\b([1-9][0-9]{2}\s?[0-9]{3})\b")

    # --- FSSAI license 14-digit pattern ---
    _FSSAI_PATTERN = re.compile(r"(?:fssai|lic\.?\s*(?:no\.?|number))?[\s:]*([12]\d{13})\b", re.IGNORECASE)

    @staticmethod
    def validate_usp_consistency(
        mrp_amount: float, net_qty_val: float, net_qty_unit: str, usp_val: float, usp_unit: str
    ) -> Dict[str, Any]:
        """
        Verify if Unit Sale Price mathematically matches MRP / Net Qty under Rule 6(11).
        E.g. MRP ₹120 for 500g -> expected USP is ₹0.24 / g.
        """
        if mrp_amount <= 0 or net_qty_val <= 0 or usp_val <= 0:
            return {"verified": False, "consistent": True, "note": "Insufficient values for cross-check"}

        # Normalize quantity to base unit (grams / milliliters / pieces)
        qty_base = net_qty_val
        u_norm = net_qty_unit.lower().strip()
        if u_norm in ("kg", "l", "litre", "liter", "ltr"):
            qty_base = net_qty_val * 1000.0

        expected_per_base = mrp_amount / max(qty_base, 0.001)

        usp_base = usp_val
        usp_u_norm = usp_unit.lower().strip()
        if usp_u_norm in ("kg", "l", "litre", "liter", "ltr"):
            usp_base = usp_val / 1000.0

        discrepancy = abs(expected_per_base - usp_base) / max(expected_per_base, 0.001)
        is_consistent = discrepancy < 0.06  # 6% margin for packaging rounding

        return {
            "verified": True,
            "consistent": is_consistent,
            "expected_usp": round(expected_per_base, 4),
            "reported_usp": round(usp_base, 4),
            "discrepancy_pct": round(discrepancy * 100, 2),
        }

    def extract_fields(self, ocr_spans_by_region: Dict[str, List[dict]]) -> Dict[str, NormalizedField]:
        """
        Main extraction entry point.
        ocr_spans_by_region: {region_label: [OCRSpan-like dicts]}
        Returns: {canonical_field_name: NormalizedField}
        """
        extracted: Dict[str, NormalizedField] = {}

        for region_label, spans in ocr_spans_by_region.items():
            if not spans:
                continue

            # Canonicalize incoming region label
            canonical_name = FIELD_ALIASES.get(region_label, region_label)

            # Combine all spans in region into a single text block
            combined_text = " ".join(s.get("text", "") for s in spans).strip()
            if not combined_text:
                continue

            # Compute confidence: length-weighted average blended with top span confidence
            text_spans = [s for s in spans if s.get("text", "").strip()]
            total_chars = sum(len(s.get("text", "").strip()) for s in text_spans)
            if total_chars > 0:
                weighted_conf = sum(s.get("confidence", 0.5) * len(s.get("text", "").strip()) for s in text_spans) / total_chars
                max_conf = max((s.get("confidence", 0.0) for s in text_spans), default=0.0)
                field_confidence = round(max(weighted_conf, max_conf * 0.90), 4)
            else:
                field_confidence = 0.0

            first_bbox = spans[0].get("bbox", [0, 0, 0, 0])

            field = self._normalize_region(canonical_name, combined_text, field_confidence, first_bbox)
            if field:
                extracted[canonical_name] = field

        return extracted

    def _normalize_region(
        self,
        field_name: str,
        text: str,
        confidence: float,
        bbox: List[float],
    ) -> Optional[NormalizedField]:
        """Route canonical field name to the appropriate normalizer."""
        if field_name == "mrp":
            return self._normalize_mrp(text, confidence, bbox)
        elif field_name == "net_quantity":
            return self._normalize_net_quantity(text, confidence, bbox)
        elif field_name in ("date_of_manufacture", "date_declaration"):
            return self._normalize_date(text, confidence, bbox)
        elif field_name in ("consumer_care_contact", "consumer_care"):
            return self._normalize_consumer_care(text, confidence, bbox)
        elif field_name == "manufacturer_address":
            return self._normalize_address(field_name, text, confidence, bbox)
        elif field_name == "unit_sale_price":
            return self._normalize_unit_sale_price(text, confidence, bbox)
        else:
            # Generic text field (manufacturer_name, packer_name, country_of_origin, importer_name)
            return self._normalize_text_field(field_name, text, confidence, bbox)

    _MRP_STRUCTURAL_RE = re.compile(
        r"(?:M\.?R\.?P\b|mrp\b|maximum\s+retail|incl\b|inclusive"
        r"|of\s+all\b|all\s+tax|all\s+tak|tax(?:es)?\b"
        r"|of\s+all\s+tax|of\s+all\s+tak|incl\.?\s*of|\u20b9|\bRs\.?\b)",
        re.IGNORECASE
    )

    def _normalize_mrp(self, text: str, confidence: float, bbox: List[float]) -> NormalizedField:
        """Extract and normalize MRP value from OCR text."""
        normalized_value: float = 0.0
        match = self._MRP_PATTERN.search(text) or self._CURRENCY_PATTERN.search(text)
        if match:
            try:
                normalized_value = float(match.group(1).replace(",", "."))
            except (ValueError, IndexError):
                pass

        # Mark field as structurally present when MRP/currency keywords are in text,
        # even if the numeric value could not be parsed (blank-stamp package design).
        is_present = normalized_value > 0 or bool(self._MRP_STRUCTURAL_RE.search(text))

        return NormalizedField(
            field_name="mrp",
            raw_value=text,
            normalized_value={
                "value": text,
                "normalized_value": normalized_value,
                "currency": "INR",
                "present": is_present,
            },
            confidence=round(confidence, 4),
            bbox=bbox,
        )

    _NET_QTY_STRUCTURAL_RE = re.compile(
        r"(?:net\s+(?:wt|weight|qty|quantity|content|vol|volume)|gross\s+wt)",
        re.IGNORECASE
    )

    def _normalize_net_quantity(self, text: str, confidence: float, bbox: List[float]) -> NormalizedField:
        """Extract and normalize net quantity (value + unit) from OCR text."""
        norm_value: float = 0.0
        norm_unit: str = ""
        match = self._QTY_PATTERN.search(text)
        if match:
            try:
                norm_value = float(match.group(1).replace(",", "."))
                raw_unit = match.group(2).lower().rstrip(".")
                norm_unit = self._UNIT_MAP.get(raw_unit, raw_unit)
            except (ValueError, IndexError):
                pass

        # Mark structurally present when net qty label keywords found in text.
        is_present = (norm_value > 0 and bool(norm_unit)) or bool(self._NET_QTY_STRUCTURAL_RE.search(text))

        return NormalizedField(
            field_name="net_quantity",
            raw_value=text,
            normalized_value={
                "value": text,
                "normalized_value": norm_value,
                "unit": norm_unit,
                "present": is_present,
            },
            confidence=round(confidence, 4),
            bbox=bbox,
        )

    def _normalize_date(self, text: str, confidence: float, bbox: List[float]) -> NormalizedField:
        """Extract month/year from date of manufacture text."""
        month: Optional[str] = None
        year: Optional[str] = None
        matches = self._DATE_PATTERN.findall(text)
        if matches:
            m, y = matches[0]
            month = m.zfill(2)
            year = y if len(y) == 4 else f"20{y}"
        else:
            text_match = self._DATE_TEXT_PATTERN.search(text)
            if text_match:
                y = text_match.group(1)
                year = y if len(y) == 4 else f"20{y}"

        return NormalizedField(
            field_name="date_of_manufacture",
            raw_value=text,
            normalized_value={
                "value": text,
                "month": month,
                "year": year,
                "present": bool(year or month),
            },
            confidence=round(confidence, 4),
            bbox=bbox,
        )

    def _normalize_consumer_care(self, text: str, confidence: float, bbox: List[float]) -> NormalizedField:
        """Extract phone and email from consumer care contact text."""
        phone_match = self._PHONE_PATTERN.search(text)
        email_match = self._EMAIL_PATTERN.search(text)

        phone = phone_match.group(0).strip() if phone_match else None
        email = email_match.group(0).strip() if email_match else None
        is_present = bool(text.strip()) and (bool(phone) or bool(email) or len(text.strip()) >= 8)

        return NormalizedField(
            field_name="consumer_care_contact",
            raw_value=text,
            normalized_value={
                "value": text.strip(),
                "phone": phone,
                "email": email,
                "present": is_present,
            },
            confidence=round(confidence, 4),
            bbox=bbox,
        )

    def _normalize_address(
        self, field_name: str, text: str, confidence: float, bbox: List[float]
    ) -> NormalizedField:
        """Extract and normalize physical address details."""
        stripped = text.strip()
        pincode_match = self._PINCODE_PATTERN.search(stripped)
        pincode = pincode_match.group(1).replace(" ", "") if pincode_match else None

        return NormalizedField(
            field_name=field_name,
            raw_value=text,
            normalized_value={
                "value": stripped,
                "pincode": pincode,
                "present": len(stripped) >= 10,
            },
            confidence=round(confidence, 4),
            bbox=bbox,
        )

    def _normalize_unit_sale_price(self, text: str, confidence: float, bbox: List[float]) -> NormalizedField:
        """Extract unit sale price per gram/kg/ml/l/unit."""
        price_val: float = 0.0
        unit: str = ""
        match = self._USP_PATTERN.search(text)
        if match:
            try:
                price_val = float(match.group(1).replace(",", "."))
                raw_unit = match.group(3).lower().rstrip(".")
                multiplier = float(match.group(2)) if match.group(2) else 1.0
                unit = f"{int(multiplier)}{raw_unit}" if multiplier > 1 else raw_unit
            except (ValueError, IndexError):
                pass

        return NormalizedField(
            field_name="unit_sale_price",
            raw_value=text,
            normalized_value={
                "value": text.strip(),
                "normalized_value": price_val,
                "unit": unit,
                "currency": "INR",
                "present": price_val > 0,
            },
            confidence=round(confidence, 4),
            bbox=bbox,
        )

    def _normalize_text_field(
        self, field_name: str, text: str, confidence: float, bbox: List[float]
    ) -> NormalizedField:
        """Generic text field (manufacturer_name, packer_name, etc.)."""
        stripped = text.strip()
        return NormalizedField(
            field_name=field_name,
            raw_value=text,
            normalized_value={
                "value": stripped,
                "present": len(stripped) >= 3,
            },
            confidence=round(confidence, 4),
            bbox=bbox,
        )
