"""Multilingual OCR Engine (PRD Section 9.D).

Architecture:
- Production mode (settings.DEMO_MODE=False or use_real_model=True):
  Uses EasyOCR (English + Hindi) to extract text strictly from detector crops.
  Preserves empty results if no text is found, tracks OCR confidence, records
  engine version and languages, and never substitutes mock values.
- Demo mode (settings.DEMO_MODE=True and use_real_model=False):
  Returns structured realistic mock OCR text per region label.
"""

import logging
from typing import Any, Dict, List, Optional, Tuple

from pydantic import BaseModel

from app.core.config import settings

logger = logging.getLogger(__name__)


class OCRSpan(BaseModel):
    text: str
    confidence: float
    bbox: List[float]   # [x1, y1, x2, y2] in pixel coordinates within the region crop
    language: str = "en"
    engine_version: str = "easyocr-1.7.1"


# Canonical mock data per region label — ONLY used when settings.DEMO_MODE is True
_MOCK_OCR_DATA: Dict[str, List[dict]] = {
    "mrp": [
        {"text": "M.R.P.: ₹ 120.00 (Incl. of all taxes)", "confidence": 0.97, "bbox": [0, 0, 300, 25], "language": "en"}
    ],
    "net_quantity": [
        {"text": "Net Qty: 500 g", "confidence": 0.98, "bbox": [0, 0, 200, 25], "language": "en"}
    ],
    "manufacturer_name": [
        {"text": "Manufactured by: Bharat Foods Pvt. Ltd.", "confidence": 0.94, "bbox": [0, 0, 450, 25], "language": "en"}
    ],
    "manufacturer_address": [
        {"text": "12 Industrial Area, Hadapsar, Pune - 411001, Maharashtra, India", "confidence": 0.92, "bbox": [0, 0, 550, 25], "language": "en"}
    ],
    "packer_name": [
        {"text": "Packed by: Bharat Foods Pvt. Ltd., Pune", "confidence": 0.91, "bbox": [0, 0, 350, 25], "language": "en"}
    ],
    "consumer_care_contact": [
        {"text": "Consumer Care: 1800-209-1234 | care@bharatfoods.in", "confidence": 0.89, "bbox": [0, 0, 400, 25], "language": "en"}
    ],
    "date_of_manufacture": [
        {"text": "Mfg. Date: 08/2026  Best Before: 08/2027", "confidence": 0.96, "bbox": [0, 0, 280, 25], "language": "en"}
    ],
    "country_of_origin": [
        {"text": "Country of Origin: India", "confidence": 0.93, "bbox": [0, 0, 180, 25], "language": "en"}
    ],
    "unit_sale_price": [
        {"text": "Unit Sale Price: ₹ 0.24 / g", "confidence": 0.90, "bbox": [0, 0, 220, 25], "language": "en"}
    ],
    "importer_name": [
        {"text": "", "confidence": 0.0, "bbox": [0, 0, 0, 0], "language": "en"}
    ],
}


class OCREngine:
    """
    Optical Character Recognition engine interface.
    - Production: Runs EasyOCR on crops only. Never substitutes mock text.
    - Demo mode: Only allowed if settings.DEMO_MODE is True.
    """

    # Class-level EasyOCR reader singleton (expensive to initialize, share across calls)
    _reader: Any = None
    _reader_initialized: bool = False
    _init_error: Optional[str] = None
    _engine_version: str = "easyocr-1.7.1"

    def __init__(
        self,
        languages: Optional[List[str]] = None,
        use_real_model: Optional[bool] = None,
    ):
        self.languages = languages or getattr(settings, "OCR_LANGUAGES", ["en"])
        if use_real_model is not None:
            self.use_real_model = use_real_model
        else:
            self.use_real_model = settings.USE_REAL_MODELS or not settings.DEMO_MODE

        self.last_error: Optional[str] = None

        if self.use_real_model:
            self._ensure_reader_initialized(self.languages)

    @classmethod
    def _ensure_reader_initialized(cls, languages: List[str]) -> None:
        """Lazy-initialize the EasyOCR reader exactly once per process."""
        if cls._reader_initialized:
            return
        cls._reader_initialized = True
        try:
            import easyocr  # type: ignore
            logger.info(f"Initializing EasyOCR reader with languages {languages}…")
            cls._reader = easyocr.Reader(languages, gpu=False, verbose=False)
            logger.info("EasyOCR reader initialized successfully.")
            cls._init_error = None
        except ImportError:
            cls._init_error = "easyocr dependency not installed. Install requirements-ai.txt."
            logger.error(cls._init_error)
        except Exception as exc:
            cls._init_error = f"Failed to initialize EasyOCR: {exc}"
            logger.error(cls._init_error, exc_info=True)

    @classmethod
    def verify_ocr_readiness(cls) -> Tuple[bool, Optional[str]]:
        """Verify that EasyOCR is initialized and functional."""
        cls._ensure_reader_initialized(getattr(settings, "OCR_LANGUAGES", ["en"]))
        if cls._init_error:
            return False, cls._init_error
        if cls._reader is None:
            return False, "EasyOCR reader not loaded"
        return True, None

    def extract_text(self, cropped_image_bytes: bytes, region_label: str = "") -> List[OCRSpan]:
        """
        Extract text spans from a cropped region image.
        In production mode (DEMO_MODE=False), preserves empty results and never substitutes mock text.
        """
        spans, _ = self.extract_text_with_status(cropped_image_bytes, region_label)
        return spans

    def extract_text_with_status(
        self, cropped_image_bytes: bytes, region_label: str = ""
    ) -> Tuple[List[OCRSpan], Optional[str]]:
        """
        Extract text from crop with structured status / error message.
        """
        if self.use_real_model:
            if self.__class__._init_error or self.__class__._reader is None:
                err = self.__class__._init_error or "OCR reader unavailable"
                self.last_error = err
                logger.error(f"Cannot run real OCR: {err}")
                return [], err

            return self._run_real_ocr(cropped_image_bytes)

        # Demo mode path: strictly requires settings.DEMO_MODE=True
        if settings.DEMO_MODE:
            logger.info(f"DEMO_MODE active: returning mock OCR for region '{region_label}'.")
            mock_spans = _MOCK_OCR_DATA.get(region_label, [])
            return [OCRSpan(**span) for span in mock_spans], None

        err = "Real models disabled and DEMO_MODE=False. No OCR results."
        self.last_error = err
        return [], err

    def _preprocess_crop(self, img_bgr: Any) -> Any:
        """
        Preprocess crop for enhanced OCR accuracy:
        - Check minimum dimensions and upscale small text
        - Contrast enhancement via CLAHE on the L channel of LAB
        - Unsharp masking to crisp packaging fonts
        """
        import cv2

        h, w = img_bgr.shape[:2]
        # If crop is small, scale up with cubic interpolation to aid OCR
        if h < 48 or w < 80:
            scale = max(48.0 / max(h, 1), 80.0 / max(w, 1))
            if scale > 1.0:
                img_bgr = cv2.resize(img_bgr, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_CUBIC)

        # Convert to LAB to apply CLAHE to the L channel
        lab = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2LAB)
        l, a, b = cv2.split(lab)
        clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))
        cl = clahe.apply(l)
        enhanced_lab = cv2.merge((cl, a, b))
        enhanced_bgr = cv2.cvtColor(enhanced_lab, cv2.COLOR_LAB2BGR)

        # Unsharp mask to restore edge crispness on packaging fonts
        gaussian = cv2.GaussianBlur(enhanced_bgr, (0, 0), 2.0)
        sharpened = cv2.addWeighted(enhanced_bgr, 1.4, gaussian, -0.4, 0)
        return sharpened

    def _clean_ocr_text(self, text: str) -> str:
        """Clean and normalize OCR text artifacts common in Indian packaging."""
        import re

        cleaned = text.strip()
        # Common EasyOCR misread: '?' or '₹' read as '?' before digits
        cleaned = re.sub(r"^\?\s*(\d)", r"₹ \1", cleaned)
        # Fix common dot-matrix date artifacts like 'Pkd:' or 'Mfg:'
        cleaned = re.sub(r"\bM[fF][gG][\.,:]?", "Mfg:", cleaned)
        cleaned = re.sub(r"\bP[kK][dD][\.,:]?", "PKD:", cleaned)
        cleaned = re.sub(r"\bM\.?R\.?P\.?[\.,:]?", "M.R.P.:", cleaned)
        return cleaned

    def _run_real_ocr(self, image_bytes: bytes) -> Tuple[List[OCRSpan], Optional[str]]:
        """
        Run EasyOCR inference on cropped image bytes.
        If first pass returns 0 spans, applies adaptive thresholding pass
        specifically for dot-matrix packaging prints (manufacturing dates / batch stamps).
        Returns Tuple[List[OCRSpan], Optional[str]].
        """
        try:
            import cv2
            import numpy as np

            if not image_bytes or len(image_bytes) == 0:
                return [], "Empty image bytes provided for OCR"

            # Decode bytes to numpy array
            np_arr = np.frombuffer(image_bytes, np.uint8)
            img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
            if img is None:
                err = "Failed to decode crop bytes for OCR"
                logger.error(err)
                return [], err

            h, w = img.shape[:2]
            if h < 6 or w < 6:
                return [], f"Crop dimensions too small for OCR ({w}x{h})"

            preprocessed_img = self._preprocess_crop(img)
            reader = self.__class__._reader

            # Pass 1: standard CLAHE + unsharp mask
            raw_results = reader.readtext(preprocessed_img, detail=1, paragraph=False)

            # Pass 2: if Pass 1 yielded 0 results, try adaptive Gaussian binarization
            # (crucial for dot-matrix printed batch codes & faint expiry dates)
            if not raw_results:
                gray = cv2.cvtColor(preprocessed_img, cv2.COLOR_BGR2GRAY)
                thresh = cv2.adaptiveThreshold(
                    gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 15, 4
                )
                raw_results = reader.readtext(thresh, detail=1, paragraph=False)

            spans: List[OCRSpan] = []
            for item in raw_results:
                if len(item) < 3:
                    continue
                bbox_points, text, confidence = item[0], item[1], item[2]
                cleaned_text = self._clean_ocr_text(text)
                if not cleaned_text:
                    continue

                # Convert quad bbox to flat [x1, y1, x2, y2]
                xs = [p[0] for p in bbox_points]
                ys = [p[1] for p in bbox_points]
                x1, y1 = max(0.0, float(min(xs))), max(0.0, float(min(ys)))
                x2, y2 = float(max(xs)), float(max(ys))

                spans.append(
                    OCRSpan(
                        text=cleaned_text,
                        confidence=round(float(confidence), 4),
                        bbox=[x1, y1, x2, y2],
                        language="en",
                        engine_version=self.__class__._engine_version,
                    )
                )

            return spans, None

        except Exception as exc:
            err = f"EasyOCR inference failed: {exc}"
            logger.error(err, exc_info=True)
            return [], err
