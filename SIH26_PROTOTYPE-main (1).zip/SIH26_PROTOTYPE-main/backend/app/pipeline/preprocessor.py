"""Image Preprocessing Pipeline (PRD Section 9.B) — OpenCV-based.

Advanced CV Preconditioning for Packaged Commodity Labels:
1. Glare & Specular Reflection Suppression (for glossy/plastic packaging)
2. Bilateral Edge-Preserving Denoising
3. Perspective / Skew & Orientation Correction
4. Adaptive CLAHE Contrast Enhancement
"""

from typing import Optional, Tuple
import cv2
import numpy as np


class ImagePreprocessor:
    """
    Applies preprocessing stages to improve OCR and detection accuracy.
    Original bytes are NEVER modified — this always returns a new processed copy.
    """

    def preprocess(self, image_bytes: bytes) -> Tuple[Optional[bytes], dict]:
        """
        Full preprocessing pipeline:
        1. Glare / Specular reflection reduction
        2. Bilateral edge-preserving filtering
        3. Perspective/skew correction
        4. Contrast enhancement (CLAHE on LAB color space)
        5. Re-encode to JPEG bytes
        Returns (processed_bytes, meta) where meta records each applied operation.
        """
        meta: dict = {"operations": []}

        np_arr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        if img is None:
            return None, {"error": "Could not decode image for preprocessing"}

        h, w = img.shape[:2]

        # 1. Specular Glare Reduction (for glossy wrappers/foil packaging)
        try:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            # Find specular highlight areas (very bright spots with low saturation)
            hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
            s_ch = hsv[:, :, 1]
            v_ch = hsv[:, :, 2]
            glare_mask = cv2.inRange(v_ch, 230, 255) & cv2.inRange(s_ch, 0, 50)
            glare_pixels = int(cv2.countNonZero(glare_mask))
            if 0 < glare_pixels < (h * w * 0.15):  # only inpaint if modest glare, not whole white bg
                kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
                glare_mask = cv2.dilate(glare_mask, kernel, iterations=1)
                img = cv2.inpaint(img, glare_mask, 3, cv2.INPAINT_TELEA)
                meta["operations"].append("glare_suppression")
        except Exception:
            pass

        # 2. Bilateral edge-preserving smoothing (cleans texture noise while preserving sharp font edges)
        try:
            img = cv2.bilateralFilter(img, d=7, sigmaColor=50, sigmaSpace=50)
            meta["operations"].append("bilateral_filter")
        except Exception:
            img = cv2.fastNlMeansDenoisingColored(img, None, h=8, hColor=8, templateWindowSize=7, searchWindowSize=21)
            meta["operations"].append("denoising")

        # 3. Skew / Rotation correction — detect dominant angle via Hough lines
        try:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            edges = cv2.Canny(gray, 50, 150, apertureSize=3)
            lines = cv2.HoughLinesP(edges, 1, np.pi / 180, threshold=80, minLineLength=100, maxLineGap=10)
            if lines is not None:
                lines = lines.reshape(-1, 4)
                angles = []
                for x1, y1, x2, y2 in lines:
                    if x2 - x1 != 0:
                        angle = float(np.degrees(np.arctan2(y2 - y1, x2 - x1)))
                        if -45 < angle < 45:
                            angles.append(angle)
                if angles:
                    median_angle = float(np.median(angles))
                    if abs(median_angle) > 0.5:
                        M = cv2.getRotationMatrix2D((w / 2, h / 2), median_angle, 1.0)
                        img = cv2.warpAffine(img, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)
                        meta["operations"].append(f"deskew:{median_angle:.2f}deg")
        except Exception:
            pass

        # 4. CLAHE contrast enhancement on L channel of LAB color space
        try:
            lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
            l_ch, a_ch, b_ch = cv2.split(lab)
            clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))
            l_ch = clahe.apply(l_ch)
            img = cv2.cvtColor(cv2.merge([l_ch, a_ch, b_ch]), cv2.COLOR_LAB2BGR)
            meta["operations"].append("clahe_contrast")
        except Exception:
            pass

        # Re-encode to JPEG bytes
        success, buffer = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 94])
        if not success:
            return None, {"error": "Failed to re-encode processed image"}

        meta["success"] = True
        return bytes(buffer), meta

