"""Image Quality Assessment using OpenCV (PRD Section 9.A)."""

from typing import Any, Dict, List
import cv2
import numpy as np


class ImageQualityAssessor:
    """
    Assesses image quality for blur, low resolution, glare, and poor contrast.
    Outputs: {quality_score, issues: [...], passed: bool}
    """

    def __init__(self, min_quality_score: float = 0.65):
        self.min_quality_score = min_quality_score

    def assess(self, image_bytes: bytes, filename: str = "") -> Dict[str, Any]:
        """
        Assess image quality metrics using OpenCV.
        Returns composite quality score and list of detected issues.
        """
        issues: List[str] = []

        if not image_bytes:
            return {
                "quality_score": 0.0,
                "passed": False,
                "issues": ["Empty image file received."],
                "blur_detected": True,
                "glare_detected": False,
                "low_resolution": True,
                "skew_detected": False
            }

        # Decode image using OpenCV
        np_arr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

        if img is None:
            return {
                "quality_score": 0.0,
                "passed": False,
                "issues": ["Unable to decode image. Supported formats: JPEG, PNG."],
                "blur_detected": True,
                "glare_detected": False,
                "low_resolution": True,
                "skew_detected": False
            }

        h, w, _ = img.shape
        low_res = False
        blur_detected = False
        glare_detected = False

        # 1. Resolution Check
        if h < 480 or w < 480:
            low_res = True
            issues.append(f"Low resolution ({w}x{h} px). Minimum recommended is 720p.")

        # 2. Blur / Sharpness check via Laplacian Variance
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        lap_var = float(cv2.Laplacian(gray, cv2.CV_64F).var())
        if lap_var < 40.0:
            blur_detected = True
            issues.append(f"Image is blurry (sharpness score {lap_var:.1f}, threshold 40.0).")

        # 3. Specular Glare / Overexposure Check
        overexposed_ratio = float(np.sum(gray >= 252)) / float(gray.size)
        if overexposed_ratio > 0.08:
            glare_detected = True
            issues.append(f"Specular glare / reflections detected ({overexposed_ratio * 100:.1f}% overexposed area).")

        # Compute composite quality score (0.0 to 1.0)
        score = 1.0
        if low_res:
            score -= 0.25
        if blur_detected:
            score -= 0.35
        if glare_detected:
            score -= 0.20

        # Cap score between 0.1 and 0.98
        score = max(0.1, min(0.98, score))
        passed = score >= self.min_quality_score

        return {
            "quality_score": round(score, 2),
            "passed": passed,
            "issues": issues,
            "blur_detected": blur_detected,
            "glare_detected": glare_detected,
            "low_resolution": low_res,
            "skew_detected": False
        }
