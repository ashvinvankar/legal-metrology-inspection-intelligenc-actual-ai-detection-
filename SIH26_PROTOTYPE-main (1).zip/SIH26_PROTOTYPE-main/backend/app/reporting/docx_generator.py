"""DOCX Report Generator using python-docx (PRD Section 13)."""

import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT


_RESULT_COLORS = {
    "COMPLIANT": RGBColor(0x27, 0xAE, 0x60),
    "NON_COMPLIANT": RGBColor(0xE7, 0x4C, 0x3C),
    "NEEDS_REVIEW": RGBColor(0xF3, 0x9C, 0x12),
    "NOT_APPLICABLE": RGBColor(0x95, 0xA5, 0xA6),
}


class DOCXReportGenerator:

    def __init__(self, output_dir: str = "storage_data/reports"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def generate_inspection_docx(
        self,
        inspection_id: str,
        report_data: Dict[str, Any],
        qr_reference: Optional[str] = None,
    ) -> str:
        """Generate a DOCX compliance report. Returns path to saved file."""
        doc = Document()

        # Document title
        title = doc.add_heading("Legal Metrology Compliance Inspection Report", level=0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER

        subtitle = doc.add_paragraph("Directorate of Consumer Affairs — Department of Consumer Protection, GoI")
        subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
        subtitle.runs[0].font.size = Pt(10)

        doc.add_paragraph()

        # Summary table
        doc.add_heading("Inspection Summary", level=1)
        inspection = report_data.get("inspection", {})
        summary_tbl = doc.add_table(rows=1, cols=2)
        summary_tbl.style = "Table Grid"
        hdr = summary_tbl.rows[0].cells
        hdr[0].text = "Field"
        hdr[1].text = "Value"
        for run in hdr[0].paragraphs[0].runs:
            run.bold = True
        for run in hdr[1].paragraphs[0].runs:
            run.bold = True

        summary_rows = [
            ("Inspection ID", inspection_id),
            ("Product Name", inspection.get("product_name") or "—"),
            ("Category", inspection.get("category") or "Packaged Food"),
            ("Location", inspection.get("location") or "—"),
            ("Officer", inspection.get("officer_name") or "—"),
            ("Inspection Date", inspection.get("inspection_date") or datetime.utcnow().strftime("%d %b %Y")),
            ("Overall Result", inspection.get("overall_result") or "NEEDS_REVIEW"),
        ]
        for label, value in summary_rows:
            row = summary_tbl.add_row().cells
            row[0].text = label
            row[1].text = str(value)

        doc.add_paragraph()

        # Compliance findings
        doc.add_heading("Compliance Findings", level=1)
        findings = report_data.get("compliance_checks", [])
        if findings:
            f_tbl = doc.add_table(rows=1, cols=5)
            f_tbl.style = "Table Grid"
            hdrs = f_tbl.rows[0].cells
            for i, h in enumerate(["Rule Key", "Legal Reference", "Requirement", "Result", "Confidence"]):
                hdrs[i].text = h
                for run in hdrs[i].paragraphs[0].runs:
                    run.bold = True

            for check in findings:
                row = f_tbl.add_row().cells
                row[0].text = check.get("rule_key") or "—"
                row[1].text = (check.get("legal_reference") or "—")[:50]
                row[2].text = (check.get("requirement") or "—")[:100]
                result = check.get("result") or "NEEDS_REVIEW"
                row[3].text = result
                color = _RESULT_COLORS.get(result, RGBColor(0, 0, 0))
                for run in row[3].paragraphs[0].runs:
                    run.font.color.rgb = color
                conf = check.get("confidence")
                row[4].text = f"{conf:.0%}" if conf else "—"
        else:
            doc.add_paragraph("No compliance findings available.")

        doc.add_paragraph()

        # Violations
        violations = report_data.get("violations", [])
        if violations:
            doc.add_heading("Violations", level=1)
            for v in violations:
                p = doc.add_paragraph(style="List Bullet")
                run = p.add_run(f"[{v.get('severity', 'Major')}] {v.get('description', '')}")
                color = _RESULT_COLORS.get(
                    "NON_COMPLIANT" if v.get("severity") == "Critical" else "NEEDS_REVIEW",
                    RGBColor(0, 0, 0)
                )
                run.font.color.rgb = color

        # QR Reference
        if qr_reference:
            doc.add_paragraph()
            doc.add_heading("Digital Reference", level=1)
            doc.add_paragraph(f"QR Reference: {qr_reference}")
            doc.add_paragraph(
                f"Generated: {datetime.utcnow().strftime('%d %b %Y %H:%M UTC')}"
            )

        file_name = f"report_{inspection_id}_{uuid.uuid4()}.docx"
        output_path = self.output_dir / file_name
        doc.save(str(output_path))
        return str(output_path)
