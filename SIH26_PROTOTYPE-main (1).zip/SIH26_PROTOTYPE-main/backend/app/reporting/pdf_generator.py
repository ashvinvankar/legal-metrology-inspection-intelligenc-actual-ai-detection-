"""PDF Report Generator using ReportLab (PRD Section 13)."""

import io
import os
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm, cm
from reportlab.platypus import (
    BaseDocTemplate, Frame, PageTemplate,
    Paragraph, Spacer, Table, TableStyle, HRFlowable, KeepTogether,
)
from reportlab.graphics.barcode import qr
from reportlab.graphics.shapes import Drawing
from reportlab.graphics import renderPDF


# Color palette
HEADER_BG = colors.HexColor("#1B3A5C")
HEADER_FG = colors.white
COMPLIANT_COLOR = colors.HexColor("#27AE60")
NON_COMPLIANT_COLOR = colors.HexColor("#E74C3C")
NEEDS_REVIEW_COLOR = colors.HexColor("#F39C12")
NOT_APPLICABLE_COLOR = colors.HexColor("#95A5A6")
LIGHT_GRAY = colors.HexColor("#F8F9FA")
MID_GRAY = colors.HexColor("#DEE2E6")
TEXT_COLOR = colors.HexColor("#2C3E50")

PAGE_W, PAGE_H = A4


def _result_color(result: str) -> colors.Color:
    mapping = {
        "COMPLIANT": COMPLIANT_COLOR,
        "NON_COMPLIANT": NON_COMPLIANT_COLOR,
        "NEEDS_REVIEW": NEEDS_REVIEW_COLOR,
        "NOT_APPLICABLE": NOT_APPLICABLE_COLOR,
    }
    return mapping.get(result, TEXT_COLOR)


class PDFReportGenerator:

    def __init__(self, output_dir: str = "storage_data/reports"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def generate_inspection_pdf(
        self,
        inspection_id: str,
        report_data: Dict[str, Any],
        qr_reference: Optional[str] = None,
    ) -> str:
        """
        Generate a full compliance inspection PDF report.
        Returns the absolute file path of the generated PDF.
        """
        report_id = str(uuid.uuid4())
        file_name = f"report_{inspection_id}_{report_id}.pdf"
        output_path = self.output_dir / file_name

        styles = getSampleStyleSheet()
        h1 = ParagraphStyle("H1", parent=styles["Heading1"], textColor=HEADER_FG, fontSize=16, spaceAfter=4)
        h2 = ParagraphStyle("H2", parent=styles["Heading2"], textColor=TEXT_COLOR, fontSize=12, spaceBefore=12, spaceAfter=6)
        body = ParagraphStyle("Body", parent=styles["Normal"], textColor=TEXT_COLOR, fontSize=9, leading=13)
        small = ParagraphStyle("Small", parent=styles["Normal"], textColor=TEXT_COLOR, fontSize=8, leading=11)
        result_style = ParagraphStyle("Result", parent=styles["Normal"], fontSize=9, leading=11, alignment=1)

        def header_footer(canvas, doc):
            canvas.saveState()
            # Header band
            canvas.setFillColor(HEADER_BG)
            canvas.rect(0, PAGE_H - 30 * mm, PAGE_W, 30 * mm, fill=1, stroke=0)
            canvas.setFillColor(HEADER_FG)
            canvas.setFont("Helvetica-Bold", 14)
            canvas.drawString(15 * mm, PAGE_H - 18 * mm, "Legal Metrology Compliance Inspection Report")
            canvas.setFont("Helvetica", 9)
            canvas.drawString(15 * mm, PAGE_H - 26 * mm, "Directorate of Consumer Affairs — Department of Consumer Protection, GoI")
            # Footer band
            canvas.setFillColor(HEADER_BG)
            canvas.rect(0, 0, PAGE_W, 12 * mm, fill=1, stroke=0)
            canvas.setFillColor(HEADER_FG)
            canvas.setFont("Helvetica", 7.5)
            canvas.drawString(15 * mm, 4 * mm, f"Inspection ID: {inspection_id}  |  QR Reference: {qr_reference or 'N/A'}")
            canvas.drawRightString(PAGE_W - 15 * mm, 4 * mm, f"Page {doc.page}  |  Generated: {datetime.utcnow().strftime('%d %b %Y %H:%M UTC')}")
            canvas.restoreState()

        frame = Frame(15 * mm, 18 * mm, PAGE_W - 30 * mm, PAGE_H - 53 * mm, id="main")
        page_template = PageTemplate(id="main", frames=[frame], onPage=header_footer)
        doc = BaseDocTemplate(str(output_path), pagesize=A4, pageTemplates=[page_template])

        story = []

        # Summary Section
        inspection = report_data.get("inspection", {})
        overall_result = inspection.get("overall_result", "NEEDS_REVIEW")
        result_color = _result_color(overall_result)

        summary_data = [
            ["Field", "Value"],
            ["Inspection ID", inspection_id],
            ["Product Name", inspection.get("product_name") or "—"],
            ["Category", inspection.get("category") or "Packaged Food"],
            ["Inspection Location", inspection.get("location") or "—"],
            ["Officer", inspection.get("officer_name") or "—"],
            ["Inspection Date", inspection.get("inspection_date") or datetime.utcnow().strftime("%d %b %Y")],
            ["Overall Result", overall_result],
        ]
        summary_table = Table(
            summary_data,
            colWidths=[60 * mm, 110 * mm],
            style=TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), HEADER_BG),
                ("TEXTCOLOR", (0, 0), (-1, 0), HEADER_FG),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, 0), 9),
                ("BACKGROUND", (0, 1), (-1, -1), LIGHT_GRAY),
                ("ROWBACKGROUNDS", (0, 1), (-1, -2), [colors.white, LIGHT_GRAY]),
                ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                ("FONTSIZE", (0, 1), (-1, -1), 9),
                ("TEXTCOLOR", (0, -1), (-1, -1), result_color),
                ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
                ("GRID", (0, 0), (-1, -1), 0.5, MID_GRAY),
                ("ROWBACKGROUNDS", (0, 1), (-1, -2), [colors.white, LIGHT_GRAY]),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]),
        )
        story.append(Paragraph("Inspection Summary", h2))
        story.append(summary_table)
        story.append(Spacer(1, 8 * mm))

        # Compliance Findings Table
        story.append(Paragraph("Compliance Findings", h2))
        findings_header = ["Rule", "Legal Reference", "Requirement", "OCR Value", "Result", "Confidence"]
        findings_rows = [findings_header]
        for check in report_data.get("compliance_checks", []):
            result = check.get("result", "NEEDS_REVIEW")
            result_p = Paragraph(
                f'<font color="#{_result_color(result).hexval()[2:].upper()}">{result}</font>',
                result_style
            )
            confidence = check.get("confidence")
            conf_text = f"{confidence:.0%}" if confidence else "—"
            findings_rows.append([
                Paragraph(check.get("rule_key", "—"), small),
                Paragraph(check.get("legal_reference", "—"), small),
                Paragraph((check.get("requirement") or "—")[:120], small),
                Paragraph((check.get("detected_value") or "—")[:80], small),
                result_p,
                conf_text,
            ])

        if len(findings_rows) > 1:
            findings_table = Table(
                findings_rows,
                colWidths=[28 * mm, 30 * mm, 45 * mm, 35 * mm, 22 * mm, 15 * mm],
                style=TableStyle([
                    ("BACKGROUND", (0, 0), (-1, 0), HEADER_BG),
                    ("TEXTCOLOR", (0, 0), (-1, 0), HEADER_FG),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 8),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT_GRAY]),
                    ("FONTNAME", (0, 1), (-1, -1), "Helvetica"),
                    ("FONTSIZE", (0, 1), (-1, -1), 8),
                    ("GRID", (0, 0), (-1, -1), 0.3, MID_GRAY),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("TOPPADDING", (0, 0), (-1, -1), 4),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ]),
            )
            story.append(findings_table)
        else:
            story.append(Paragraph("No compliance findings available. Run the analysis pipeline first.", body))

        story.append(Spacer(1, 8 * mm))

        # Violations Section
        violations = report_data.get("violations", [])
        if violations:
            story.append(Paragraph("Violation Details", h2))
            for v in violations:
                sev = v.get("severity", "Major")
                sev_color = NON_COMPLIANT_COLOR if sev == "Critical" else NEEDS_REVIEW_COLOR
                story.append(Paragraph(
                    f'<font color="#{sev_color.hexval()[2:].upper()}">● [{sev}]</font> {v.get("description", "")}',
                    body
                ))
                story.append(Spacer(1, 2 * mm))

        # Officer Review Notes
        officer_reviews = [c for c in report_data.get("compliance_checks", []) if c.get("officer_decision")]
        if officer_reviews:
            story.append(Spacer(1, 4 * mm))
            story.append(Paragraph("Officer Review Notes", h2))
            for rev in officer_reviews:
                decision_text = "✓ Confirmed" if rev.get("officer_decision") == "confirmed" else "⚠ Overridden"
                story.append(Paragraph(
                    f"<b>{rev.get('rule_key', '—')}</b>: {decision_text}  |  "
                    f"Justification: {rev.get('override_justification') or 'N/A'}",
                    small
                ))
                story.append(Spacer(1, 1 * mm))

        # QR Code section
        if qr_reference:
            story.append(Spacer(1, 6 * mm))
            story.append(HRFlowable(width="100%", thickness=0.5, color=MID_GRAY))
            story.append(Spacer(1, 4 * mm))
            story.append(Paragraph("Digital Reference", h2))
            story.append(Paragraph(
                f"QR Reference Code: <b>{qr_reference}</b><br/>"
                "Scan to verify report authenticity on the SLM-CIP portal.",
                body
            ))

        doc.build(story)
        return str(output_path)
