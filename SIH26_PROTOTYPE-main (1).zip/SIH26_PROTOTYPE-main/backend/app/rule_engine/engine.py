"""Deterministic Versioned Legal Metrology Rule Engine (PRD Section 10).

Core Architecture Constraint (PRD Section 10):
  AI extracts evidence; the deterministic rule engine evaluates compliance.
  NO LLM or opaque model EVER decides compliance.
  Uncertainty ALWAYS routes to NEEDS_REVIEW, never to a hallucinated result.
"""

from typing import Any, Dict, List, Optional, Tuple
from app.rule_engine.schema import ComplianceState, EvaluationResult
from app.rule_engine.validator import FieldValidators


# Confidence thresholds (PRD Section 9.F)
HIGH_CONFIDENCE_THRESHOLD = 0.85
LOW_CONFIDENCE_THRESHOLD = 0.30


class RuleEngine:
    """
    Deterministic rule engine evaluating extracted evidence against versioned Legal Metrology rules.
    Outputs one of 4 states: COMPLIANT, NON_COMPLIANT, NEEDS_REVIEW, NOT_APPLICABLE.
    State transitions are fully deterministic and auditable.
    """

    def __init__(self, rules: List[Dict[str, Any]]):
        self.rules = rules

    def evaluate_inspection(
        self,
        extracted_fields: Dict[str, Dict[str, Any]],
        product_category: str = "ALL",
    ) -> List[EvaluationResult]:
        """
        Evaluate all applicable rules for an inspection given extracted fields and commodity category.
        Returns List[EvaluationResult] — one per applicable rule.
        """
        results: List[EvaluationResult] = []
        for rule in self.rules:
            res = self._evaluate_rule(rule, extracted_fields, product_category)
            results.append(res)
        return results

    def _evaluate_rule(
        self,
        rule: Dict[str, Any],
        extracted_fields: Dict[str, Dict[str, Any]],
        product_category: str,
    ) -> EvaluationResult:
        rule_key = rule.get("rule_key", "")
        version = rule.get("version", 1)
        legal_ref = rule.get("legal_reference", "")
        template = rule.get("explanation_template", "")
        validation_logic = rule.get("validation_logic", {})

        # ------------------------------------------------------------------ #
        # Stage 1: Applicability Check
        # ------------------------------------------------------------------ #
        applicability = rule.get("applicability_conditions", {})
        categories = applicability.get("categories", ["ALL"])
        if "ALL" not in categories and product_category not in categories:
            return EvaluationResult(
                rule_key=rule_key,
                rule_version=version,
                legal_reference=legal_ref,
                state=ComplianceState.NOT_APPLICABLE,
                explanation=f"Rule not applicable to commodity category '{product_category}'.",
            )

        # ------------------------------------------------------------------ #
        # Stage 2: Check for missing fields
        # ------------------------------------------------------------------ #
        required_fields = rule.get("input_fields", [])
        field_data: Dict[str, Optional[Dict[str, Any]]] = {
            f: extracted_fields.get(f) for f in required_fields
        }

        missing_fields = [f for f, v in field_data.items() if v is None]

        if missing_fields:
            return EvaluationResult(
                rule_key=rule_key,
                rule_version=version,
                legal_reference=legal_ref,
                state=ComplianceState.NON_COMPLIANT,
                confidence=1.0,
                violation_description=(
                    f"Mandatory declaration field(s) not detected on label: {', '.join(missing_fields)}."
                ),
                explanation=template or f"Required field(s) {missing_fields} absent. Non-compliant per {legal_ref}.",
                evidence_fields=required_fields,
            )

        # ------------------------------------------------------------------ #
        # Stage 3: Deterministic Field Validation
        # ------------------------------------------------------------------ #
        valid, violation_msg = self._run_field_validation(
            rule_key=rule_key,
            validation_logic=validation_logic,
            field_data=field_data,
        )

        low_confidence_fields = [
            f for f, v in field_data.items()
            if v is not None and float(v.get("confidence", 1.0)) < LOW_CONFIDENCE_THRESHOLD
        ]
        
        avg_confidence = sum(float(v.get("confidence", 1.0)) for v in field_data.values() if v) / max(len(field_data), 1)

        if valid is False:
            if low_confidence_fields:
                return EvaluationResult(
                    rule_key=rule_key,
                    rule_version=version,
                    legal_reference=legal_ref,
                    state=ComplianceState.NEEDS_REVIEW,
                    confidence=avg_confidence,
                    violation_description=f"Validation failed: {violation_msg} (Note: OCR confidence is low (<{LOW_CONFIDENCE_THRESHOLD}) for {', '.join(low_confidence_fields)}, which may have caused this failure)",
                    explanation="Validation failed, but low extraction confidence requires human verification to confirm.",
                    evidence_fields=required_fields,
                )
            
            return EvaluationResult(
                rule_key=rule_key,
                rule_version=version,
                legal_reference=legal_ref,
                state=ComplianceState.NON_COMPLIANT,
                confidence=avg_confidence,
                violation_description=violation_msg,
                explanation=template or f"Violation: {violation_msg} Non-compliant per {legal_ref}.",
                evidence_fields=required_fields,
            )

        if valid is None:
            # Validator returned ambiguous — route to NEEDS_REVIEW
            return EvaluationResult(
                rule_key=rule_key,
                rule_version=version,
                legal_reference=legal_ref,
                state=ComplianceState.NEEDS_REVIEW,
                confidence=avg_confidence,
                violation_description=violation_msg,
                explanation=violation_msg or "Ambiguous result — officer review required.",
                evidence_fields=required_fields,
            )

        # ------------------------------------------------------------------ #
        # Stage 4: COMPLIANT — downgrade to NEEDS_REVIEW if any evidence field
        # has confidence below the medium threshold (0.60).
        # A field that passed validation but was read with low extraction confidence
        # requires human officer confirmation before being recorded as COMPLIANT.
        # ------------------------------------------------------------------ #
        low_confidence_validated_fields = [
            f for f, v in field_data.items()
            if v is not None and float(v.get("confidence", 1.0)) < LOW_CONFIDENCE_THRESHOLD
        ]

        if low_confidence_validated_fields:
            return EvaluationResult(
                rule_key=rule_key,
                rule_version=version,
                legal_reference=legal_ref,
                state=ComplianceState.NEEDS_REVIEW,
                confidence=avg_confidence,
                violation_description=(
                    f"Field(s) passed validation but extracted with low confidence "
                    f"(< {LOW_CONFIDENCE_THRESHOLD}): "
                    f"{', '.join(low_confidence_validated_fields)}. Officer confirmation required."
                ),
                explanation="Extraction confidence is too low to automatically pass. Officer confirmation is required.",
                evidence_fields=required_fields,
            )

        return EvaluationResult(
            rule_key=rule_key,
            rule_version=version,
            legal_reference=legal_ref,
            state=ComplianceState.COMPLIANT,
            confidence=avg_confidence,
            explanation=template or f"All required declarations present and validated per {legal_ref}.",
            evidence_fields=required_fields,
        )

    def _run_field_validation(
        self,
        rule_key: str,
        validation_logic: Dict[str, Any],
        field_data: Dict[str, Optional[Dict[str, Any]]],
    ) -> Tuple[Optional[bool], Optional[str]]:
        """
        Route field validation to the correct deterministic validator.
        Matches canonical rule keys, validation logic types, and legacy aliases.
        Returns:
          (True, None) — valid
          (False, reason) — invalid / non-compliant
          (None, reason) — ambiguous, needs officer review
        """
        validator = validation_logic.get("validator")
        v_type = validation_logic.get("type")
        r_upper = rule_key.upper()

        def _get_field(name: str, alias: Optional[str] = None):
            d = field_data.get(name)
            if not d and alias:
                d = field_data.get(alias)
            d = d or {}
            raw = d.get("raw_value", "")
            norm = d.get("normalized_value")
            return raw, norm

        # 1. Maximum Retail Price (MRP)
        if (
            validator == "validate_mrp"
            or v_type == "field_presence_and_format"
            or "MRP" in r_upper
        ):
            raw, norm = _get_field("mrp")
            valid, reason = FieldValidators.validate_mrp(raw, norm)
            if valid:
                fmt_valid, fmt_reason = FieldValidators.validate_mrp_format(raw)
                if fmt_valid is None:
                    return None, fmt_reason
            return valid, reason

        # 2. Net Quantity
        elif (
            validator == "validate_net_quantity"
            or v_type == "field_presence_and_unit"
            or "NET_QUANTITY" in r_upper
        ):
            raw, norm = _get_field("net_quantity")
            return FieldValidators.validate_net_quantity(raw, norm)

        # 3. Date of Manufacture / Packing
        elif (
            validator == "validate_date"
            or v_type == "date_format"
            or "DATE" in r_upper
        ):
            raw, norm = _get_field("date_of_manufacture", "date_declaration")
            return FieldValidators.validate_date_declaration(raw, norm)

        # 4. Country of Origin
        elif (
            validator == "validate_country_of_origin"
            or "COUNTRY_OF_ORIGIN" in r_upper
            or (v_type == "field_presence" and "country_of_origin" in validation_logic.get("field", ""))
        ):
            raw, norm = _get_field("country_of_origin")
            return FieldValidators.validate_country_of_origin(raw, norm)

        # 5. Manufacturer / Packer Details (Name + Address)
        elif (
            validator in ("validate_manufacturer", "validate_packer")
            or v_type == "entity_presence"
            or "MANUFACTURER" in r_upper
            or "PACKER" in r_upper
        ):
            m_raw, m_norm = _get_field("manufacturer_name", "packer_name")
            a_raw, a_norm = _get_field("manufacturer_address")
            return FieldValidators.validate_entity_details(m_raw, m_norm, a_raw, a_norm)

        # 6. Consumer Care Contact Details
        elif (
            validator == "validate_consumer_care"
            or v_type == "contact_details"
            or "CONSUMER_CARE" in r_upper
        ):
            raw, norm = _get_field("consumer_care_contact", "consumer_care")
            return FieldValidators.validate_consumer_care_contact(raw, norm)

        # 7. Unit Sale Price (USP)
        elif (
            validator == "validate_unit_sale_price"
            or v_type == "unit_sale_price_check"
            or "UNIT_SALE_PRICE" in r_upper
        ):
            raw, norm = _get_field("unit_sale_price")
            _, qty_norm = _get_field("net_quantity")
            return FieldValidators.validate_unit_sale_price(raw, norm, qty_norm)

        # 8. Importer Name
        elif validator == "validate_importer" or "IMPORTER" in r_upper:
            raw, norm = _get_field("importer_name")
            return FieldValidators.validate_text_presence("importer_name", raw, norm)

        # Fallback: generic presence validation across all required fields
        else:
            for field_name, fdata in field_data.items():
                raw = (fdata or {}).get("raw_value", "")
                norm = (fdata or {}).get("normalized_value")
                valid, reason = FieldValidators.validate_text_presence(field_name, raw, norm)
                if not valid:
                    return False, reason
            return True, None
