"""Rule Loader from JSON Seeds or Database."""

import json
from pathlib import Path
from typing import Any, Dict, List


class RuleLoader:
    @staticmethod
    def load_seed_rules() -> List[Dict[str, Any]]:
        """Load seed Legal Metrology rules from the project rules directory."""
        possible_paths = [
            Path("/app/rules/pc_rules_2011_v1.json"),
            Path("rules/pc_rules_2011_v1.json"),
            Path(__file__).resolve().parents[2] / "rules" / "pc_rules_2011_v1.json",
            Path(__file__).resolve().parents[3] / "rules" / "pc_rules_2011_v1.json",
        ]
        for p in possible_paths:
            if p.exists():
                with open(p, "r", encoding="utf-8") as f:
                    return json.load(f)
        return []
