"""Font Size and Readability Assessment (PRD Section 11)."""

from typing import Any, Dict, Optional


class ReadabilityEvaluator:
    """
    Evaluates font legibility across the 3 PRD modes:
    - Mode A: Calibrated with known package physical dimension
    - Mode B: Reference object (ruler, calibration card)
    - Mode C: Visual readability (default qualitative mode)
    """

    @staticmethod
    def evaluate_mode_c(ocr_confidence: float, char_height_px: float, image_quality_score: float) -> Dict[str, Any]:
        """
        Mode C - Visual Readability (Default).
        Explicitly produces a qualitative assessment, not a millimetre measurement.
        Routes numeric threshold rules to NEEDS_REVIEW.
        """
        score = (ocr_confidence * 0.5) + (min(char_height_px / 30.0, 1.0) * 0.3) + (image_quality_score * 0.2)
        rating = "Good" if score >= 0.8 else ("Fair" if score >= 0.6 else "Poor")

        return {
            "mode": "Mode C (Visual Readability)",
            "readability_score": round(score, 2),
            "qualitative_rating": rating,
            "requires_officer_review": rating != "Good",
            "disclaimer": "Physical font size in millimetres cannot be verified without physical calibration."
        }
