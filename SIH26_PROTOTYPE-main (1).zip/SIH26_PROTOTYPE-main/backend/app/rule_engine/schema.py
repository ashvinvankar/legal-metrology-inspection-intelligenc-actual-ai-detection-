"""Rule Engine Schema & Evaluation Result Types (PRD Section 10)."""

from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel


class ComplianceState(str, Enum):
    COMPLIANT = "COMPLIANT"
    NON_COMPLIANT = "NON_COMPLIANT"
    NEEDS_REVIEW = "NEEDS_REVIEW"
    NOT_APPLICABLE = "NOT_APPLICABLE"


class RuleSeverity(str, Enum):
    CRITICAL = "Critical"
    MAJOR = "Major"
    MINOR = "Minor"


class EvaluationResult(BaseModel):
    rule_key: str
    rule_version: int
    legal_reference: str
    state: ComplianceState
    confidence: Optional[float] = None
    violation_description: Optional[str] = None
    explanation: str
    evidence_fields: List[str] = []
    metadata: Dict[str, Any] = {}
