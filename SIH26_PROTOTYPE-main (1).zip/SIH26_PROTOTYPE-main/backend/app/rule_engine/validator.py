"""Deterministic Field Validators for Legal Metrology Declarations (PRD Section 10).

Each validator receives the raw OCR text and normalized structured value,
and returns (is_valid: Optional[bool], failure_reason: Optional[str]).
- is_valid = True: compliant
- is_valid = False: non-compliant (deterministic violation)
- is_valid = None: ambiguous / borderline -> routes to NEEDS_REVIEW
"""

import re
from typing import Any, Dict, List, Optional, Tuple


class FieldValidators:
    """
    Deterministic, verifiable validation functions for mandatory declarations.
    Each method is independently testable against known compliant/non-compliant fixtures.
    """

    # --- MRP Validation ---
    _MRP_NUMERIC_PATTERN = re.compile(r"\d+(?:[.,]\d+)?")
    _CURRENCY_MARKER = re.compile(r"(?:₹|\bRs\.?\b|\bINR\b)", re.IGNORECASE)

    # Keywords that structurally indicate an MRP field is present on the label.
    # Deliberately liberal — OCR frequently garbles '(INCL. OF ALL TAXES)' into
    # fragments like 'OF AlL TAKES)'. Matching any one fragment is sufficient
    # evidence that the MRP label is present on the package.
    _MRP_STRUCTURAL_KEYWORDS = re.compile(
        r"(?:M\.?R\.?P\b|mrp\b|maximum\s+retail|incl\b|inclusive"
        r"|of\s+all\b|all\s+tax|all\s+tak|tax(?:es)?\b"
        r"|of\s+all\s+tax|of\s+all\s+tak|incl\.?\s*of|\u20b9|\bRs\.?\b)",
        re.IGNORECASE
    )

    @staticmethod
    def validate_mrp(raw_value: Optional[str], normalized: Optional[Dict[str, Any]]) -> Tuple[bool, Optional[str]]:
        """
        Validate Maximum Retail Price (MRP).
        Rules:
        - Must be present (non-empty)
        - Must include a currency marker (₹, Rs., INR)
        - Must have a numeric value > 0

        Returns None (NEEDS_REVIEW) when field structure is detectably present
        (label text, tax disclosure, or ₹ symbol found) but the numeric value is
        absent or unreadable — common on blank-stamp package designs.
        """
        if not raw_value and not normalized:
            return False, "MRP declaration not found on package."

        text = raw_value or ""

        # Check currency marker
        has_currency = bool(FieldValidators._CURRENCY_MARKER.search(text))

        if not has_currency:
            # Before failing as NON_COMPLIANT, check whether the MRP field is
            # structurally present (label text or tax-disclosure found) but the
            # numeric value is blank/unstamped (e.g. blank-stamp package design).
            # In that case, a human officer must verify from the physical label.
            if FieldValidators._MRP_STRUCTURAL_KEYWORDS.search(text):
                return None, (
                    f"MRP field structure detected but currency marker (₹, Rs., INR) and "
                    f"numeric value not found in OCR output. The value may be blank-stamped "
                    f"or unreadable. Officer must verify from physical label. "
                    f"Raw OCR: '{text[:80]}'"
                )
            return False, f"MRP field is missing a currency marker (₹, Rs., INR). Found: '{text[:80]}'"

        # Check numeric value
        norm_val = normalized.get("normalized_value") if normalized else None
        if norm_val is not None:
            try:
                if float(norm_val) <= 0:
                    # ₹ symbol found but value is zero — could be blank-stamp field.
                    # Only treat as NEEDS_REVIEW when we have structural evidence that
                    # an MRP field exists; otherwise fall through to numeric check below.
                    if FieldValidators._MRP_STRUCTURAL_KEYWORDS.search(text):
                        nums = FieldValidators._MRP_NUMERIC_PATTERN.findall(text)
                        if not nums:
                            return None, (
                                "MRP currency marker found but numeric value is absent or unstamped. "
                                "Officer must verify the actual MRP from the physical label."
                            )
                    return False, f"Declared MRP value must be greater than zero. Found: {norm_val}"
            except (TypeError, ValueError):
                pass
        else:
            # Fallback: try to find any number in raw text
            nums = FieldValidators._MRP_NUMERIC_PATTERN.findall(text)
            if not nums:
                if FieldValidators._MRP_STRUCTURAL_KEYWORDS.search(text):
                    # Currency marker + MRP structure found but no number — blank-stamp
                    return None, (
                        "MRP currency marker found but numeric value is absent or unstamped. "
                        "Officer must verify the actual MRP from the physical label."
                    )
                return False, f"No numeric MRP value found in field text: '{text[:80]}'"
            if float(nums[0].replace(",", ".")) <= 0:
                return False, "MRP value must be greater than zero."

        return True, None

    # --- Net Quantity Validation ---
    _LEGAL_UNITS = {"g", "kg", "ml", "l", "litre", "liter", "m", "cm", "mm", "pcs", "pieces", "units", "nos", "no", "piece", "unit", "n"}

    # Keywords that structurally indicate a Net Quantity field is present on the label
    _NET_QTY_STRUCTURAL_KEYWORDS = re.compile(
        r"(?:net\s+(?:wt|weight|qty|quantity|content|vol|volume)|gross\s+wt)",
        re.IGNORECASE
    )

    @staticmethod
    def validate_net_quantity(raw_value: Optional[str], normalized: Optional[Dict[str, Any]]) -> Tuple[bool, Optional[str]]:
        """
        Validate Net Quantity declaration.
        Rules:
        - Must be present
        - Must have a unit from the legal SI unit set
        - Must have a numeric value > 0

        Returns None (NEEDS_REVIEW) when a qty-label keyword is present but value
        is blank/unstamped (blank-stamp package design).
        """
        if not raw_value and not normalized:
            return False, "Net quantity declaration not found on package."

        unit = (normalized.get("unit") or "").lower().strip(".") if normalized else ""
        norm_val = normalized.get("normalized_value") if normalized else None

        if not unit:
            text = raw_value or ""
            # If a net-quantity label keyword is present, field structure exists;
            # the numeric value is simply blank or unreadable → NEEDS_REVIEW.
            if FieldValidators._NET_QTY_STRUCTURAL_KEYWORDS.search(text):
                return None, (
                    "Net quantity field label detected but numeric value and unit are absent or "
                    "unreadable in OCR output. The value may be blank-stamped. "
                    f"Officer must verify from physical label. Raw OCR: '{text[:80]}'"
                )
            return False, f"Net quantity unit not found or not recognized. Verify with officer. Raw: '{text[:80]}'"

        if unit not in FieldValidators._LEGAL_UNITS:
            return False, f"Net quantity unit '{unit}' is not a recognized legal metrology standard unit."

        if norm_val is not None:
            try:
                if float(norm_val) <= 0:
                    return False, f"Net quantity value must be greater than zero. Found: {norm_val}"
            except (TypeError, ValueError):
                pass

        return True, None

    # --- Date of Manufacture Validation ---
    # Keywords that structurally indicate a date field is present on the label
    _DATE_STRUCTURAL_KEYWORDS = re.compile(
        r"(?:mfg\.?|mfg\s+date|manufacture|manufactured|pkd\.?|packed|packing\s+date|expiry|expir|best\s+before|b\.?b\.?|best\s+by|best\s+before\s+use)",
        re.IGNORECASE
    )

    @staticmethod
    def validate_date_declaration(raw_value: Optional[str], normalized: Optional[Dict[str, Any]]) -> Tuple[bool, Optional[str]]:
        """
        Validate Month and Year of manufacture / packing / import (PC Rules 2011 Rule 6(1)(d)).
        Rules:
        - Must be present
        - Must contain a recognizable month/year

        Returns None (NEEDS_REVIEW) when date-label keywords are present but no
        parseable date value exists — indicates a blank-stamp field.
        """
        if not raw_value and not normalized:
            return False, "Date of manufacture/packing/import not found on package."

        month = normalized.get("month") if normalized else None
        year = normalized.get("year") if normalized else None

        if not month and not year:
            text = raw_value or ""
            date_pattern = re.compile(r"\d{1,2}[/\-\.]\d{2,4}")
            if date_pattern.search(text):
                return True, None

            # Before failing as NON_COMPLIANT, check whether the date field is
            # structurally present (label keyword found) but the value is
            # blank/unstamped (e.g. OCR reads "PKD." or "EXPIRY DATE:" with no value).
            if FieldValidators._DATE_STRUCTURAL_KEYWORDS.search(text):
                return None, (
                    "Date field label detected but no parseable date (MM/YYYY or similar) "
                    "found in OCR output. The value may be blank-stamped or unreadable. "
                    f"Officer must verify manufacture/packing date from physical label. "
                    f"Raw OCR: '{text[:80]}'"
                )

            return False, f"No parseable date (MM/YYYY) found in date declaration field. Raw: '{text[:80]}'"

        if year:
            try:
                y = int(year)
                if y < 2000 or y > 2040:
                    return False, f"Date year {y} seems implausible. Officer review required."
            except ValueError:
                pass

        return True, None

    # --- Country of Origin Validation ---
    @staticmethod
    def validate_country_of_origin(raw_value: Optional[str], normalized: Optional[Dict[str, Any]]) -> Tuple[bool, Optional[str]]:
        """Country of Origin must be present and non-empty."""
        text = (normalized.get("value") or raw_value or "").strip() if normalized else (raw_value or "").strip()
        if not text:
            return False, "Country of origin declaration not found on package."
        if len(text) < 2:
            return False, f"Country of origin value too short to be valid: '{text}'"
        return True, None

    # --- Consumer Care Contact Validation ---
    _CONTACT_PHONE_RE = re.compile(r"(?:1800[\s\-]?\d{3}[\s\-]?\d{3,4}|(?:\+?91[\s\-]?)?[6-9]\d{4}[\s\-]?\d{5}|\d{3,5}[\s\-]?\d{6,8})")
    _CONTACT_EMAIL_RE = re.compile(r"([a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)")

    @staticmethod
    def validate_consumer_care_contact(raw_value: Optional[str], normalized: Optional[Dict[str, Any]]) -> Tuple[bool, Optional[str]]:
        """
        Consumer care cell details must include contact channel (telephone or email or postal address).
        """
        if not raw_value and not normalized:
            return False, "Consumer care contact declaration not found on package."

        text = (normalized.get("value") or raw_value or "").strip() if normalized else (raw_value or "").strip()
        phone = normalized.get("phone") if normalized else None
        email = normalized.get("email") if normalized else None

        if phone or email:
            return True, None

        # Check raw text for channels
        if FieldValidators._CONTACT_PHONE_RE.search(text) or FieldValidators._CONTACT_EMAIL_RE.search(text):
            return True, None

        if len(text) >= 15:
            # Has descriptive contact text, pass with officer confirmation
            return True, None

        return False, f"Consumer care contact details missing phone or email channel. Found: '{text[:80]}'"

    # --- Manufacturer Address Validation ---
    @staticmethod
    def validate_manufacturer_address(raw_value: Optional[str], normalized: Optional[Dict[str, Any]]) -> Tuple[bool, Optional[str]]:
        """Complete physical address must be present for manufacturer/packer/importer."""
        if not raw_value and not normalized:
            return False, "Manufacturer/Packer address declaration not found on package."

        text = (normalized.get("value") or raw_value or "").strip() if normalized else (raw_value or "").strip()
        if not text or len(text) < 8:
            return False, f"Manufacturer address appears incomplete or illegible: '{text}'"

        return True, None

    # --- Entity Presence Validation (Name + Address) ---
    @staticmethod
    def validate_entity_details(
        name_raw: Optional[str],
        name_norm: Optional[Dict[str, Any]],
        addr_raw: Optional[str],
        addr_norm: Optional[Dict[str, Any]],
    ) -> Tuple[bool, Optional[str]]:
        """Verify presence of both manufacturer/packer name and physical address per Rule 6(1)(a)."""
        valid_name, name_err = FieldValidators.validate_text_presence("manufacturer_name", name_raw, name_norm, min_length=3)
        if not valid_name:
            return False, name_err

        # If address field is provided separately, validate it
        if addr_raw or addr_norm:
            valid_addr, addr_err = FieldValidators.validate_manufacturer_address(addr_raw, addr_norm)
            if not valid_addr:
                return False, addr_err

        return True, None

    # --- Unit Sale Price Validation ---
    @staticmethod
    def validate_unit_sale_price(
        raw_value: Optional[str],
        normalized: Optional[Dict[str, Any]],
        net_qty_normalized: Optional[Dict[str, Any]] = None,
    ) -> Tuple[bool, Optional[str]]:
        """
        Validate Unit Sale Price (USP) per Rule 6(11).
        Required if package quantity > 1 kg or 1 l.
        """
        # If net quantity is known and <= 1kg/1l, unit sale price is optional
        if net_qty_normalized:
            unit = (net_qty_normalized.get("unit") or "").lower()
            val = float(net_qty_normalized.get("normalized_value") or 0.0)
            if (unit == "g" and val <= 1000) or (unit == "ml" and val <= 1000) or (unit in ("pcs", "no", "piece") and val <= 1):
                # Below threshold: optional
                return True, None

        if not raw_value and not normalized:
            return False, "Unit Sale Price declaration not found on package where required by Rule 6(11)."

        norm_val = normalized.get("normalized_value") if normalized else None
        if norm_val is not None and float(norm_val) > 0:
            return True, None

        text = raw_value or ""
        if any(kw in text.lower() for kw in ["unit sale price", "usp", "per g", "per kg", "per ml", "per l"]):
            return True, None

        return False, f"Unit sale price value not parseable: '{text[:80]}'"

    # --- Text Presence Validation (generic) ---
    @staticmethod
    def validate_text_presence(
        field_name: str,
        raw_value: Optional[str],
        normalized: Optional[Dict[str, Any]],
        min_length: int = 3,
    ) -> Tuple[bool, Optional[str]]:
        """Generic text presence validator for names and declarations."""
        text = (normalized.get("value") or raw_value or "").strip() if normalized else (raw_value or "").strip()
        present = normalized.get("present", True) if normalized else True

        if not text or not present:
            return False, f"'{field_name}' declaration not found or illegible on package."
        if len(text) < min_length:
            return False, f"'{field_name}' value appears too short to be a valid declaration: '{text}'"
        return True, None

    # --- MRP Format Check ---
    @staticmethod
    def validate_mrp_format(raw_value: Optional[str]) -> Tuple[Optional[bool], Optional[str]]:
        """Check that MRP includes 'incl. of all taxes' or similar disclosure."""
        if not raw_value:
            return True, None
        text = raw_value.lower()
        if any(kw in text for kw in ["incl", "inclusive", "all taxes", "tax"]):
            return True, None
        return None, "MRP declaration may be missing tax-inclusive disclosure. Officer review recommended."
