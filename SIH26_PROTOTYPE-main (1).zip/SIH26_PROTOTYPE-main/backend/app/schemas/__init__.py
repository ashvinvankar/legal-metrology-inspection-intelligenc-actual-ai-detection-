"""Schemas package root."""

from app.schemas.auth import Token, LoginRequest, RefreshRequest, UserResponse, UserCreate
from app.schemas.inspection import InspectionCreate, InspectionUpdate, InspectionResponse
from app.schemas.image import ImageUploadResponse, ImageQualityResult
from app.schemas.vision import DetectedRegionDTO, OCRResultDTO, ExtractedFieldDTO, FieldCorrectionRequest
from app.schemas.rule import RuleCreate, RuleResponse, RuleVersionDTO
from app.schemas.compliance import ComplianceCheckDTO, ComplianceReviewRequest, ViolationDTO, EvidenceDTO
from app.schemas.report import ReportRequest, ReportResponse
from app.schemas.dashboard import DashboardSummary, ViolationCategoryBreakdown, ManufacturerTrend, DashboardTrendsResponse

__all__ = [
    "Token",
    "LoginRequest",
    "RefreshRequest",
    "UserResponse",
    "UserCreate",
    "InspectionCreate",
    "InspectionUpdate",
    "InspectionResponse",
    "ImageUploadResponse",
    "ImageQualityResult",
    "DetectedRegionDTO",
    "OCRResultDTO",
    "ExtractedFieldDTO",
    "FieldCorrectionRequest",
    "RuleCreate",
    "RuleResponse",
    "RuleVersionDTO",
    "ComplianceCheckDTO",
    "ComplianceReviewRequest",
    "ViolationDTO",
    "EvidenceDTO",
    "ReportRequest",
    "ReportResponse",
    "DashboardSummary",
    "ViolationCategoryBreakdown",
    "ManufacturerTrend",
    "DashboardTrendsResponse"
]
