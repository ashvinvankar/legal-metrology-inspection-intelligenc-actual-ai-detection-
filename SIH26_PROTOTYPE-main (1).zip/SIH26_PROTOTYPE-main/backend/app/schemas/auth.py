"""Authentication and User Schemas."""

from typing import Optional
from uuid import UUID
from pydantic import BaseModel, ConfigDict, EmailStr


class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"


class TokenPayload(BaseModel):
    sub: Optional[str] = None
    role: Optional[str] = None


class LoginRequest(BaseModel):
    username: str
    password: str


class UserRegisterRequest(BaseModel):
    username: str
    email: EmailStr
    password: str


class RefreshRequest(BaseModel):
    refresh_token: str


class UserBase(BaseModel):
    username: str
    email: EmailStr
    role_id: UUID
    department_id: Optional[UUID] = None
    status: str = "active"


class UserCreate(UserBase):
    password: str


class UserResponse(UserBase):
    id: UUID

    model_config = ConfigDict(from_attributes=True)
