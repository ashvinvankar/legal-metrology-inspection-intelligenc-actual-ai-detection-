"""Compliance Finding and Review Schemas (PRD Section 10.4 & 12)."""

from datetime import datetime
from typing import List, Optional
from uuid import UUID
from pydantic import BaseModel, ConfigDict


class EvidenceDTO(BaseModel):
    id: UUID
    image_id: Optional[UUID] = None
    region_id: Optional[UUID] = None
    ocr_result_id: Optional[UUID] = None
    cropped_image_uri: Optional[str] = None

    model_config = ConfigDict(from_attributes=True)


class ViolationDTO(BaseModel):
    id: UUID
    severity: str
    description: str

    model_config = ConfigDict(from_attributes=True)


class ComplianceCheckDTO(BaseModel):
    id: UUID
    inspection_id: UUID
    rule_version_id: UUID
    rule_key: Optional[str] = None
    requirement: Optional[str] = None
    legal_reference: Optional[str] = None
    input_fields: Optional[List[str]] = None
    result: str  # COMPLIANT / NON_COMPLIANT / NEEDS_REVIEW / NOT_APPLICABLE
    confidence: Optional[float] = None
    system_generated: bool = True
    officer_decision: Optional[str] = None  # confirmed / overridden
    override_justification: Optional[str] = None
    violations: List[ViolationDTO] = []
    evidence_items: List[EvidenceDTO] = []
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)


class ComplianceReviewRequest(BaseModel):
    decision: str  # confirmed / overridden
    justification: Optional[str] = None  # Mandatory if decision == overridden
    corrected_fields: Optional[dict] = None
