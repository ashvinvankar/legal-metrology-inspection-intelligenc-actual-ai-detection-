"""Dashboard and Analytics DTOs (PRD Section 15)."""

from typing import Dict, List, Optional
from pydantic import BaseModel


class DashboardSummary(BaseModel):
    total_inspections: int
    compliant_count: int
    non_compliant_count: int
    needs_review_count: int
    draft_count: int


class ViolationCategoryBreakdown(BaseModel):
    category_name: str
    rule_key: str
    violation_count: int
    percentage: float


class ManufacturerTrend(BaseModel):
    manufacturer_name: str
    inspections_count: int
    violations_count: int
    repeat_offender: bool


class DashboardTrendsResponse(BaseModel):
    date_labels: List[str]
    compliant_series: List[int]
    non_compliant_series: List[int]
    needs_review_series: List[int]
