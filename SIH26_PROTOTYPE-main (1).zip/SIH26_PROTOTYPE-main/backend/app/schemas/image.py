"""Product Image and Quality Assessment Schemas (PRD Section 9.A)."""

from datetime import datetime
from typing import Any, Dict, List, Optional
from uuid import UUID
from pydantic import BaseModel, ConfigDict


class ImageQualityResult(BaseModel):
    quality_score: float
    passed: bool
    issues: List[str] = []
    blur_detected: bool = False
    glare_detected: bool = False
    low_resolution: bool = False
    skew_detected: bool = False


class ImageUploadResponse(BaseModel):
    id: UUID
    inspection_id: UUID
    image_type: str
    original_uri: str
    processed_uri: Optional[str] = None
    quality_score: Optional[float] = None
    quality_issues: Optional[Dict[str, Any]] = None
    created_at: datetime

    model_config = ConfigDict(from_attributes=True)
