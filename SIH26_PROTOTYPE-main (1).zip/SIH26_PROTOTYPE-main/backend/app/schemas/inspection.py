"""Inspection Schemas (PRD Section 23)."""

from datetime import datetime
from typing import List, Optional
from uuid import UUID
from pydantic import BaseModel, ConfigDict


class InspectionBase(BaseModel):
    product_id: Optional[UUID] = None
    product_name: Optional[str] = None
    location: Optional[str] = None
    category: Optional[str] = "Packaged Food"


class InspectionCreate(InspectionBase):
    pass


class InspectionUpdate(BaseModel):
    status: Optional[str] = None
    overall_result: Optional[str] = None
    location: Optional[str] = None


class InspectionResponse(InspectionBase):
    id: UUID
    officer_id: UUID
    reviewer_id: Optional[UUID] = None
    status: str
    overall_result: Optional[str] = None
    inspection_date: datetime
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class AnalysisStatusResponse(BaseModel):
    inspection_id: UUID
    task_id: str
    status: str
    stage: str
    progress_percent: int
    attempt: int
    error_message: Optional[str] = None
    completed: bool
