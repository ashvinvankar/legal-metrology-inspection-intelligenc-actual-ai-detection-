"""Report Metadata and Export Request Schemas (PRD Section 13)."""

from datetime import datetime
from typing import Optional
from uuid import UUID
from pydantic import BaseModel, ConfigDict


class ReportRequest(BaseModel):
    report_type: str = "summary"  # summary / detailed
    include_evidence_images: bool = True


class ReportResponse(BaseModel):
    id: UUID
    inspection_id: UUID
    report_type: str
    pdf_uri: Optional[str] = None
    docx_uri: Optional[str] = None
    qr_reference: str
    generated_at: datetime

    model_config = ConfigDict(from_attributes=True)
