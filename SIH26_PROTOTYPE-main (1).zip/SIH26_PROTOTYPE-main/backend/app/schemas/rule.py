"""Legal Rule Engine Schemas (PRD Section 10)."""

from datetime import date
from typing import Any, Dict, List, Optional
from uuid import UUID
from pydantic import BaseModel, ConfigDict


class RuleVersionDTO(BaseModel):
    id: UUID
    rule_id: UUID
    version: int
    applicability_conditions: Dict[str, Any]
    input_fields: List[str]
    validation_logic: Dict[str, Any]
    evidence_requirements: List[str]
    explanation_template: str
    active_from: date
    active_until: Optional[date] = None
    status: str

    model_config = ConfigDict(from_attributes=True)


class RuleCreate(BaseModel):
    rule_key: str
    legal_reference: str
    requirement: str
    severity: str = "Major"
    source_document: Optional[str] = None
    applicability_conditions: Dict[str, Any]
    input_fields: List[str]
    validation_logic: Dict[str, Any]
    evidence_requirements: List[str] = ["CROPPED_REGION", "OCR_TEXT", "BOUNDING_BOX"]
    explanation_template: str


class RuleResponse(BaseModel):
    id: UUID
    rule_key: str
    legal_reference: str
    requirement: str
    severity: str
    source_document: Optional[str] = None
    versions: List[RuleVersionDTO] = []

    model_config = ConfigDict(from_attributes=True)
