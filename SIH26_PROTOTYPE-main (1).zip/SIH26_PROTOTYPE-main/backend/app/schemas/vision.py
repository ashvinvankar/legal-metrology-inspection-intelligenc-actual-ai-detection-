"""Vision, OCR and Field Extraction DTOs (PRD Section 9)."""

from typing import Any, Dict, List, Optional
from uuid import UUID
from pydantic import BaseModel, ConfigDict


class BoundingBox(BaseModel):
    x1: float
    y1: float
    x2: float
    y2: float


class DetectedRegionDTO(BaseModel):
    id: UUID
    image_id: UUID
    region_type: str
    bbox: List[float]
    confidence: float
    model_version: str

    model_config = ConfigDict(from_attributes=True)


class OCRResultDTO(BaseModel):
    id: UUID
    region_id: UUID
    text: str
    confidence: float
    bbox: Optional[List[float]] = None
    language: str

    model_config = ConfigDict(from_attributes=True)


class ExtractedFieldDTO(BaseModel):
    id: UUID
    inspection_id: UUID
    field_name: str
    raw_value: Optional[str] = None
    normalized_value: Optional[Dict[str, Any]] = None
    confidence: float
    source_ocr_id: Optional[UUID] = None
    officer_confirmed: bool = False
    officer_corrected_value: Optional[Dict[str, Any]] = None

    model_config = ConfigDict(from_attributes=True)


class FieldCorrectionRequest(BaseModel):
    corrected_value: Any
    justification: str


class DeclarationUpdatePayload(BaseModel):
    raw_value: Optional[str] = None
    normalized_value: Optional[Dict[str, Any]] = None
    officer_confirmed: bool = True
    justification: Optional[str] = None


class RegionEvidenceItem(BaseModel):
    region: DetectedRegionDTO
    ocr_spans: List[OCRResultDTO]
    crop_uri: Optional[str] = None


class EvidenceDetailResponse(BaseModel):
    inspection_id: UUID
    image_id: UUID
    image_uri: str
    image_type: str
    quality_score: Optional[float] = None
    regions: List[RegionEvidenceItem]


class CopilotRequest(BaseModel):
    query: str
    history: Optional[List[Dict[str, str]]] = None


class CopilotResponse(BaseModel):
    answer: str
    source: str = "gemini-3.8-flash"
    rule_references: Optional[List[str]] = None
