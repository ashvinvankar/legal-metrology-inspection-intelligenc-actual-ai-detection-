"""Immutable Audit Trail Service (PRD Section 16).

IMPORTANT: This service adds the AuditLog row to the session and flushes it,
but does NOT call db.commit(). The session lifecycle (and final commit) is
managed by the FastAPI dependency get_db(). This prevents double-commit issues.
"""

import uuid
from typing import Any, Dict, Optional
from uuid import UUID

from sqlalchemy.ext.asyncio import AsyncSession
from app.models.audit import AuditLog


class AuditService:

    @staticmethod
    async def log_action(
        db: AsyncSession,
        actor_id: Optional[UUID],
        action: str,
        target_entity: str,
        target_id: Optional[UUID] = None,
        before_value: Optional[Dict[str, Any]] = None,
        after_value: Optional[Dict[str, Any]] = None,
        ip_address: Optional[str] = None,
    ) -> None:
        """
        Append an immutable audit log entry.
        Audit records must never be updated or deleted.
        The caller is responsible for committing the session.
        """
        audit_entry = AuditLog(
            id=uuid.uuid4(),
            actor_id=actor_id,
            action=action,
            target_entity=target_entity,
            target_id=target_id,
            before_value=before_value,
            after_value=after_value,
            ip_address=ip_address,
        )
        db.add(audit_entry)
        # Flush to get the ID but DO NOT commit — caller manages commit lifecycle
        await db.flush()
