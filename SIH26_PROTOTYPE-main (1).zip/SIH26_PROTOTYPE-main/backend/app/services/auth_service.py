"""Authentication and User Lifecycle Service (PRD Section 17 & 22.4)."""

from typing import Optional
from uuid import UUID
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.security import verify_password, create_access_token, create_refresh_token, get_password_hash
from app.models.user import User, Role
from app.schemas.auth import Token, LoginRequest, UserRegisterRequest
from fastapi import HTTPException, status
import uuid


class AuthService:

    @staticmethod
    async def get_user_by_username(db: AsyncSession, username: str) -> Optional[User]:
        """Fetch a user by username, eagerly loading their role."""
        stmt = (
            select(User)
            .where(User.username == username)
            .where(User.status == "active")
            .options(selectinload(User.role))
        )
        result = await db.execute(stmt)
        return result.scalar_one_or_none()

    @staticmethod
    async def get_user_by_id(db: AsyncSession, user_id: UUID) -> Optional[User]:
        """Fetch an active user by UUID, eagerly loading their role."""
        stmt = (
            select(User)
            .where(User.id == user_id)
            .where(User.status == "active")
            .options(selectinload(User.role))
        )
        result = await db.execute(stmt)
        return result.scalar_one_or_none()

    @staticmethod
    async def authenticate_user(db: AsyncSession, login_data: LoginRequest) -> Optional[Token]:
        """
        Authenticate user credentials against DB and issue JWT tokens.
        Returns None if credentials are invalid or user is disabled.
        JWT claims embed: sub (user UUID), username, role, department_id.
        """
        user = await AuthService.get_user_by_username(db, login_data.username)
        if not user:
            return None
        if not verify_password(login_data.password, user.password_hash):
            return None

        role_name = user.role.name if user.role else "Officer"
        token_data = {
            "sub": str(user.id),
            "username": user.username,
            "role": role_name,
            "department_id": str(user.department_id) if user.department_id else None,
        }
        access_token = create_access_token(subject=str(user.id), extra_claims=token_data)
        refresh_token = create_refresh_token(subject=str(user.id))
        return Token(access_token=access_token, refresh_token=refresh_token)

    @staticmethod
    async def register_user(db: AsyncSession, user_in: UserRegisterRequest) -> User:
        """Register a new user with the default 'Officer' role."""
        stmt = select(User).where(User.username == user_in.username)
        if (await db.execute(stmt)).scalar_one_or_none():
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Username already registered")
            
        stmt = select(User).where(User.email == user_in.email)
        if (await db.execute(stmt)).scalar_one_or_none():
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Email already registered")

        stmt = select(Role).where(Role.name == "Officer")
        role = (await db.execute(stmt)).scalar_one_or_none()
        if not role:
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Default role 'Officer' not found")

        db_user = User(
            id=uuid.uuid4(),
            username=user_in.username,
            email=user_in.email,
            password_hash=get_password_hash(user_in.password),
            role_id=role.id,
            status="active"
        )
        db.add(db_user)
        await db.commit()
        await db.refresh(db_user)
        return db_user

