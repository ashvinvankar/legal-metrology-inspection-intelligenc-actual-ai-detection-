"""Compliance Evaluation & Officer Review Service (PRD Section 10 & 12)."""

from typing import Any, Dict, List, Optional
from uuid import UUID, uuid4
from datetime import date

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.compliance import ComplianceCheck, Violation, Evidence
from app.models.inspection import Inspection
from app.models.rule import Rule, RuleVersion
from app.models.vision import ExtractedField
from app.rule_engine.engine import RuleEngine
from app.rule_engine.loader import RuleLoader
from app.rule_engine.schema import ComplianceState
from app.schemas.compliance import ComplianceCheckDTO, ComplianceReviewRequest


class ComplianceService:

    @staticmethod
    async def get_compliance_results(
        db: AsyncSession,
        inspection_id: UUID,
    ) -> List[ComplianceCheck]:
        """Load all compliance checks for an inspection with violations and evidence."""
        stmt = (
            select(ComplianceCheck)
            .where(ComplianceCheck.inspection_id == inspection_id)
            .options(
                selectinload(ComplianceCheck.violations),
                selectinload(ComplianceCheck.evidence_items),
                selectinload(ComplianceCheck.rule_version).selectinload(RuleVersion.rule),
            )
            .order_by(ComplianceCheck.created_at)
        )
        result = await db.execute(stmt)
        return list(result.scalars().all())

    @staticmethod
    async def review_finding(
        db: AsyncSession,
        compliance_check_id: UUID,
        reviewer_id: UUID,
        review_data: ComplianceReviewRequest,
    ) -> Optional[ComplianceCheck]:
        """
        Record officer confirmation or override on an individual compliance check (PRD Section 12).
        Rules:
        - decision=overridden requires non-empty justification
        - decision=confirmed simply marks officer agrees with system result
        - All review events must be audit-logged by the caller
        """
        if review_data.decision == "overridden" and not (review_data.justification or "").strip():
            raise ValueError("Justification is mandatory when overriding a compliance finding.")

        stmt = select(ComplianceCheck).where(ComplianceCheck.id == compliance_check_id)
        check = (await db.execute(stmt)).scalar_one_or_none()
        if not check:
            return None

        check.officer_decision = review_data.decision
        check.officer_id = reviewer_id
        check.override_justification = review_data.justification
        check.system_generated = False

        if review_data.decision == "overridden":
            if check.result in ("NON_COMPLIANT", "NEEDS_REVIEW"):
                check.result = "COMPLIANT"
            elif check.result == "COMPLIANT":
                check.result = "NON_COMPLIANT"

        if getattr(review_data, "corrected_fields", None):
            import uuid
            for field_name, value in review_data.corrected_fields.items():
                if not value:
                    continue
                ef_stmt = select(ExtractedField).where(
                    ExtractedField.inspection_id == check.inspection_id,
                    ExtractedField.field_name == field_name
                )
                ef = (await db.execute(ef_stmt)).scalar_one_or_none()
                if ef:
                    ef.officer_corrected_value = {"value": value}
                    ef.officer_confirmed = True
                else:
                    new_ef = ExtractedField(
                        id=uuid.uuid4(),
                        inspection_id=check.inspection_id,
                        field_name=field_name,
                        confidence=1.0,
                        officer_confirmed=True,
                        officer_corrected_value={"value": value}
                    )
                    db.add(new_ef)

        await db.flush()
        await db.refresh(check)
        return check

    @staticmethod
    async def run_rule_evaluation(
        db: AsyncSession,
        inspection_id: UUID,
    ) -> List[ComplianceCheck]:
        """
        Synchronous (async context) rule evaluation pipeline for direct API-triggered evaluation.
        Used as fallback if Celery is not available.
        Loads extracted fields from DB, evaluates all rules, and persists results.
        """
        # Load extracted fields
        ef_stmt = select(ExtractedField).where(ExtractedField.inspection_id == inspection_id)
        ef_rows = list((await db.execute(ef_stmt)).scalars().all())

        extracted_for_engine: Dict[str, Any] = {
            ef.field_name: {
                "raw_value": ef.raw_value,
                "normalized_value": ef.normalized_value,
                "confidence": ef.confidence,
            }
            for ef in ef_rows
        }

        # Load active rule versions
        rv_stmt = select(RuleVersion, Rule).join(Rule, Rule.id == RuleVersion.rule_id).where(
            RuleVersion.status == "published",
        )
        rv_rows = list((await db.execute(rv_stmt)).all())
        rv_by_key: Dict[str, RuleVersion] = {row.Rule.rule_key: row.RuleVersion for row in rv_rows}

        # Evaluate
        seed_rules = RuleLoader.load_seed_rules()
        inspection_stmt = select(Inspection).where(Inspection.id == inspection_id)
        inspection = (await db.execute(inspection_stmt)).scalar_one_or_none()
        category = inspection.category if inspection else "ALL"

        rule_engine = RuleEngine(seed_rules)
        evaluation_results = rule_engine.evaluate_inspection(extracted_for_engine, category)

        created_checks: List[ComplianceCheck] = []

        for eval_result in evaluation_results:
            rv = rv_by_key.get(eval_result.rule_key)
            if not rv:
                continue

            check = ComplianceCheck(
                id=uuid4(),
                inspection_id=inspection_id,
                rule_version_id=rv.id,
                result=eval_result.state.value,
                confidence=eval_result.confidence,
                system_generated=True,
            )
            db.add(check)
            await db.flush()

            if eval_result.state.value in ("NON_COMPLIANT", "NEEDS_REVIEW") and eval_result.violation_description:
                violation = Violation(
                    id=uuid4(),
                    compliance_check_id=check.id,
                    severity="Major",
                    description=eval_result.violation_description,
                )
                db.add(violation)

            created_checks.append(check)

        # Compute overall result
        results_set = {c.result for c in created_checks}
        if "NON_COMPLIANT" in results_set:
            overall = "NON_COMPLIANT"
        elif "NEEDS_REVIEW" in results_set:
            overall = "NEEDS_REVIEW"
        else:
            overall = "COMPLIANT"

        if inspection:
            inspection.overall_result = overall
            inspection.status = "completed"
        await db.flush()

        return created_checks
