"""Dashboard Aggregation Service (PRD Section 15)."""

from typing import Any, Dict, List, Optional
from uuid import UUID

from sqlalchemy import func, select, case
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.compliance import ComplianceCheck, Violation
from app.models.inspection import Inspection
from app.models.rule import Rule


class DashboardService:

    @staticmethod
    async def get_summary(
        db: AsyncSession,
        officer_id: Optional[UUID] = None,
    ) -> Dict[str, int]:
        """
        Aggregate inspection counts by overall_result and status.
        Officers are scoped to their own inspections; admins/reviewers see all.
        """
        stmt = select(
            func.count(Inspection.id).label("total"),
            func.sum(case((Inspection.overall_result == "COMPLIANT", 1), else_=0)).label("compliant"),
            func.sum(case((Inspection.overall_result == "NON_COMPLIANT", 1), else_=0)).label("non_compliant"),
            func.sum(case((Inspection.overall_result == "NEEDS_REVIEW", 1), else_=0)).label("needs_review"),
            func.sum(case((Inspection.status == "draft", 1), else_=0)).label("draft"),
        )
        if officer_id:
            stmt = stmt.where(Inspection.officer_id == officer_id)

        row = (await db.execute(stmt)).one()
        return {
            "total_inspections": int(row.total or 0),
            "compliant_count": int(row.compliant or 0),
            "non_compliant_count": int(row.non_compliant or 0),
            "needs_review_count": int(row.needs_review or 0),
            "draft_count": int(row.draft or 0),
        }

    @staticmethod
    async def get_violation_breakdown(db: AsyncSession, limit: int = 10, severity: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Top violation categories ranked by frequency.
        Joins ComplianceCheck → RuleVersion → Rule to get rule_key and legal_reference.
        """
        from app.models.rule import RuleVersion

        stmt = (
            select(
                Rule.rule_key,
                Rule.legal_reference,
                func.count(ComplianceCheck.id).label("violation_count"),
            )
            .join(RuleVersion, RuleVersion.id == ComplianceCheck.rule_version_id)
            .join(Rule, Rule.id == RuleVersion.rule_id)
            .where(ComplianceCheck.result == "NON_COMPLIANT")
        )
        if severity:
            stmt = stmt.where(Rule.severity == severity)
            
        stmt = (
            stmt.group_by(Rule.rule_key, Rule.legal_reference)
            .order_by(func.count(ComplianceCheck.id).desc())
            .limit(limit)
        )
        rows = list((await db.execute(stmt)).all())

        total = sum(r.violation_count for r in rows)
        return [
            {
                "category_name": r.legal_reference or r.rule_key,
                "rule_key": r.rule_key,
                "violation_count": r.violation_count,
                "percentage": round((r.violation_count / total * 100) if total > 0 else 0, 1),
            }
            for r in rows
        ]

    @staticmethod
    async def get_trends(db: AsyncSession, days: int = 30) -> Dict[str, Any]:
        """
        Time-series of inspection counts grouped by date and overall_result.
        Returns data for the past N days.
        """
        from sqlalchemy import text, cast, Date
        from datetime import date, timedelta

        # Generate date series for past N days
        today = date.today()
        date_range = [(today - timedelta(days=i)) for i in range(days - 1, -1, -1)]
        date_labels = [d.strftime("%d %b") for d in date_range]

        # Query inspections grouped by date
        stmt = (
            select(
                func.date(Inspection.inspection_date).label("idate"),
                Inspection.overall_result,
                func.count(Inspection.id).label("cnt"),
            )
            .where(Inspection.inspection_date >= today - timedelta(days=days))
            .group_by(func.date(Inspection.inspection_date), Inspection.overall_result)
            .order_by(func.date(Inspection.inspection_date))
        )
        rows = list((await db.execute(stmt)).all())

        # Build lookup: {date: {result: count}}
        from collections import defaultdict
        daily: Dict[str, Dict[str, int]] = defaultdict(lambda: {"COMPLIANT": 0, "NON_COMPLIANT": 0, "NEEDS_REVIEW": 0})
        for row in rows:
            d_str = row.idate.strftime("%d %b") if hasattr(row.idate, "strftime") else str(row.idate)
            result = row.overall_result or "NEEDS_REVIEW"
            if result in daily[d_str]:
                daily[d_str][result] = row.cnt

        compliant_series = [daily[d]["COMPLIANT"] for d in date_labels]
        non_compliant_series = [daily[d]["NON_COMPLIANT"] for d in date_labels]
        needs_review_series = [daily[d]["NEEDS_REVIEW"] for d in date_labels]

        return {
            "date_labels": date_labels,
            "compliant_series": compliant_series,
            "non_compliant_series": non_compliant_series,
            "needs_review_series": needs_review_series,
        }
