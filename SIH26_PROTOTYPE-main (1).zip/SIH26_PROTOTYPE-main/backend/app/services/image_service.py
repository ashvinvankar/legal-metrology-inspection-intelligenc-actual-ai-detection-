"""Image Storage and Retrieval Service (PRD Section 12)."""

import asyncio
import uuid
from pathlib import Path
from typing import List, Optional, Tuple
from uuid import UUID

from fastapi import UploadFile
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.inspection import ProductImage
from app.services.storage_service import StorageService


# Allowed image MIME types and magic bytes
ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp"}
MAGIC_BYTES = {
    b"\xff\xd8\xff": "jpeg",   # JPEG
    b"\x89PNG": "png",          # PNG
    b"RIFF": "webp",            # WebP (also needs to check offset 8 for "WEBP")
}


def _validate_file_type(content: bytes, filename: str) -> Tuple[bool, str]:
    """Validate file by extension and magic bytes to prevent upload-based attacks."""
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        return False, f"File extension '{ext}' not allowed. Supported: {ALLOWED_EXTENSIONS}"
    # Magic byte check
    if content[:3] == b"\xff\xd8\xff":
        return True, "jpeg"
    if content[:4] == b"\x89PNG":
        return True, "png"
    if content[:4] == b"RIFF" and len(content) > 12 and content[8:12] == b"WEBP":
        return True, "webp"
    return False, "File content does not match declared image format (magic byte check failed)"


class ImageService:

    @staticmethod
    async def save_image(
        db: AsyncSession,
        inspection_id: UUID,
        uploaded_by: UUID,
        file: UploadFile,
        image_type: str,
    ) -> Tuple[Optional[ProductImage], Optional[dict]]:
        """
        Validate, save, and register an uploaded image.
        Returns (ProductImage, None) on success, or (None, error_dict) on failure.
        """
        # Read full content for magic byte validation
        content = await file.read()

        # Size check: 10MB max (PRD Section 17)
        if len(content) > 10 * 1024 * 1024:
            return None, {"error": "Image exceeds 10MB size limit"}

        valid, mime_or_error = _validate_file_type(content, file.filename or "upload.jpg")
        if not valid:
            return None, {"error": mime_or_error}

        # Object keys are UUID-based, preventing traversal and retaining no
        # client-controlled path component. Storage is MinIO/S3 in Compose.
        file_id = uuid.uuid4()
        ext = Path(file.filename or "upload.jpg").suffix.lower()
        storage_key = f"images/{file_id}{ext}"
        storage = StorageService()
        relative_uri = await asyncio.to_thread(
            storage.upload_file, content, storage_key, file.content_type or "application/octet-stream"
        )

        # Persist DB record
        image = ProductImage(
            id=file_id,
            inspection_id=inspection_id,
            image_type=image_type,
            original_uri=relative_uri,
            uploaded_by=uploaded_by,
        )
        db.add(image)
        await db.flush()
        await db.refresh(image)
        return image, None

    @staticmethod
    async def get_images_for_inspection(db: AsyncSession, inspection_id: UUID) -> List[ProductImage]:
        """Retrieve all images associated with an inspection."""
        stmt = select(ProductImage).where(ProductImage.inspection_id == inspection_id)
        result = await db.execute(stmt)
        return list(result.scalars().all())

    @staticmethod
    async def get_image_bytes(image: ProductImage) -> Optional[bytes]:
        """Load raw image bytes from local storage for pipeline processing."""
        return await asyncio.to_thread(StorageService().get_file_bytes, image.original_uri)

    @staticmethod
    async def get_browser_uri(uri: str) -> str:
        """Resolve the durable object URI to a short-lived browser read URL."""
        return await asyncio.to_thread(StorageService().get_presigned_url, uri)
