"""Inspection Lifecycle and Repository Service (PRD Section 14)."""

from datetime import datetime
from typing import List, Optional
from uuid import UUID, uuid4

from sqlalchemy import select, and_, or_, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.inspection import Inspection, ProductImage
from app.models.compliance import ComplianceCheck
from app.schemas.inspection import InspectionCreate, InspectionUpdate


class InspectionService:

    @staticmethod
    async def create_inspection(
        db: AsyncSession,
        officer_id: UUID,
        data: InspectionCreate
    ) -> Inspection:
        """Create a new inspection in draft state with officer ownership."""
        inspection = Inspection(
            id=uuid4(),
            officer_id=officer_id,
            product_id=data.product_id,
            product_name=data.product_name,
            category=data.category or "Packaged Food",
            location=data.location,
            status="draft",
            inspection_date=datetime.utcnow(),
        )
        db.add(inspection)
        await db.flush()
        await db.refresh(inspection)
        return inspection

    @staticmethod
    async def get_inspection(db: AsyncSession, inspection_id: UUID) -> Optional[Inspection]:
        """Retrieve an inspection with images, fields and compliance checks loaded."""
        stmt = (
            select(Inspection)
            .where(Inspection.id == inspection_id)
            .options(
                selectinload(Inspection.images),
                selectinload(Inspection.extracted_fields),
                selectinload(Inspection.compliance_checks),
            )
        )
        result = await db.execute(stmt)
        return result.scalar_one_or_none()

    @staticmethod
    async def list_inspections(
        db: AsyncSession,
        officer_id: Optional[UUID] = None,
        status: Optional[str] = None,
        category: Optional[str] = None,
        overall_result: Optional[str] = None,
        skip: int = 0,
        limit: int = 50,
    ) -> List[Inspection]:
        """List inspections with optional filters. Officers see only their own; Reviewers/Admins see all."""
        stmt = select(Inspection).offset(skip).limit(limit).order_by(Inspection.inspection_date.desc())
        filters = []
        if officer_id:
            filters.append(Inspection.officer_id == officer_id)
        if status:
            filters.append(Inspection.status == status)
        if category:
            filters.append(Inspection.category == category)
        if overall_result:
            filters.append(Inspection.overall_result == overall_result)
        if filters:
            stmt = stmt.where(and_(*filters))
        result = await db.execute(stmt)
        return list(result.scalars().all())

    @staticmethod
    async def update_inspection(
        db: AsyncSession,
        inspection_id: UUID,
        data: InspectionUpdate
    ) -> Optional[Inspection]:
        """Update inspection metadata or workflow status."""
        inspection = await InspectionService.get_inspection(db, inspection_id)
        if not inspection:
            return None
        if data.status is not None:
            inspection.status = data.status
        if data.overall_result is not None:
            inspection.overall_result = data.overall_result
        if data.location is not None:
            inspection.location = data.location
        await db.flush()
        await db.refresh(inspection)
        return inspection

    @staticmethod
    async def compute_overall_result(db: AsyncSession, inspection_id: UUID) -> str:
        """
        Compute and persist overall result from compliance checks:
        If any NON_COMPLIANT → NON_COMPLIANT
        If any NEEDS_REVIEW (and none NON_COMPLIANT) → NEEDS_REVIEW
        Else → COMPLIANT
        """
        stmt = select(ComplianceCheck.result).where(ComplianceCheck.inspection_id == inspection_id)
        results = list((await db.execute(stmt)).scalars().all())

        if not results:
            return "NEEDS_REVIEW"

        result_set = set(results)
        if "NON_COMPLIANT" in result_set:
            overall = "NON_COMPLIANT"
        elif "NEEDS_REVIEW" in result_set:
            overall = "NEEDS_REVIEW"
        else:
            overall = "COMPLIANT"

        # Persist back
        inspection = await InspectionService.get_inspection(db, inspection_id)
        if inspection:
            inspection.overall_result = overall
            inspection.status = "completed"
            await db.flush()
        return overall

