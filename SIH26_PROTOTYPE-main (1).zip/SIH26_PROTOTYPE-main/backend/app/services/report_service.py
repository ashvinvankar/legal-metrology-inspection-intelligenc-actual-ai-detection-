"""Report Service — DB aggregation, generation, storage (PRD Section 13)."""

import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.config import settings
from app.models.compliance import ComplianceCheck, Violation
from app.models.inspection import Inspection
from app.models.report import Report
from app.models.rule import Rule, RuleVersion
from app.models.user import User
from app.reporting.pdf_generator import PDFReportGenerator


class ReportService:

    @staticmethod
    async def generate_report(
        db: AsyncSession,
        inspection_id: UUID,
        report_type: str = "summary",
        generated_by: UUID = None,
    ) -> Report:
        """
        Aggregate all inspection data and generate a PDF (and optionally DOCX) report.
        Persists a Report row and returns it.
        """
        # ---- Aggregate inspection data ----
        inspection_stmt = (
            select(Inspection)
            .where(Inspection.id == inspection_id)
            .options(
                selectinload(Inspection.images),
                selectinload(Inspection.extracted_fields),
                selectinload(Inspection.compliance_checks).selectinload(ComplianceCheck.violations),
                selectinload(Inspection.compliance_checks).selectinload(ComplianceCheck.rule_version).selectinload(RuleVersion.rule),
            )
        )
        inspection = (await db.execute(inspection_stmt)).scalar_one_or_none()
        if not inspection:
            raise ValueError(f"Inspection {inspection_id} not found")

        # Load officer info
        officer_stmt = select(User).where(User.id == inspection.officer_id)
        officer = (await db.execute(officer_stmt)).scalar_one_or_none()

        # Build report_data dict for PDF generator
        compliance_checks_data: List[Dict[str, Any]] = []
        violations_data: List[Dict[str, Any]] = []

        for check in inspection.compliance_checks:
            rv = check.rule_version
            rule = rv.rule if (rv and hasattr(rv, "rule")) else None
            compliance_checks_data.append({
                "rule_key": rule.rule_key if rule else "—",
                "legal_reference": rule.legal_reference if rule else "—",
                "requirement": rule.requirement if rule else "—",
                "detected_value": check.confidence and f"(confidence {check.confidence:.0%})",
                "result": check.result,
                "confidence": check.confidence,
                "officer_decision": check.officer_decision,
                "override_justification": check.override_justification,
            })
            for v in check.violations:
                violations_data.append({
                    "severity": v.severity,
                    "description": v.description,
                })

        report_data = {
            "inspection": {
                "inspection_date": inspection.inspection_date.strftime("%d %b %Y") if inspection.inspection_date else "—",
                "product_name": inspection.product_name,
                "category": inspection.category,
                "location": inspection.location,
                "overall_result": inspection.overall_result or "NEEDS_REVIEW",
                "officer_name": officer.username if officer else "—",
            },
            "compliance_checks": compliance_checks_data,
            "violations": violations_data,
        }

        # ---- Generate QR reference ----
        qr_ref = f"QR-SLM-{str(inspection_id).split('-')[0].upper()}"

        # ---- Generate PDF ----
        storage_dir = Path(settings.STORAGE_DIR) / "reports"
        pdf_gen = PDFReportGenerator(output_dir=str(storage_dir))
        pdf_path = pdf_gen.generate_inspection_pdf(
            str(inspection_id),
            report_data,
            qr_reference=qr_ref,
        )
        relative_pdf = f"/storage/reports/{Path(pdf_path).name}"

        # ---- Optionally generate DOCX ----
        docx_path = None
        try:
            from app.reporting.docx_generator import DOCXReportGenerator
            docx_gen = DOCXReportGenerator(output_dir=str(storage_dir))
            docx_file = docx_gen.generate_inspection_docx(str(inspection_id), report_data)
            docx_path = f"/storage/reports/{Path(docx_file).name}"
        except Exception:
            pass  # DOCX is optional; PDF is the primary artifact

        # ---- Persist Report row ----
        report = Report(
            id=uuid.uuid4(),
            inspection_id=inspection_id,
            report_type=report_type,
            pdf_uri=relative_pdf,
            docx_uri=docx_path,
            qr_reference=qr_ref,
            generated_by=generated_by or inspection.officer_id,
        )
        db.add(report)
        await db.flush()
        await db.refresh(report)
        return report

    @staticmethod
    async def get_report(db: AsyncSession, report_id: UUID) -> Optional[Report]:
        """Retrieve a report record by UUID."""
        stmt = select(Report).where(Report.id == report_id)
        return (await db.execute(stmt)).scalar_one_or_none()

    @staticmethod
    async def list_reports_for_inspection(db: AsyncSession, inspection_id: UUID) -> List[Report]:
        """List all reports generated for an inspection."""
        stmt = select(Report).where(Report.inspection_id == inspection_id).order_by(Report.generated_at.desc())
        return list((await db.execute(stmt)).scalars().all())

    @staticmethod
    def get_report_file_path(report: Report, file_type: str = "pdf") -> Optional[Path]:
        """Resolve the filesystem path for report download."""
        uri = report.pdf_uri if file_type == "pdf" else report.docx_uri
        if not uri:
            return None
        relative = uri.lstrip("/storage/").lstrip("storage/")
        storage = Path(settings.STORAGE_DIR)
        # Handle both /storage/reports/file.pdf and reports/file.pdf
        if relative.startswith("reports/"):
            return storage / relative
        return storage / "reports" / Path(relative).name
