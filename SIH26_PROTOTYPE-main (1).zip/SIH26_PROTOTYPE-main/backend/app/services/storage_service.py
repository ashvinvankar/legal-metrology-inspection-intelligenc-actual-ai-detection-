"""Storage adapter for local development and S3-compatible object storage."""

from pathlib import Path
from typing import Optional

import boto3
from botocore.client import Config

from app.core.config import settings


class StorageService:
    """Persist opaque object keys; never expose filesystem paths as the storage contract."""

    def __init__(self):
        self.backend = settings.STORAGE_BACKEND.lower()
        self.base_dir = Path(settings.STORAGE_DIR)
        if self.backend == "local":
            self.base_dir.mkdir(parents=True, exist_ok=True)
        else:
            scheme = "https" if settings.STORAGE_USE_SSL else "http"
            self.client = boto3.client(
                "s3", endpoint_url=f"{scheme}://{settings.STORAGE_ENDPOINT}",
                aws_access_key_id=settings.STORAGE_ACCESS_KEY,
                aws_secret_access_key=settings.STORAGE_SECRET_KEY,
                config=Config(signature_version="s3v4"), region_name="us-east-1",
            )

    @staticmethod
    def _key(destination_key: str) -> str:
        return destination_key.lstrip("/\\").replace("\\", "/")

    def _ensure_bucket(self) -> None:
        try:
            self.client.head_bucket(Bucket=settings.STORAGE_BUCKET_NAME)
        except Exception:
            self.client.create_bucket(Bucket=settings.STORAGE_BUCKET_NAME)

    def upload_file(self, file_bytes: bytes, destination_key: str, content_type: str = "application/octet-stream") -> str:
        key = self._key(destination_key)
        if self.backend == "local":
            file_path = self.base_dir / key
            file_path.parent.mkdir(parents=True, exist_ok=True)
            file_path.write_bytes(file_bytes)
            return f"local://{key}"
        self._ensure_bucket()
        self.client.put_object(Bucket=settings.STORAGE_BUCKET_NAME, Key=key, Body=file_bytes, ContentType=content_type)
        return f"s3://{settings.STORAGE_BUCKET_NAME}/{key}"

    def get_file_bytes(self, uri: str) -> Optional[bytes]:
        key = self.key_from_uri(uri)
        try:
            if self.backend == "local":
                path = self.base_dir / key
                return path.read_bytes() if path.exists() else None
            return self.client.get_object(Bucket=settings.STORAGE_BUCKET_NAME, Key=key)["Body"].read()
        except Exception:
            return None

    def delete_file(self, uri: str) -> None:
        key = self.key_from_uri(uri)
        if self.backend == "local":
            path = self.base_dir / key
            if path.exists():
                path.unlink()
            return
        self.client.delete_object(Bucket=settings.STORAGE_BUCKET_NAME, Key=key)

    def get_presigned_url(self, uri: str, expires_in: int = 3600) -> str:
        """Return a browser-safe read URL without making evidence objects public."""
        key = self.key_from_uri(uri)
        if self.backend == "local":
            from app.core.security import create_access_token
            from datetime import timedelta
            token = create_access_token(
                subject="storage", 
                expires_delta=timedelta(seconds=expires_in), 
                extra_claims={"file_key": key}
            )
            return f"{settings.API_V1_STR}/storage/{key}?token={token}"
        scheme = "https" if settings.STORAGE_USE_SSL else "http"
        external_endpoint = settings.STORAGE_ENDPOINT
        if "minio" in external_endpoint:
             external_endpoint = external_endpoint.replace("minio", "localhost")
             
        presign_client = boto3.client(
            "s3", endpoint_url=f"{scheme}://{external_endpoint}",
            aws_access_key_id=settings.STORAGE_ACCESS_KEY,
            aws_secret_access_key=settings.STORAGE_SECRET_KEY,
            config=Config(signature_version="s3v4"), region_name="us-east-1",
        )
        url = presign_client.generate_presigned_url(
            "get_object",
            Params={"Bucket": settings.STORAGE_BUCKET_NAME, "Key": key},
            ExpiresIn=expires_in,
        )
        return url

    def key_from_uri(self, uri: str) -> str:
        if uri.startswith("s3://"):
            parts = uri[5:].split("/", 1)
            return parts[1] if len(parts) == 2 else ""
        if uri.startswith("local://"):
            return uri[8:]
        # Backward compatibility for data uploaded before this adapter.
        return uri.removeprefix("/storage/").lstrip("/")
