"""User Management Service (PRD Section 6, 23)."""

from typing import List, Optional
from uuid import UUID, uuid4
import uuid

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.security import get_password_hash
from app.models.user import User, Role
from app.schemas.auth import UserCreate, UserResponse


class UserService:

    @staticmethod
    async def get_user_by_id(db: AsyncSession, user_id: UUID) -> Optional[User]:
        """Get user by UUID, loading role eagerly."""
        stmt = select(User).where(User.id == user_id).options(selectinload(User.role))
        result = await db.execute(stmt)
        return result.scalar_one_or_none()

    @staticmethod
    async def list_users(
        db: AsyncSession,
        department_id: Optional[UUID] = None,
        role_name: Optional[str] = None,
        skip: int = 0,
        limit: int = 50,
    ) -> List[User]:
        """List users, optionally scoped by department and role (PRD Section 6.3 — Dept Admin scoping)."""
        stmt = select(User).options(selectinload(User.role)).offset(skip).limit(limit)
        if department_id:
            stmt = stmt.where(User.department_id == department_id)
        if role_name:
            stmt = stmt.join(User.role).where(Role.name == role_name)
        result = await db.execute(stmt)
        return list(result.scalars().all())

    @staticmethod
    async def create_user(db: AsyncSession, data: UserCreate) -> User:
        """Create a new user with a hashed password."""
        new_user = User(
            id=uuid4(),
            username=data.username,
            email=data.email,
            password_hash=get_password_hash(data.password),
            role_id=data.role_id,
            department_id=data.department_id,
            status=data.status,
        )
        db.add(new_user)
        await db.flush()
        # Reload with role relationship
        await db.refresh(new_user)
        return new_user

    @staticmethod
    async def update_user_status(db: AsyncSession, user_id: UUID, status: str) -> Optional[User]:
        """Activate or disable a user account."""
        user = await UserService.get_user_by_id(db, user_id)
        if not user:
            return None
        user.status = status
        await db.flush()
        return user
