"""Celery Background Pipeline Tasks (PRD Section 22.1).

Full end-to-end async pipeline:
1. Load inspection images from DB
2. Image Quality Assessment (OpenCV)
3. Image Preprocessing (OpenCV)
4. Declaration Region Detection (YOLO with canonical classes, strictly no mock in prod)
5. Per-region OCR (EasyOCR on crops only, strictly no mock in prod)
6. Structured Field Extraction & Normalization (canonical vocabulary)
7. Deterministic Legal Rule Engine Evaluation
8. Persist all results (DetectedRegion, OCRResult, ExtractedField, ComplianceCheck, Violation, Evidence)
9. Update Inspection overall_result and status
"""

import logging
import uuid
import time
from datetime import datetime, date
from typing import Any, Dict, List, Optional

from app.core.celery_app import celery_app
from app.core.config import settings

logger = logging.getLogger(__name__)


@celery_app.task(bind=True, name="tasks.run_inspection_pipeline", max_retries=3)
def run_inspection_pipeline(self, inspection_id: str, task_id: Optional[str] = None) -> Dict[str, Any]:
    """
    Full async inspection pipeline. Runs in Celery worker with sync DB session.
    Updates inspection status through stages, never leaves a silent false-completed state.
    """
    from app.core.database import SyncSessionLocal
    from app.models.inspection import Inspection, InspectionAnalysisTask, ProductImage
    from app.models.vision import DetectedRegion, OCRResult, ExtractedField
    from app.models.compliance import ComplianceCheck, Violation, Evidence
    from app.models.rule import Rule, RuleVersion
    from app.pipeline.preprocessor import ImagePreprocessor
    from app.pipeline.detector import RegionDetector
    from app.pipeline.ocr_engine import OCREngine
    from app.pipeline.extractor import InformationExtractor
    from app.pipeline.gemini_vision import GeminiVisionInspector
    from app.services.storage_service import StorageService
    from app.rule_engine.engine import RuleEngine
    from app.rule_engine.loader import RuleLoader
    from sqlalchemy import select, delete

    inspection_uuid = uuid.UUID(inspection_id)
    analysis_task = None

    with SyncSessionLocal() as db:
        try:
            # --- Stage 0: Load inspection and images ---
            inspection: Optional[Inspection] = db.execute(
                select(Inspection).where(Inspection.id == inspection_uuid)
            ).scalar_one_or_none()

            if not inspection:
                logger.error(f"Inspection {inspection_id} not found in pipeline task.")
                return {"error": "Inspection not found", "inspection_id": inspection_id}

            if task_id:
                analysis_task = db.execute(
                    select(InspectionAnalysisTask).where(InspectionAnalysisTask.celery_task_id == task_id)
                ).scalar_one_or_none()
                if not analysis_task:
                    logger.error("Analysis task %s not found for inspection %s", task_id, inspection_id)
                    return {"error": "Analysis task not found", "inspection_id": inspection_id}
                if analysis_task.status == "completed":
                    return {"inspection_id": inspection_id, "status": "COMPLETED", "idempotent": True}
                analysis_task.status = "running"
                analysis_task.stage = "PREPROCESSING"
                analysis_task.progress_percent = 5
                analysis_task.attempt += 1
                analysis_task.error_message = None
                analysis_task.started_at = datetime.utcnow()

            # Mark as analyzing
            inspection.status = "analyzing"
            db.commit()

            images: List[ProductImage] = list(
                db.execute(select(ProductImage).where(ProductImage.inspection_id == inspection_uuid)).scalars().all()
            )

            if not images:
                logger.warning(f"No images found for inspection {inspection_id}. Setting needs_review.")
                inspection.status = "needs_review"
                inspection.overall_result = "NEEDS_REVIEW"
                if analysis_task:
                    analysis_task.status = "completed"
                    analysis_task.stage = "COMPLETED"
                    analysis_task.progress_percent = 100
                    analysis_task.completed_at = datetime.utcnow()
                db.commit()
                return {"inspection_id": inspection_id, "status": "NEEDS_REVIEW", "reason": "No images uploaded"}

            # --- Safety Checks for Production Mode ---
            gemini_available = GeminiVisionInspector.is_available()
            if not settings.DEMO_MODE and not gemini_available:
                det_ready, det_err = RegionDetector.verify_detector_readiness()
                if not det_ready:
                    err_msg = f"Detector unavailable in production: {det_err}"
                    logger.error(err_msg)
                    inspection.status = "needs_review"
                    inspection.overall_result = "NEEDS_REVIEW"
                    if analysis_task:
                        analysis_task.status = "failed"
                        analysis_task.stage = "FAILED"
                        analysis_task.error_message = err_msg
                        analysis_task.completed_at = datetime.utcnow()
                    db.commit()
                    return {"inspection_id": inspection_id, "status": "NEEDS_REVIEW", "error": err_msg}

                ocr_ready, ocr_err = OCREngine.verify_ocr_readiness()
                if not ocr_ready:
                    err_msg = f"OCR engine unavailable in production: {ocr_err}"
                    logger.error(err_msg)
                    inspection.status = "needs_review"
                    inspection.overall_result = "NEEDS_REVIEW"
                    if analysis_task:
                        analysis_task.status = "failed"
                        analysis_task.stage = "FAILED"
                        analysis_task.error_message = err_msg
                        analysis_task.completed_at = datetime.utcnow()
                    db.commit()
                    return {"inspection_id": inspection_id, "status": "NEEDS_REVIEW", "error": err_msg}

            # Clean up any existing results for this inspection before running pipeline (idempotent re-run)
            existing_checks = list(db.execute(select(ComplianceCheck).where(ComplianceCheck.inspection_id == inspection_uuid)).scalars().all())
            for chk in existing_checks:
                db.execute(delete(Violation).where(Violation.compliance_check_id == chk.id))
                db.execute(delete(Evidence).where(Evidence.compliance_check_id == chk.id))
                db.delete(chk)
            db.execute(delete(ExtractedField).where(ExtractedField.inspection_id == inspection_uuid))
            for img_rec in images:
                regions_to_del = list(db.execute(select(DetectedRegion).where(DetectedRegion.image_id == img_rec.id)).scalars().all())
                for reg in regions_to_del:
                    db.execute(delete(OCRResult).where(OCRResult.region_id == reg.id))
                    db.delete(reg)
            db.flush()

            # --- Stage 1: Initialize Pipeline Components ---
            preprocessor = ImagePreprocessor()
            detector = RegionDetector()
            ocr_engine = OCREngine()
            extractor = InformationExtractor()
            storage = StorageService()

            all_ocr_by_region: Dict[str, List[dict]] = {}
            # Tracks regions where every OCR span was below the 0.60 confidence threshold.
            low_confidence_regions: set = set()
            image_ids_by_type: Dict[str, uuid.UUID] = {}

            if analysis_task:
                analysis_task.stage = "REGION_DETECTION"
                analysis_task.progress_percent = 25
                db.flush()

            for image_record in images:
                raw_bytes = storage.get_file_bytes(image_record.original_uri)
                if not raw_bytes:
                    logger.warning("Image object not found for %s", image_record.id)
                    continue

                # --- Stage 2: Preprocessing ---
                if settings.DEMO_MODE:
                    # In DEMO_MODE, skip heavy preprocessing for speed
                    processed_bytes = raw_bytes
                else:
                    processed_bytes, _ = preprocessor.preprocess(raw_bytes)
                    if processed_bytes:
                        processed_name = f"proc_{image_record.id}.jpg"
                        image_record.processed_uri = storage.upload_file(processed_bytes, f"images/{processed_name}", "image/jpeg")
                    else:
                        processed_bytes = raw_bytes

                # --- Stage 3 & 4: Multimodal Vision AI Perception or Local OCR Fallback ---
                gemini_ran = False
                if gemini_available:
                    try:
                        logger.info(f"Running Gemini 3.8 Flash Multimodal Vision perception on image {image_record.id}...")
                        gemini_res = GeminiVisionInspector.inspect_package_image_sync(raw_bytes)
                        if gemini_res and isinstance(gemini_res, dict):
                            for field_key in [
                                "mrp", "net_quantity", "date_of_manufacture", "consumer_care_contact",
                                "manufacturer_name", "manufacturer_address", "packer_name",
                                "importer_name", "country_of_origin", "unit_sale_price"
                            ]:
                                field_val = gemini_res.get(field_key)
                                if field_val and isinstance(field_val, dict):
                                    raw_text = (
                                        field_val.get("raw_text")
                                        or field_val.get("name")
                                        or field_val.get("address")
                                        or field_val.get("country")
                                        or ""
                                    )
                                    if raw_text:
                                        bbox_coords = GeminiVisionInspector.to_canonical_bbox(field_val.get("bbox"))
                                        conf = float(field_val.get("confidence", 0.95))
                                        reg_id = uuid.uuid4()
                                        d_reg = DetectedRegion(
                                            id=reg_id,
                                            image_id=image_record.id,
                                            region_type=field_key,
                                            bbox=bbox_coords,
                                            confidence=conf,
                                            model_version="gemini-1.5-flash",
                                        )
                                        db.add(d_reg)

                                        # Crop region specifically for targeted evidence preview
                                        cropped = RegionDetector.crop_region(raw_bytes, bbox_coords)
                                        crop_uri = None
                                        if cropped:
                                            try:
                                                crop_uri = storage.upload_file(cropped, f"crops/crop_{reg_id}.jpg", "image/jpeg")
                                            except Exception as up_exc:
                                                logger.warning(f"Failed to upload crop {reg_id}: {up_exc}")

                                        ocr_id = uuid.uuid4()
                                        ocr_res = OCRResult(
                                            id=ocr_id,
                                            region_id=reg_id,
                                            text=raw_text,
                                            confidence=conf,
                                            bbox=bbox_coords,
                                            language="en",
                                        )
                                        db.add(ocr_res)

                                        if field_key not in all_ocr_by_region:
                                            all_ocr_by_region[field_key] = []
                                        all_ocr_by_region[field_key].append({
                                            "text": raw_text,
                                            "confidence": conf,
                                            "bbox": bbox_coords,
                                            "ocr_result_id": str(ocr_id),
                                            "image_id": str(image_record.id),
                                            "region_id": str(reg_id),
                                            "crop_uri": crop_uri,
                                        })
                            if all_ocr_by_region:
                                gemini_ran = True
                    except Exception as g_exc:
                        logger.warning(f"Gemini Vision failed on image {image_record.id}: {g_exc}. Running local pipeline.")

                if not gemini_ran:
                    # Enhanced Local CV Detection & OCR Pipeline
                    regions, det_err = detector.detect_regions_with_status(raw_bytes)
                    if not regions and processed_bytes:
                        regions, det_err = detector.detect_regions_with_status(processed_bytes)
                    if det_err and not settings.DEMO_MODE:
                        logger.warning(f"Detection note for image {image_record.id}: {det_err}")

                    for region in regions:
                        region_id = uuid.uuid4()
                        db_region = DetectedRegion(
                            id=region_id,
                            image_id=image_record.id,
                            region_type=region.label,
                            bbox=region.bbox,
                            confidence=region.confidence,
                            model_version=region.model_version,
                        )
                        db.add(db_region)

                        # Crop region specifically for targeted OCR (prefer raw_bytes for max resolution)
                        cropped = RegionDetector.crop_region(raw_bytes, region.bbox) or RegionDetector.crop_region(processed_bytes, region.bbox)
                        crop_uri = None
                        if cropped:
                            crop_filename = f"crop_{region_id}.jpg"
                            try:
                                crop_uri = storage.upload_file(cropped, f"crops/{crop_filename}", "image/jpeg")
                            except Exception as up_exc:
                                logger.warning(f"Failed to upload crop {region_id}: {up_exc}")

                        # OCR on crop bytes
                        ocr_spans: List[Any] = []
                        if cropped:
                            ocr_spans = ocr_engine.extract_text(cropped, region_label=region.label)
                        elif settings.DEMO_MODE:
                            ocr_spans = ocr_engine.extract_text(processed_bytes, region_label=region.label)

                        # Confidence Gate: drop spans below the medium threshold (0.60)
                        conf_threshold = settings.OCR_MEDIUM_CONFIDENCE_THRESHOLD
                        high_conf_spans = [s for s in ocr_spans if s.confidence >= conf_threshold]

                        if ocr_spans and not high_conf_spans:
                            low_confidence_regions.add(region.label)
                            logger.warning(
                                f"Region '{region.label}' (image {image_record.id}): all {len(ocr_spans)} "
                                f"OCR span(s) are below confidence threshold {conf_threshold}. "
                                "Region flagged for NEEDS_REVIEW."
                            )

                        for span in ocr_spans:
                            ocr_id = uuid.uuid4()
                            ocr_result = OCRResult(
                                id=ocr_id,
                                region_id=region_id,
                                text=span.text,
                                confidence=span.confidence,
                                bbox=span.bbox,
                                language=span.language,
                            )
                            db.add(ocr_result)

                            if span.confidence >= conf_threshold:
                                if region.label not in all_ocr_by_region:
                                    all_ocr_by_region[region.label] = []
                                all_ocr_by_region[region.label].append({
                                    "text": span.text,
                                    "confidence": span.confidence,
                                    "bbox": span.bbox,
                                    "ocr_result_id": str(ocr_id),
                                    "image_id": str(image_record.id),
                                    "region_id": str(region_id),
                                    "crop_uri": crop_uri,
                                })

                image_ids_by_type[image_record.image_type] = image_record.id

                # Batch flush once per image instead of per region
                db.flush()

            if analysis_task:
                analysis_task.stage = "TEXT_EXTRACTION"
                analysis_task.progress_percent = 50
                db.flush()

            if settings.DEMO_MODE:
                pass  # no artificial delay

            # --- Stage 5: Structured Field Extraction ---
            extracted_fields = extractor.extract_fields(all_ocr_by_region)

            # Mathematical cross-check (Rule 6(11): Unit Sale Price vs MRP / Net Quantity)
            mrp_f = extracted_fields.get("mrp")
            qty_f = extracted_fields.get("net_quantity")
            usp_f = extracted_fields.get("unit_sale_price")
            if mrp_f and qty_f and usp_f:
                try:
                    mrp_v = float(mrp_f.normalized_value.get("normalized_value", 0.0) or 0.0)
                    qty_v = float(qty_f.normalized_value.get("normalized_value", 0.0) or 0.0)
                    qty_u = str(qty_f.normalized_value.get("unit", "") or "")
                    usp_v = float(usp_f.normalized_value.get("normalized_value", 0.0) or 0.0)
                    usp_u = str(usp_f.normalized_value.get("unit", "") or "")
                    usp_f.normalized_value["math_consistency"] = InformationExtractor.validate_usp_consistency(
                        mrp_v, qty_v, qty_u, usp_v, usp_u
                    )
                except Exception as c_exc:
                    logger.warning(f"USP math check skipped: {c_exc}")

            # Persist ExtractedField rows with provenance link
            for field_name, norm_field in extracted_fields.items():
                src_ocr_id = None
                spans_meta = all_ocr_by_region.get(field_name, [])
                if spans_meta and spans_meta[0].get("ocr_result_id"):
                    try:
                        src_ocr_id = uuid.UUID(spans_meta[0]["ocr_result_id"])
                    except Exception:
                        src_ocr_id = None

                ef = ExtractedField(
                    id=uuid.uuid4(),
                    inspection_id=inspection_uuid,
                    field_name=field_name,
                    raw_value=norm_field.raw_value,
                    normalized_value=norm_field.normalized_value,
                    confidence=norm_field.confidence,
                    source_ocr_id=src_ocr_id,
                )
                db.add(ef)
            db.flush()

            if analysis_task:
                analysis_task.stage = "COMPLIANCE_EVALUATION"
                analysis_task.progress_percent = 75
                db.flush()

            if settings.DEMO_MODE:
                pass  # no artificial delay

            # --- Stage 6: Deterministic Rule Engine Evaluation ---
            rules = RuleLoader.load_seed_rules()

            # Load active rule versions from DB (prefer DB rules over seed file)
            active_rule_versions = list(
                db.execute(
                    select(RuleVersion).where(
                        RuleVersion.status == "published",
                        (RuleVersion.active_until == None) | (RuleVersion.active_until >= date.today()),
                    )
                ).scalars().all()
            )

            rule_engine = RuleEngine(rules)
            extracted_for_engine = {
                field_name: {
                    "raw_value": nf.raw_value,
                    "normalized_value": nf.normalized_value,
                    "confidence": nf.confidence,
                    "bbox": nf.bbox,
                }
                for field_name, nf in extracted_fields.items()
            }

            evaluation_results = rule_engine.evaluate_inspection(
                extracted_fields=extracted_for_engine,
                product_category=inspection.category or "ALL",
            )

            # --- Confidence Gate Post-Processing ---
            # Override any rule result to NEEDS_REVIEW if its evidence fields were
            # detected but had exclusively low-confidence OCR (< 0.60).
            # This prevents a field that "exists" as a region but is unreadable from
            # being evaluated deterministically (where it would appear as missing → NON_COMPLIANT).
            if low_confidence_regions:
                from app.rule_engine.schema import ComplianceState, EvaluationResult
                updated_results = []
                for eval_result in evaluation_results:
                    affected = [
                        f for f in eval_result.evidence_fields
                        if f in low_confidence_regions
                    ]
                    if affected and eval_result.state not in (
                        ComplianceState.NOT_APPLICABLE,
                        ComplianceState.NEEDS_REVIEW,
                    ):
                        reason = (
                            f"Field(s) {affected} detected but all OCR confidence scores were "
                            f"below {conf_threshold}. Human officer review required to confirm "
                            "declaration text."
                        )
                        logger.info(
                            f"Rule {eval_result.rule_key}: overriding {eval_result.state.value} "
                            f"→ NEEDS_REVIEW (low OCR confidence on {affected})"
                        )
                        updated_results.append(
                            EvaluationResult(
                                rule_key=eval_result.rule_key,
                                rule_version=eval_result.rule_version,
                                legal_reference=eval_result.legal_reference,
                                state=ComplianceState.NEEDS_REVIEW,
                                confidence=eval_result.confidence,
                                violation_description=reason,
                                explanation=reason,
                                evidence_fields=eval_result.evidence_fields,
                            )
                        )
                    else:
                        updated_results.append(eval_result)
                evaluation_results = updated_results

            # Persist ComplianceCheck + Violation + Evidence
            rv_by_key: Dict[str, uuid.UUID] = {}
            for rv in active_rule_versions:
                rule_obj = db.execute(select(Rule).where(Rule.id == rv.rule_id)).scalar_one_or_none()
                if rule_obj:
                    rv_by_key[rule_obj.rule_key] = rv.id

            for eval_result in evaluation_results:
                rule_version_id = rv_by_key.get(eval_result.rule_key)
                if not rule_version_id:
                    continue

                check_id = uuid.uuid4()
                check = ComplianceCheck(
                    id=check_id,
                    inspection_id=inspection_uuid,
                    rule_version_id=rule_version_id,
                    result=eval_result.state.value,
                    confidence=eval_result.confidence,
                    system_generated=True,
                )
                db.add(check)
                db.flush()

                # Add violation if non-compliant or needs review
                if eval_result.state.value in ("NON_COMPLIANT", "NEEDS_REVIEW") and eval_result.violation_description:
                    violation = Violation(
                        id=uuid.uuid4(),
                        compliance_check_id=check_id,
                        severity=_get_severity_for_rule(eval_result.rule_key, active_rule_versions, db),
                        description=eval_result.violation_description,
                    )
                    db.add(violation)

                # Attach per-region evidence
                evidence_attached = False
                for req_field in eval_result.evidence_fields:
                    field_spans = all_ocr_by_region.get(req_field, [])
                    for s in field_spans:
                        ev_image_id = uuid.UUID(s["image_id"]) if s.get("image_id") else None
                        ev_region_id = uuid.UUID(s["region_id"]) if s.get("region_id") else None
                        ev_ocr_id = uuid.UUID(s["ocr_result_id"]) if s.get("ocr_result_id") else None
                        evidence = Evidence(
                            id=uuid.uuid4(),
                            compliance_check_id=check_id,
                            image_id=ev_image_id,
                            region_id=ev_region_id,
                            ocr_result_id=ev_ocr_id,
                            cropped_image_uri=s.get("crop_uri"),
                        )
                        db.add(evidence)
                        evidence_attached = True

                # If no direct region evidence (e.g. missing field), attach package image for officer review
                if not evidence_attached and image_ids_by_type:
                    first_image_id = next(iter(image_ids_by_type.values()))
                    evidence = Evidence(
                        id=uuid.uuid4(),
                        compliance_check_id=check_id,
                        image_id=first_image_id,
                    )
                    db.add(evidence)

            db.flush()

            # --- Stage 7: Compute and Persist Overall Result ---
            all_results = [r.state.value for r in evaluation_results]
            if "NON_COMPLIANT" in all_results:
                overall = "NON_COMPLIANT"
            elif "NEEDS_REVIEW" in all_results:
                overall = "NEEDS_REVIEW"
            else:
                overall = "COMPLIANT"

            inspection.overall_result = overall
            inspection.status = "completed"
            if analysis_task:
                analysis_task.status = "completed"
                analysis_task.stage = "COMPLETED"
                analysis_task.progress_percent = 100
                analysis_task.completed_at = datetime.utcnow()
            db.commit()

            logger.info(f"Pipeline completed for inspection {inspection_id}. Result: {overall}")
            return {
                "inspection_id": inspection_id,
                "status": "COMPLETED",
                "overall_result": overall,
                "regions_detected": sum(len(v) for v in all_ocr_by_region.values()),
                "fields_extracted": len(extracted_fields),
                "rules_evaluated": len(evaluation_results),
            }

        except Exception as exc:
            logger.error(f"Pipeline failed for inspection {inspection_id}: {exc}", exc_info=True)
            db.rollback()
            try:
                inspection = db.execute(select(Inspection).where(Inspection.id == inspection_uuid)).scalar_one_or_none()
                if inspection:
                    inspection.status = "failed"
                    inspection.overall_result = "NEEDS_REVIEW"
                if task_id:
                    analysis_task = db.execute(
                        select(InspectionAnalysisTask).where(InspectionAnalysisTask.celery_task_id == task_id)
                    ).scalar_one_or_none()
                    if analysis_task:
                        exhausted = self.request.retries >= self.max_retries
                        analysis_task.status = "failed" if exhausted else "retrying"
                        analysis_task.stage = "FAILED" if exhausted else "RETRYING"
                        analysis_task.error_message = str(exc)[:2000]
                        if exhausted:
                            analysis_task.completed_at = datetime.utcnow()
                db.commit()
            except Exception:
                db.rollback()
                pass
            raise self.retry(exc=exc, countdown=30)


def _get_severity_for_rule(rule_key: str, rule_versions: list, db) -> str:
    """Look up severity for a rule from loaded versions, defaulting to Major."""
    from app.models.rule import Rule
    from sqlalchemy import select
    for rv in rule_versions:
        rule = db.execute(select(Rule).where(Rule.id == rv.rule_id)).scalar_one_or_none()
        if rule and rule.rule_key == rule_key:
            return rule.severity or "Major"
    return "Major"
