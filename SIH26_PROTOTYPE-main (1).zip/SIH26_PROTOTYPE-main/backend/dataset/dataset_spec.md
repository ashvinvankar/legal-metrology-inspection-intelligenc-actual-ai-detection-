# Legal Metrology Package Declaration Dataset Specification (SLM-DATA-V1)

## 1. Overview & Objective
This dataset specification provides guidelines for curating, annotating, and partitioning package label imagery to train and benchmark custom declaration-region detectors (YOLOv8/YOLO11) and OCR models for Indian Legal Metrology compliance verification under the Legal Metrology (Packaged Commodities) Rules, 2011.

## 2. Canonical Classes (10 Declaration Types)
All annotations follow standard YOLO format normalized coordinates (`class_id x_center y_center width height` in `[0..1]`).

| Class ID | Canonical Class Name | Description | Mandatory Legal Reference |
|---|---|---|---|
| `0` | `mrp` | Maximum Retail Price inclusive of all taxes | Rule 6(1)(e) |
| `1` | `net_quantity` | Net quantity in weight/volume/units | Rule 6(1)(f) |
| `2` | `manufacturer_name` | Name of manufacturer or packer | Rule 6(1)(a) |
| `3` | `manufacturer_address` | Complete physical address with PIN code | Rule 6(1)(a) |
| `4` | `packer_name` | Name of packing entity (if distinct) | Rule 6(1)(a) |
| `5` | `consumer_care_contact` | Consumer complaint phone/email/address | Rule 6(1)(g) |
| `6` | `date_of_manufacture` | Month & year of manufacture/packing | Rule 6(1)(d) |
| `7` | `country_of_origin` | Country of origin/manufacture | Rule 6(1)(ea) |
| `8` | `unit_sale_price` | Price per standard unit (e.g. ₹/g, ₹/ml) | Rule 6(11) |
| `9` | `importer_name` | Name and address of importer | Rule 6(1)(a) |

## 3. Coverage & Diversity Requirements
To ensure model robustness in field operations, the dataset must meet minimum distribution quotas:

### 3.1 Script & Language Distribution
- **English**: ≥ 50%
- **Hindi (Devanagari)**: ≥ 25%
- **Bilingual / Mixed Script**: ≥ 25%

### 3.2 Product Category Coverage
- **Packaged Food & Beverages** (snacks, edible oils, spices, dairy, beverages)
- **Cosmetics & Personal Care** (shampoos, lotions, soaps, toothpastes)
- **Household Goods** (detergents, cleaners, disinfectants)
- **Consumer Electronics & Accessories** (chargers, bulbs, cables)
- **Apparel & Textiles**
- **Imported Commodities**

### 3.3 Environmental & Distortion Variations
- **Glare & Specular Highlights** (reflective plastic foils, metallized pouches)
- **Motion Blur & Out-of-Focus**
- **Perspective Distortion & Skew** (camera angles 15°–45°)
- **Curved Surfaces** (bottles, cans, flexible pouches)
- **Occlusion & Wrinkles** (crinkled chip packets, folded corners)
- **Small Print** (font sizes < 1.5 mm height)

### 3.4 Compliance Scenario Distribution
- **Fully Compliant**: All mandatory declarations clearly visible and conforming.
- **Missing Mandatory Declarations**: Omits one or more declarations (e.g. missing country of origin or consumer care).
- **Blank / Unprinted Declarations**: Field label is printed (e.g. "Mfg Date: "), but the stamped date area is left blank.
- **Misleading / Deceptive Declarations**: Declarations hidden in seams or printed below minimum legal contrast.

## 4. Brand-Level Data Partitioning (Zero Data Leakage)
To prevent memorization of brand font/packaging templates:
- Partitions **MUST** be split by **Brand / Manufacturer Entity**, NEVER by random image assignment.
- **Train Set (70%)**: Unique brand set A (e.g. Haldiram, Amul, Patanjali).
- **Validation Set (15%)**: Unique brand set B (e.g. Britannia, Nestle, Dabur).
- **Test / Golden Corpus Set (15%)**: Unique brand set C (e.g. Balaji, Parle, ITC).

## 5. YOLO Directory Layout
```
dataset/
├── data.yaml
├── images/
│   ├── train/
│   ├── val/
│   └── test/
└── labels/
    ├── train/
    ├── val/
    └── test/
```

`data.yaml` definition:
```yaml
path: /path/to/dataset
train: images/train
val: images/val
test: images/test

names:
  0: mrp
  1: net_quantity
  2: manufacturer_name
  3: manufacturer_address
  4: packer_name
  5: consumer_care_contact
  6: date_of_manufacture
  7: country_of_origin
  8: unit_sale_price
  9: importer_name
```
