"""Dataset Validation and Integrity Utility (SLM-DATA-V1).

Validates:
- YOLO label files against images
- Canonical class index range (0..9)
- Normalized bounding box bounds (0 <= val <= 1)
- Positive box area
- Class distribution statistics
"""

import argparse
from pathlib import Path
from typing import Dict, List, Tuple

CANONICAL_CLASSES: Dict[int, str] = {
    0: "mrp",
    1: "net_quantity",
    2: "manufacturer_name",
    3: "manufacturer_address",
    4: "packer_name",
    5: "consumer_care_contact",
    6: "date_of_manufacture",
    7: "country_of_origin",
    8: "unit_sale_price",
    9: "importer_name",
}


def validate_split(split_dir: Path) -> Tuple[bool, List[str], Dict[str, int]]:
    """Validate a dataset split directory (e.g. train, val, or test)."""
    images_dir = split_dir / "images"
    labels_dir = split_dir / "labels"

    errors: List[str] = []
    class_counts: Dict[str, int] = {name: 0 for name in CANONICAL_CLASSES.values()}

    if not images_dir.exists():
        return False, [f"Images dir missing: {images_dir}"], class_counts

    image_files = list(images_dir.glob("*.jpg")) + list(images_dir.glob("*.jpeg")) + list(images_dir.glob("*.png"))
    if not image_files:
        errors.append(f"No image files found in {images_dir}")

    for img_path in image_files:
        lbl_path = labels_dir / f"{img_path.stem}.txt"
        if not lbl_path.exists():
            errors.append(f"Missing label file for image: {img_path.name}")
            continue

        with open(lbl_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

        for line_num, line in enumerate(lines, 1):
            parts = line.strip().split()
            if not parts:
                continue
            if len(parts) != 5:
                errors.append(f"{lbl_path.name}: line {line_num} has {len(parts)} tokens (expected 5)")
                continue

            try:
                cls_id = int(parts[0])
                xc, yc, w, h = float(parts[1]), float(parts[2]), float(parts[3]), float(parts[4])
            except ValueError:
                errors.append(f"{lbl_path.name}: line {line_num} has non-numeric coordinates")
                continue

            if cls_id not in CANONICAL_CLASSES:
                errors.append(f"{lbl_path.name}: line {line_num} has invalid class ID {cls_id} (allowed: 0..9)")
                continue

            # Check bbox boundaries
            if not (0.0 <= xc <= 1.0 and 0.0 <= yc <= 1.0 and 0.0 < w <= 1.0 and 0.0 < h <= 1.0):
                errors.append(f"{lbl_path.name}: line {line_num} bbox coordinates out of range [0, 1]")
                continue

            class_name = CANONICAL_CLASSES[cls_id]
            class_counts[class_name] += 1

    is_valid = len(errors) == 0
    return is_valid, errors, class_counts


def main():
    parser = argparse.ArgumentParser(description="Validate Legal Metrology YOLO Dataset")
    parser.add_argument("--data-dir", type=str, required=True, help="Path to dataset directory containing images/ and labels/")
    args = parser.parse_args()

    data_dir = Path(args.data_dir)
    print(f"Validating dataset at: {data_dir}")

    valid, errors, counts = validate_split(data_dir)
    print("\n--- Class Distribution ---")
    for cls_name, cnt in counts.items():
        print(f"  {cls_name:<25}: {cnt}")

    if not valid:
        print(f"\n[FAIL] Found {len(errors)} error(s):")
        for err in errors[:20]:
            print(f"  - {err}")
        if len(errors) > 20:
            print(f"  ... and {len(errors) - 20} more errors.")
    else:
        print("\n[SUCCESS] All annotations and images are valid!")


if __name__ == "__main__":
    main()
