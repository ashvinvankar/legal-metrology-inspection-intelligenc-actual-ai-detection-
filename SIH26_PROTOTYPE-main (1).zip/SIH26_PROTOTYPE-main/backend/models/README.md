# Model Weights Directory

Place trained ML model weights in this directory for real inference mode.

## Region Detection (YOLO)

**File**: `slm_detector.pt`

This is a YOLO (YOLOv8/YOLO11) model trained to detect all **10 mandatory
Legal Metrology declaration regions** on packaged commodity labels.

The model weights must be verified against the SHA-256 checksum in
`model_metadata.json` before the worker will load them.

### Expected Class Names (10 Canonical Classes)

| Class ID | Canonical Name | Legal Reference |
|---|---|---|
| 0 | `mrp` | Rule 6(1)(e) |
| 1 | `net_quantity` | Rule 6(1)(f) |
| 2 | `manufacturer_name` | Rule 6(1)(a) |
| 3 | `manufacturer_address` | Rule 6(1)(a) |
| 4 | `packer_name` | Rule 6(1)(a) |
| 5 | `consumer_care_contact` | Rule 6(1)(g) |
| 6 | `date_of_manufacture` | Rule 6(1)(d) |
| 7 | `country_of_origin` | Rule 6(1)(ea) |
| 8 | `unit_sale_price` | Rule 6(11) |
| 9 | `importer_name` | Rule 6(1)(a) |

> **Legacy aliases**: The detector normalizes `consumer_care → consumer_care_contact`
> and `date_declaration → date_of_manufacture` via `LABEL_ALIASES` in `detector.py`.
> Models emitting these old names will still work, but all new training data must
> use the canonical names above.

### How to Enable Real Inference

```bash
# 1. Place your model weights here (must match SHA-256 in model_metadata.json):
cp path/to/your/slm_detector.pt backend/models/slm_detector.pt

# 2. Install AI dependencies:
pip install -r backend/requirements-ai.txt

# 3. Set the environment flags in .env:
USE_REAL_MODELS=true
DEMO_MODE=false
OCR_LANGUAGES=["en","hi"]

# 4. Restart the Celery worker:
docker-compose restart ai_worker
```

### Training a New Model

Use the Ultralytics YOLO framework. Dataset must follow `backend/dataset/dataset_spec.md`.

```bash
pip install ultralytics
yolo train data=dataset/data.yaml model=yolov8n.pt epochs=100 imgsz=640 \
    name=slm_detector project=runs/detect
```

After training, update `model_metadata.json`:

```bash
python -c "
import hashlib, json
sha = hashlib.sha256(open('models/slm_detector.pt','rb').read()).hexdigest()
meta = json.load(open('models/model_metadata.json'))
meta['sha256'] = sha
meta['version'] = '1.x.x'   # bump version
json.dump(meta, open('models/model_metadata.json','w'), indent=2)
print('Checksum updated:', sha)
"
```

## OCR (EasyOCR)

EasyOCR models are downloaded automatically on first use (~200 MB for `en` + `hi`).
No manual model placement is required.

- Language models cache at: `~/.EasyOCR/model/`
- **Supported languages**: `en` (English), `hi` (Hindi/Devanagari)
- **Benchmark note**: PaddleOCR is a candidate replacement for dense-text labels
  (FMCG, multilingual). Evaluate before upgrading.

## Demo Mode (Offline Testing)

Without model weights, set **both** flags to use the deterministic mock pipeline:

```env
USE_REAL_MODELS=false
DEMO_MODE=true
```

This returns structured mock regions and OCR for all 10 canonical classes,
enabling end-to-end testing of the extraction → rule engine → compliance flow
without GPU or model files.

> **Production safety**: `DEMO_MODE=false` (the default) prevents any mock
> fallback. If `USE_REAL_MODELS=true` and weights are missing, the worker logs
> a clear error and routes the inspection to `NEEDS_REVIEW`.
