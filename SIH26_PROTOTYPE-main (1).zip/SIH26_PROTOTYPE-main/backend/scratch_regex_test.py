import re

mrp_pat = re.compile(
    r"(?:M\.?R\.?P\b|mrp\b|maximum\s+retail|incl\b|inclusive"
    r"|of\s+all\b|all\s+tax|all\s+tak|tax(?:es)?\b"
    r"|of\s+all\s+tax|of\s+all\s+tak|incl\.?\s*of|\u20b9|\bRs\.?\b)",
    re.IGNORECASE
)

date_pat = re.compile(
    r"(?:mfg\.?|mfg\s+date|manufacture|manufactured|pkd\.?|packed|packing\s+date|expiry|expir|best\s+before|b\.?b\.?|best\s+by|best\s+before\s+use)",
    re.IGNORECASE
)

mrp_tests = [
    ("OF AlL TAKES)", True),    # garbled "(INCL. OF ALL TAXES)"
    ("POTATO WAFERS", False),   # no MRP signal
    ("MRP: blank", True),       # MRP keyword
    ("Rs. 120", True),          # currency marker
    ("(INCL. OF ALL TAXES)", True),  # full disclosure
    ("₹ (INCL. OF ALL TAXES)", True),  # with rupee symbol
]

date_tests = [
    ("pkD; FXPIR", True),       # garbled "PKD.; EXPIRY DATE:"
    ("Mfg. Date: 08/2026", True),
    ("POTATO WAFERS", False),
    ("FXPIR", False),           # garbled EXPIRY alone (no PKD/MFG prefix)
]

print("=== MRP structural keyword tests ===")
all_ok = True
for text, expect in mrp_tests:
    m = mrp_pat.search(text)
    got = bool(m)
    status = "OK" if got == expect else "FAIL"
    matched = m.group(0) if m else None
    print(f"  [{status}] {text!r} => matched={matched!r}, expect={expect}, got={got}")
    if got != expect:
        all_ok = False

print("\n=== Date structural keyword tests ===")
for text, expect in date_tests:
    m = date_pat.search(text)
    got = bool(m)
    status = "OK" if got == expect else "FAIL"
    matched = m.group(0) if m else None
    print(f"  [{status}] {text!r} => matched={matched!r}, expect={expect}, got={got}")
    if got != expect:
        all_ok = False

print(f"\n{'ALL PASS' if all_ok else 'SOME FAILURES'}")
