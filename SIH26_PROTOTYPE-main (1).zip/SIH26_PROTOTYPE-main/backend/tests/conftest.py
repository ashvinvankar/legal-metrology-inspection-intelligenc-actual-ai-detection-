"""Isolated database and HTTP fixtures for API tests.

Each test gets a separate temporary SQLite database and a FastAPI dependency
override.  Tests therefore never initialise or mutate the developer's local
``slm_cip.db``. PostgreSQL/MinIO/Celery contract tests belong in a dedicated
Compose/Testcontainers suite.
"""

import sys
from pathlib import Path

import pytest
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import async_sessionmaker, create_async_engine

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app.core.database import Base, get_db
import app.models  # noqa: F401 -- register every ORM table before create_all
from app.main import app as fastapi_app


@pytest.fixture
async def db_session(tmp_path):
    database_url = f"sqlite+aiosqlite:///{tmp_path / 'slm_cip_test.db'}"
    engine = create_async_engine(database_url, connect_args={"check_same_thread": False})
    session_factory = async_sessionmaker(engine, expire_on_commit=False)
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)
    async with session_factory() as session:
        yield session
        await session.rollback()
    await engine.dispose()


@pytest.fixture
async def async_client(db_session):
    async def override_get_db():
        yield db_session

    fastapi_app.dependency_overrides[get_db] = override_get_db
    transport = ASGITransport(app=fastapi_app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client
    fastapi_app.dependency_overrides.clear()
