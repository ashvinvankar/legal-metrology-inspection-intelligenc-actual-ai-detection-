"""Unit and Integration Tests for RegionDetector (YOLOv8/YOLO11)."""

import pytest
import numpy as np
import cv2

from app.core.config import settings
from app.pipeline.detector import (
    RegionDetector,
    DetectedBoundingBox,
    CANONICAL_REGION_CLASSES,
    _MOCK_REGIONS,
)


def _make_dummy_image() -> bytes:
    """Create a 640x640 blank image encoded as JPEG."""
    img = np.zeros((640, 640, 3), dtype=np.uint8)
    cv2.putText(img, "TEST LABEL", (50, 300), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
    ok, buf = cv2.imencode(".jpg", img)
    assert ok
    return buf.tobytes()


class TestRegionDetector:

    def test_canonical_classes_count(self):
        """Must have exactly 10 canonical Legal Metrology classes."""
        assert len(CANONICAL_REGION_CLASSES) == 10
        assert "mrp" in CANONICAL_REGION_CLASSES
        assert "net_quantity" in CANONICAL_REGION_CLASSES
        assert "manufacturer_name" in CANONICAL_REGION_CLASSES
        assert "manufacturer_address" in CANONICAL_REGION_CLASSES
        assert "packer_name" in CANONICAL_REGION_CLASSES
        assert "consumer_care_contact" in CANONICAL_REGION_CLASSES
        assert "date_of_manufacture" in CANONICAL_REGION_CLASSES
        assert "country_of_origin" in CANONICAL_REGION_CLASSES
        assert "unit_sale_price" in CANONICAL_REGION_CLASSES
        assert "importer_name" in CANONICAL_REGION_CLASSES

    def test_metadata_loading(self):
        """Metadata must load valid approved classes and thresholds."""
        meta = RegionDetector.load_metadata()
        assert meta.get("model_name") == "slm_detector"
        assert meta.get("version") == "1.0.0"
        assert meta.get("confidence_threshold") == 0.25
        assert len(meta.get("classes", [])) == 10

    def test_checksum_verification(self):
        """Checksum verification checks model file."""
        from pathlib import Path
        model_path = Path(__file__).parent.parent / "models" / "slm_detector.pt"
        if model_path.exists():
            valid, err = RegionDetector.verify_checksum(model_path)
            assert valid is True
            assert err is None

    def test_production_mode_no_mock_fallback_on_blank_image(self, monkeypatch):
        """In production mode (DEMO_MODE=False), blank image must return empty list, NOT mock regions."""
        monkeypatch.setattr(settings, "DEMO_MODE", False)
        monkeypatch.setattr(settings, "USE_REAL_MODELS", True)

        detector = RegionDetector(use_real_model=True)
        img_bytes = _make_dummy_image()
        regions = detector.detect_regions(img_bytes)

        # Blank image has no label boxes; must NEVER return the 8 mock regions
        assert regions != _MOCK_REGIONS
        for r in regions:
            assert r.label in CANONICAL_REGION_CLASSES

    def test_demo_mode_returns_mock_when_explicitly_enabled(self, monkeypatch):
        """When DEMO_MODE=True and use_real_model=False, returns structured mock regions."""
        monkeypatch.setattr(settings, "DEMO_MODE", True)
        monkeypatch.setattr(settings, "USE_REAL_MODELS", False)

        detector = RegionDetector(use_real_model=False)
        regions = detector.detect_regions(b"dummy")
        assert len(regions) > 0
        assert regions[0].label == "mrp"

    def test_corrupted_image_handling(self, monkeypatch):
        """Corrupted/invalid image bytes must return empty list with structured error, never crash.

        Two acceptable failure modes:
        - Model loaded: 'Failed to decode image' (corrupted bytes)
        - Model not installed: dependency or init error (still structured, not None)
        Both scenarios must return ([], non-None error string).
        """
        monkeypatch.setattr(settings, "DEMO_MODE", False)
        detector = RegionDetector()
        regions, err = detector.detect_regions_with_status(b"corrupted-non-image-data")
        assert regions == []
        assert err is not None, "A structured error string must always be returned, never None."
        assert isinstance(err, str) and len(err) > 0, "Error must be a non-empty string."
        # Either the image failed to decode, or the model/dependency was unavailable.
        acceptable = (
            "Failed to decode image" in err
            or "not installed" in err
            or "not found" in err
            or "unavailable" in err
            or "Cannot run" in err
            or "Failed to initialize" in err
        )
        assert acceptable, (
            f"Unexpected error message for corrupted image: '{err}'. "
            "Must reference image decode failure, missing dependency, or unavailable model."
        )

    def test_crop_region_valid_bbox(self):
        """crop_region extracts correct sub-image within [0..1] range."""
        img_bytes = _make_dummy_image()
        crop = RegionDetector.crop_region(img_bytes, [0.1, 0.1, 0.5, 0.5])
        assert crop is not None
        assert len(crop) > 0

    def test_crop_region_invalid_bbox_returns_none(self):
        """Invalid bounding box (e.g. x2 <= x1) safely returns None."""
        img_bytes = _make_dummy_image()
        assert RegionDetector.crop_region(img_bytes, [0.5, 0.5, 0.1, 0.1]) is None
        assert RegionDetector.crop_region(b"not-image", [0.1, 0.1, 0.5, 0.5]) is None

    def test_ocr_anchor_fallback_never_invents_boxes(self, monkeypatch):
        """
        When YOLO returns 0 detections, the OCR-anchor fallback must only propose
        bounding boxes anchored to text that is actually visible in the image.

        - A blank (all-black) image contains no text → anchor fallback must return []
          (not mock regions).
        - An image containing the literal string 'M.R.P' must produce a box for 'mrp'
          but not for fields with no matching text (e.g. 'date_of_manufacture' if no
          date-like text is present).
        """
        import numpy as np
        import cv2
        from app.pipeline.ocr_engine import OCREngine

        monkeypatch.setattr(settings, "DEMO_MODE", False)
        monkeypatch.setattr(settings, "USE_REAL_MODELS", True)

        # --- 1. Blank image: anchor fallback must produce no proposals ---
        blank = np.zeros((640, 640, 3), dtype=np.uint8)
        _, blank_buf = cv2.imencode(".jpg", blank)
        blank_bytes = blank_buf.tobytes()

        detector = RegionDetector(use_real_model=True)

        # We only test the anchor method directly (YOLO may not be loaded in CI).
        # Ensure EasyOCR is initialized for the fallback.
        OCREngine._ensure_reader_initialized(["en"])
        if OCREngine._reader is None:
            pytest.skip("EasyOCR reader unavailable — skipping anchor fallback test")

        blank_cv2 = cv2.imdecode(np.frombuffer(blank_bytes, np.uint8), cv2.IMREAD_COLOR)
        h, w = blank_cv2.shape[:2]
        proposals = detector._propose_regions_from_ocr(blank_cv2, w, h)

        # A blank image has no text → zero proposals (no invented boxes)
        assert proposals == [], (
            f"OCR-anchor fallback invented {len(proposals)} region(s) on a blank image. "
            "It must only produce boxes anchored to real text."
        )

        # --- 2. Image with explicit MRP text: only mrp proposal expected ---
        mrp_img = np.ones((200, 640, 3), dtype=np.uint8) * 240
        cv2.putText(mrp_img, "M.R.P.: Rs. 50", (20, 120), cv2.FONT_HERSHEY_SIMPLEX, 1.5, (0, 0, 0), 3)
        _, mrp_buf = cv2.imencode(".jpg", mrp_img)
        mrp_cv2 = cv2.imdecode(np.frombuffer(mrp_buf.tobytes(), np.uint8), cv2.IMREAD_COLOR)
        mh, mw = mrp_cv2.shape[:2]

        mrp_proposals = detector._propose_regions_from_ocr(mrp_cv2, mw, mh)
        labels = {p.label for p in mrp_proposals}

        # MRP text is present → at least an mrp proposal
        assert "mrp" in labels, (
            "OCR-anchor fallback failed to detect 'mrp' region on image containing 'M.R.P.' text."
        )
        # Proposals that exist must be canonical
        for p in mrp_proposals:
            assert p.label in CANONICAL_REGION_CLASSES, (
                f"Anchor fallback returned non-canonical label: {p.label}"
            )
            # Bounding boxes must be normalized [0..1]
            assert all(0.0 <= v <= 1.0 for v in p.bbox), (
                f"Anchor proposal '{p.label}' has out-of-range bbox: {p.bbox}"
            )
