"""Field-contract alignment tests across Extractor, Rules JSON, and Validator."""

import pytest
import json
from pathlib import Path

from app.pipeline.extractor import InformationExtractor, CANONICAL_FIELDS, FIELD_ALIASES
from app.rule_engine.validator import FieldValidators
from app.rule_engine.engine import RuleEngine
from app.rule_engine.schema import ComplianceState


class TestFieldContract:

    def test_canonical_fields_vocabulary(self):
        """Verify the 10 canonical field names."""
        expected = {
            "mrp",
            "net_quantity",
            "manufacturer_name",
            "manufacturer_address",
            "packer_name",
            "consumer_care_contact",
            "date_of_manufacture",
            "country_of_origin",
            "unit_sale_price",
            "importer_name",
        }
        assert set(CANONICAL_FIELDS) == expected

    def test_rules_json_uses_canonical_fields(self):
        """Verify that rules/pc_rules_2011_v1.json uses only canonical field names in input_fields."""
        from app.rule_engine.loader import RuleLoader
        rules = RuleLoader.load_seed_rules()
        assert len(rules) > 0, "Seed rules could not be loaded"

        canonical_set = set(CANONICAL_FIELDS)
        for rule in rules:
            input_fields = rule.get("input_fields", [])
            for f in input_fields:
                assert f in canonical_set, f"Rule {rule.get('rule_key')} uses uncanonical field '{f}'"

    def test_extractor_emits_date_of_manufacture(self):
        """Extractor must emit 'date_of_manufacture', not 'date_declaration'."""
        extractor = InformationExtractor()
        spans_input = {
            "date_of_manufacture": [{"text": "Mfg: 05/2026", "confidence": 0.95, "bbox": [0, 0, 100, 20]}]
        }
        res = extractor.extract_fields(spans_input)
        assert "date_of_manufacture" in res
        assert "date_declaration" not in res
        assert res["date_of_manufacture"].normalized_value["month"] == "05"
        assert res["date_of_manufacture"].normalized_value["year"] == "2026"

    def test_extractor_aliases_legacy_date_declaration(self):
        """Legacy 'date_declaration' label must alias to 'date_of_manufacture'."""
        extractor = InformationExtractor()
        spans_input = {
            "date_declaration": [{"text": "Mfg Date: 12/2025", "confidence": 0.94, "bbox": [0, 0, 100, 20]}]
        }
        res = extractor.extract_fields(spans_input)
        assert "date_of_manufacture" in res
        assert "date_declaration" not in res

    def test_extractor_emits_consumer_care_contact(self):
        """Extractor must emit 'consumer_care_contact', not 'consumer_care'."""
        extractor = InformationExtractor()
        spans_input = {
            "consumer_care_contact": [
                {"text": "Call: 1800-222-3333 or care@example.com", "confidence": 0.92, "bbox": [0, 0, 200, 20]}
            ]
        }
        res = extractor.extract_fields(spans_input)
        assert "consumer_care_contact" in res
        assert "consumer_care" not in res
        norm = res["consumer_care_contact"].normalized_value
        assert "1800" in (norm.get("phone") or "")
        assert "care@example.com" in (norm.get("email") or "")

    def test_extractor_emits_manufacturer_address(self):
        """Extractor must properly extract and normalize manufacturer_address."""
        extractor = InformationExtractor()
        spans_input = {
            "manufacturer_address": [
                {"text": "Plot 45, GIDC Industrial Estate, Rajkot - 360003, Gujarat", "confidence": 0.91, "bbox": [0, 0, 300, 20]}
            ]
        }
        res = extractor.extract_fields(spans_input)
        assert "manufacturer_address" in res
        norm = res["manufacturer_address"].normalized_value
        assert norm.get("pincode") == "360003"
        assert norm.get("present") is True

    def test_extractor_emits_unit_sale_price(self):
        """Extractor must properly extract unit_sale_price."""
        extractor = InformationExtractor()
        spans_input = {
            "unit_sale_price": [
                {"text": "Unit Sale Price: ₹ 0.25 / g", "confidence": 0.93, "bbox": [0, 0, 150, 20]}
            ]
        }
        res = extractor.extract_fields(spans_input)
        assert "unit_sale_price" in res
        norm = res["unit_sale_price"].normalized_value
        assert norm.get("normalized_value") == 0.25
        assert norm.get("unit") == "g"
        assert norm.get("currency") == "INR"

    def test_rule_engine_validates_canonical_rules(self):
        """Rule engine evaluates canonical rule keys with canonical extracted fields."""
        from app.rule_engine.loader import RuleLoader
        rules = RuleLoader.load_seed_rules()
        assert len(rules) > 0, "Seed rules could not be loaded"

        engine = RuleEngine(rules)
        extracted = {
            "mrp": {
                "raw_value": "M.R.P.: ₹ 50.00 (Incl. of all taxes)",
                "normalized_value": {"value": "₹50", "normalized_value": 50.0, "currency": "INR"},
                "confidence": 0.95,
            },
            "net_quantity": {
                "raw_value": "Net Qty: 200 g",
                "normalized_value": {"value": "200 g", "normalized_value": 200.0, "unit": "g"},
                "confidence": 0.95,
            },
            "manufacturer_name": {
                "raw_value": "Balaji Wafers Pvt. Ltd.",
                "normalized_value": {"value": "Balaji Wafers Pvt. Ltd.", "present": True},
                "confidence": 0.94,
            },
            "manufacturer_address": {
                "raw_value": "Vajdi Vad, Kalawad Road, Rajkot - 360021, Gujarat",
                "normalized_value": {"value": "Vajdi Vad, Kalawad Road, Rajkot - 360021, Gujarat", "pincode": "360021", "present": True},
                "confidence": 0.93,
            },
            "date_of_manufacture": {
                "raw_value": "Mfg Date: 09/2026",
                "normalized_value": {"value": "09/2026", "month": "09", "year": "2026"},
                "confidence": 0.96,
            },
            "country_of_origin": {
                "raw_value": "Product of India",
                "normalized_value": {"value": "India", "present": True},
                "confidence": 0.95,
            },
            "consumer_care_contact": {
                "raw_value": "Consumer Care: 1800-233-1234 or care@balajiwafers.com",
                "normalized_value": {"value": "1800-233-1234", "phone": "1800-233-1234", "present": True},
                "confidence": 0.92,
            },
        }

        results = engine.evaluate_inspection(extracted, product_category="ALL")
        states = {r.rule_key: r.state for r in results}

        assert states["MANDATORY_MRP_DECLARATION"] == ComplianceState.COMPLIANT
        assert states["MANDATORY_NET_QUANTITY"] == ComplianceState.COMPLIANT
        assert states["MANDATORY_MANUFACTURER_PACKER_DETAILS"] == ComplianceState.COMPLIANT
        assert states["MANDATORY_DATE_OF_MANUFACTURE"] == ComplianceState.COMPLIANT
        assert states["MANDATORY_COUNTRY_OF_ORIGIN"] == ComplianceState.COMPLIANT
        assert states["MANDATORY_CONSUMER_CARE_DETAILS"] == ComplianceState.COMPLIANT
