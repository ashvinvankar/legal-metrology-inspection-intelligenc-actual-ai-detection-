"""Golden Corpus Regression Tests: Real Inference & Safety Checks."""

import pytest
from pathlib import Path
import json

from app.core.config import settings
from app.pipeline.detector import RegionDetector
from app.pipeline.ocr_engine import OCREngine
from app.pipeline.extractor import InformationExtractor
from app.rule_engine.engine import RuleEngine
from app.rule_engine.schema import ComplianceState


class TestGoldenCorpusBalaji:

    @pytest.fixture
    def balaji_image_bytes(self) -> bytes:
        """Load the Balaji sample image from sample_images/."""
        # Check both possible paths
        p1 = Path(__file__).parent.parent / "sample_images" / "balaji_sample.jpg"
        p2 = Path(__file__).parent.parent.parent / "sample_images" / "balaji_sample.jpg"
        img_path = p1 if p1.exists() else p2
        assert img_path.exists(), f"Balaji sample image not found at {p1} or {p2}"
        with open(img_path, "rb") as f:
            return f.read()

    def test_balaji_image_never_reports_mock_values(self, balaji_image_bytes, monkeypatch):
        """
        CRITICAL ACCEPTANCE CRITERIA:
        The Balaji image must NEVER report mock values such as 'Bharat Foods', '₹120', or '500g'.
        """
        monkeypatch.setattr(settings, "DEMO_MODE", False)
        monkeypatch.setattr(settings, "USE_REAL_MODELS", True)

        detector = RegionDetector(use_real_model=True)
        ocr_engine = OCREngine(use_real_model=True)
        extractor = InformationExtractor()

        # Run real detection
        regions = detector.detect_regions(balaji_image_bytes)

        all_ocr: dict = {}
        for region in regions:
            crop = RegionDetector.crop_region(balaji_image_bytes, region.bbox)
            if crop:
                spans = ocr_engine.extract_text(crop, region_label=region.label)
                all_ocr[region.label] = [{"text": s.text, "confidence": s.confidence, "bbox": s.bbox} for s in spans]

        # Extract structured fields
        extracted = extractor.extract_fields(all_ocr)

        # Check all raw and normalized values: NEVER fabricate mock data
        for field_name, field in extracted.items():
            raw_text = field.raw_value.lower()
            assert "bharat foods" not in raw_text, f"Field '{field_name}' fabricated 'Bharat Foods'!"
            assert "1800-xxx-xxxx" not in raw_text, f"Field '{field_name}' fabricated mock phone number!"

            norm_val = field.normalized_value or {}
            # Assert no invented MRP 120 or 500g
            if field_name == "mrp":
                assert norm_val.get("normalized_value") != 120.0, "MRP was fabricated as ₹120!"
            if field_name == "net_quantity":
                assert not (norm_val.get("normalized_value") == 500.0 and norm_val.get("unit") == "g"), "Net qty fabricated as 500g!"

    def test_balaji_image_real_ocr_detects_actual_label_text(self, balaji_image_bytes, monkeypatch):
        """Real OCR directly on the Balaji image extracts visible brand/country declarations.

        Requires: pip install -r requirements-ai.txt (easyocr).
        Skipped automatically if EasyOCR is not installed.
        """
        monkeypatch.setattr(settings, "DEMO_MODE", False)
        monkeypatch.setattr(settings, "USE_REAL_MODELS", True)

        ocr_engine = OCREngine(use_real_model=True)

        # Skip if OCR dependency is not installed (CI without requirements-ai.txt)
        if ocr_engine.last_error and "not installed" in (ocr_engine.last_error or ""):
            pytest.skip(f"EasyOCR not installed — skipping real OCR test: {ocr_engine.last_error}")
        if OCREngine._reader is None:
            pytest.skip("EasyOCR reader not initialized — skipping real OCR test")

        spans = ocr_engine.extract_text(balaji_image_bytes)
        assert len(spans) > 0, (
            "Real OCR on the Balaji image returned no text spans. "
            "Check that easyocr is installed and the image is not corrupted."
        )

        extracted_text = " ".join(s.text for s in spans).upper()
        # Verify real text from the Balaji wafer package is present
        assert "BALAJI" in extracted_text or "WAFERS" in extracted_text or "INDIA" in extracted_text

    def test_missing_declarations_route_to_missing_evidence(self, monkeypatch):
        """
        When mandatory declarations (e.g. MRP, net weight, date) are missing on an image crop,
        the system must record missing evidence or NEEDS_REVIEW, never invent compliant values.
        """
        monkeypatch.setattr(settings, "DEMO_MODE", False)
        from app.rule_engine.loader import RuleLoader
        rules = RuleLoader.load_seed_rules()
        assert len(rules) > 0, "Seed rules could not be loaded"

        engine = RuleEngine(rules)

        # Only manufacturer and country present; MRP and Net Qty are missing from label
        partial_evidence = {
            "manufacturer_name": {
                "raw_value": "Balaji Wafers Pvt. Ltd.",
                "normalized_value": {"value": "Balaji Wafers Pvt. Ltd.", "present": True},
                "confidence": 0.94,
            },
            "country_of_origin": {
                "raw_value": "Product of India",
                "normalized_value": {"value": "India", "present": True},
                "confidence": 0.95,
            },
        }

        eval_results = engine.evaluate_inspection(partial_evidence, product_category="ALL")
        states = {r.rule_key: r.state for r in eval_results}

        # Mandatory missing declarations must be NON_COMPLIANT, not COMPLIANT
        assert states["MANDATORY_MRP_DECLARATION"] == ComplianceState.NON_COMPLIANT
        assert states["MANDATORY_NET_QUANTITY"] == ComplianceState.NON_COMPLIANT
        assert states["MANDATORY_DATE_OF_MANUFACTURE"] == ComplianceState.NON_COMPLIANT
        # Present declarations evaluate compliant
        assert states["MANDATORY_COUNTRY_OF_ORIGIN"] == ComplianceState.COMPLIANT


class TestHindiOCRSupport:
    """Verifies that Hindi/Devanagari OCR support is functional."""

    def test_hindi_ocr_initialized_with_correct_languages(self, monkeypatch):
        """
        OCREngine must initialize EasyOCR with both 'en' and 'hi' when the
        default OCR_LANGUAGES config is used (which now includes Hindi).
        """
        monkeypatch.setattr(settings, "DEMO_MODE", False)
        monkeypatch.setattr(settings, "USE_REAL_MODELS", True)

        # Verify that the configured languages include Hindi
        assert "hi" in settings.OCR_LANGUAGES, (
            "OCR_LANGUAGES must include 'hi' (Hindi) for Indian packaged goods. "
            "Check app/core/config.py and .env"
        )
        assert "en" in settings.OCR_LANGUAGES, "OCR_LANGUAGES must always include 'en'."

    def test_hindi_ocr_does_not_crash_on_devanagari_image(self, monkeypatch):
        """
        EasyOCR initialized with ['en', 'hi'] must not crash or return an error
        when processing a synthetic Devanagari-script image.

        This is a smoke test to catch import/model-load failures early.
        It does NOT assert that specific Hindi characters are extracted correctly —
        that depends on real model weights and is evaluated separately.
        """
        import numpy as np
        import cv2

        monkeypatch.setattr(settings, "DEMO_MODE", False)
        monkeypatch.setattr(settings, "USE_REAL_MODELS", True)

        # Create a high-contrast image with ASCII text (CI-safe; Devanagari requires PIL/Pillow font)
        # The meaningful assertion here is that the engine handles the image without error.
        img = np.ones((120, 480, 3), dtype=np.uint8) * 255
        cv2.putText(img, "Bharat Pvt Ltd India", (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 0), 2)
        _, buf = cv2.imencode(".jpg", img)
        img_bytes = buf.tobytes()

        engine = OCREngine(languages=["en", "hi"], use_real_model=True)

        if engine.last_error and "not installed" in (engine.last_error or ""):
            pytest.skip("EasyOCR not installed — skipping Hindi OCR smoke test")

        # Must not raise
        spans, err = engine.extract_text_with_status(img_bytes, region_label="manufacturer_name")

        # Even if no Hindi text is present, the call must complete without a hard error
        assert err is None or "EasyOCR inference failed" not in err, (
            f"EasyOCR crashed processing image with ['en','hi'] languages: {err}"
        )
