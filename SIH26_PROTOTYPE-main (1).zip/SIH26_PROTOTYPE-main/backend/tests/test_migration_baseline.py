"""PostgreSQL clean-install migration contract.

Set TEST_DATABASE_URL to an isolated empty Postgres database in CI. The test
does not guess a database or drop developer data.
"""

import os
from pathlib import Path

import pytest
from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, inspect


@pytest.mark.integration
def test_baseline_migration_upgrades_and_downgrades_empty_postgres(monkeypatch):
    database_url = os.getenv("TEST_DATABASE_URL")
    if not database_url:
        pytest.skip("TEST_DATABASE_URL must point to an isolated PostgreSQL test database")
    if not database_url.startswith("postgresql"):
        pytest.fail("Migration contract must run against PostgreSQL")

    backend_dir = Path(__file__).resolve().parents[1]
    config = Config(str(backend_dir / "alembic.ini"))
    config.set_main_option("sqlalchemy.url", database_url)
    monkeypatch.delenv("DATABASE_URL_SYNC", raising=False)
    command.downgrade(config, "base")
    command.upgrade(config, "head")

    engine = create_engine(database_url)
    tables = set(inspect(engine).get_table_names())
    assert {"users", "inspections", "inspection_analysis_tasks", "product_images", "compliance_checks"} <= tables

    command.downgrade(config, "base")
    assert "inspections" not in set(inspect(engine).get_table_names())
    engine.dispose()
