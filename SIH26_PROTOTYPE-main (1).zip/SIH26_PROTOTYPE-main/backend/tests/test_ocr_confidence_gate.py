"""OCR Confidence Gate Tests.

Verifies that OCR spans below the medium-confidence threshold (0.60) are
excluded from the extractor, and that rules whose evidence fields are
exclusively low-confidence get overridden to NEEDS_REVIEW.

These tests exercise the confidence-gate logic introduced in pipeline_tasks.py
using the Rule Engine and Extractor directly (no DB / Celery required).
"""

import pytest
from app.core.config import settings
from app.pipeline.extractor import InformationExtractor
from app.rule_engine.engine import RuleEngine
from app.rule_engine.loader import RuleLoader
from app.rule_engine.schema import ComplianceState


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_span(text: str, confidence: float, bbox=None) -> dict:
    """Build a minimal OCR-span dict as produced by OCREngine."""
    return {
        "text": text,
        "confidence": confidence,
        "bbox": bbox or [0, 0, 100, 20],
    }


def _simulate_confidence_gate(
    ocr_spans_by_region: dict,
    threshold: float,
) -> tuple[dict, set]:
    """
    Mirror the confidence-gate logic in pipeline_tasks.py so we can unit-test
    it without spinning up a full Celery pipeline.

    Returns:
        (filtered_spans_by_region, low_confidence_regions)
    """
    filtered: dict = {}
    low_conf_regions: set = set()

    for region_label, spans in ocr_spans_by_region.items():
        high = [s for s in spans if s["confidence"] >= threshold]
        if spans and not high:
            low_conf_regions.add(region_label)
        if high:
            filtered[region_label] = high

    return filtered, low_conf_regions


# ---------------------------------------------------------------------------
# Gate filtering tests
# ---------------------------------------------------------------------------

class TestOCRConfidenceGate:

    def test_low_confidence_span_excluded_from_extractor(self):
        """Spans with confidence < 0.60 must not reach the extractor."""
        spans_by_region = {
            "mrp": [
                _make_span("MRP Rs. 50", confidence=0.45),  # below threshold
            ]
        }
        threshold = settings.OCR_MEDIUM_CONFIDENCE_THRESHOLD  # 0.60

        filtered, low_conf = _simulate_confidence_gate(spans_by_region, threshold)

        # The low-conf span should be dropped
        assert "mrp" not in filtered, "Low-confidence span must be excluded from extractor input."
        assert "mrp" in low_conf, "Region with all-low-confidence spans must be in low_confidence_regions."

    def test_high_confidence_span_passes_gate(self):
        """Spans with confidence >= 0.60 must reach the extractor unchanged."""
        spans_by_region = {
            "net_quantity": [
                _make_span("Net Qty: 250 g", confidence=0.85),
            ]
        }
        threshold = settings.OCR_MEDIUM_CONFIDENCE_THRESHOLD

        filtered, low_conf = _simulate_confidence_gate(spans_by_region, threshold)

        assert "net_quantity" in filtered
        assert filtered["net_quantity"][0]["text"] == "Net Qty: 250 g"
        assert "net_quantity" not in low_conf

    def test_confidence_boundary_exactly_0_60_passes(self):
        """A span at exactly the threshold value (0.60) must be included (>= not >)."""
        spans_by_region = {
            "country_of_origin": [
                _make_span("Made in India", confidence=0.60),
            ]
        }
        threshold = settings.OCR_MEDIUM_CONFIDENCE_THRESHOLD  # 0.60

        filtered, low_conf = _simulate_confidence_gate(spans_by_region, threshold)

        assert "country_of_origin" in filtered, "Span at exactly 0.60 must pass the gate."
        assert "country_of_origin" not in low_conf

    def test_mixed_confidence_keeps_only_high_conf_spans(self):
        """
        When a region has both high and low confidence spans, only the
        high-confidence ones are forwarded to the extractor.
        """
        spans_by_region = {
            "manufacturer_name": [
                _make_span("Balaji Wafers", confidence=0.92),  # keep
                _make_span("garbage OCR", confidence=0.35),    # drop
                _make_span("Pvt Ltd", confidence=0.77),        # keep
            ]
        }
        threshold = settings.OCR_MEDIUM_CONFIDENCE_THRESHOLD

        filtered, low_conf = _simulate_confidence_gate(spans_by_region, threshold)

        assert "manufacturer_name" in filtered
        assert len(filtered["manufacturer_name"]) == 2
        texts = {s["text"] for s in filtered["manufacturer_name"]}
        assert "Balaji Wafers" in texts
        assert "Pvt Ltd" in texts
        assert "garbage OCR" not in texts
        # Region is NOT in low_conf because some spans were high-confidence
        assert "manufacturer_name" not in low_conf

    def test_empty_region_not_flagged_as_low_confidence(self):
        """A region that produced zero OCR spans (no text found) must not be
        added to low_confidence_regions — it is simply absent, not uncertain."""
        spans_by_region = {
            "importer_name": [],  # empty — no spans at all
        }
        threshold = settings.OCR_MEDIUM_CONFIDENCE_THRESHOLD

        filtered, low_conf = _simulate_confidence_gate(spans_by_region, threshold)

        assert "importer_name" not in filtered
        assert "importer_name" not in low_conf, (
            "An empty-span region should not be flagged as low-confidence; "
            "it is simply missing evidence, handled by the missing-field rule path."
        )


# ---------------------------------------------------------------------------
# Rule engine override tests
# ---------------------------------------------------------------------------

class TestLowConfidenceRuleOverride:
    """
    Tests that rules whose evidence fields are in low_confidence_regions are
    overridden to NEEDS_REVIEW by the post-processing step in pipeline_tasks.
    These tests replicate that post-processing logic inline.
    """

    @pytest.fixture
    def rules(self):
        return RuleLoader.load_seed_rules()

    def _apply_override(self, evaluation_results, low_confidence_regions, conf_threshold=0.60):
        """Inline replica of the confidence-gate override in pipeline_tasks.py."""
        from app.rule_engine.schema import ComplianceState, EvaluationResult

        updated = []
        for eval_result in evaluation_results:
            affected = [f for f in eval_result.evidence_fields if f in low_confidence_regions]
            if affected and eval_result.state not in (
                ComplianceState.NOT_APPLICABLE,
                ComplianceState.NEEDS_REVIEW,
            ):
                reason = (
                    f"Field(s) {affected} detected but all OCR confidence scores were "
                    f"below {conf_threshold}. Human officer review required."
                )
                updated.append(
                    EvaluationResult(
                        rule_key=eval_result.rule_key,
                        rule_version=eval_result.rule_version,
                        legal_reference=eval_result.legal_reference,
                        state=ComplianceState.NEEDS_REVIEW,
                        confidence=eval_result.confidence,
                        violation_description=reason,
                        explanation=reason,
                        evidence_fields=eval_result.evidence_fields,
                    )
                )
            else:
                updated.append(eval_result)
        return updated

    def test_all_low_confidence_mrp_routes_to_needs_review(self, rules):
        """
        If MRP was detected but ALL OCR spans for it were below 0.60,
        the MANDATORY_MRP_DECLARATION rule must resolve as NEEDS_REVIEW.
        """
        engine = RuleEngine(rules)

        # Simulate: MRP field is in all_ocr_by_region but NOT in filtered_spans
        # so it never reaches extracted_fields → engine sees it as MISSING → NON_COMPLIANT
        # The override should upgrade it to NEEDS_REVIEW since the region WAS detected
        extracted_fields = {
            # mrp intentionally absent (all spans dropped by gate)
            "net_quantity": {
                "raw_value": "Net Qty: 100 g",
                "normalized_value": {"value": "100 g", "normalized_value": 100.0, "unit": "g", "present": True},
                "confidence": 0.88,
            },
        }

        eval_results = engine.evaluate_inspection(extracted_fields, product_category="ALL")

        # mrp is missing → NON_COMPLIANT before override
        pre_states = {r.rule_key: r.state for r in eval_results}
        assert pre_states["MANDATORY_MRP_DECLARATION"] == ComplianceState.NON_COMPLIANT

        # Apply override: mrp was in low_confidence_regions
        low_conf_regions = {"mrp"}
        updated = self._apply_override(eval_results, low_conf_regions)

        post_states = {r.rule_key: r.state for r in updated}

        # After override: NON_COMPLIANT → NEEDS_REVIEW (region was seen but unreadable)
        assert post_states["MANDATORY_MRP_DECLARATION"] == ComplianceState.NEEDS_REVIEW, (
            "Low-confidence MRP region must route to NEEDS_REVIEW, not NON_COMPLIANT."
        )
        # Other rules are unaffected
        assert post_states["MANDATORY_NET_QUANTITY"] != ComplianceState.NEEDS_REVIEW

    def test_already_needs_review_not_double_overridden(self, rules):
        """An already-NEEDS_REVIEW result must not be modified by the override step."""
        engine = RuleEngine(rules)
        extracted_fields = {}  # all fields missing → all NON_COMPLIANT

        eval_results = engine.evaluate_inspection(extracted_fields, product_category="ALL")

        # Inject a fake NEEDS_REVIEW result for mrp
        from app.rule_engine.schema import ComplianceState, EvaluationResult
        for i, r in enumerate(eval_results):
            if r.rule_key == "MANDATORY_MRP_DECLARATION":
                eval_results[i] = EvaluationResult(
                    rule_key=r.rule_key,
                    rule_version=r.rule_version,
                    legal_reference=r.legal_reference,
                    state=ComplianceState.NEEDS_REVIEW,
                    confidence=0.3,
                    violation_description="Already NEEDS_REVIEW for another reason.",
                    explanation="Already NEEDS_REVIEW.",
                    evidence_fields=r.evidence_fields,
                )
                break

        low_conf_regions = {"mrp"}
        updated = self._apply_override(eval_results, low_conf_regions)

        for r in updated:
            if r.rule_key == "MANDATORY_MRP_DECLARATION":
                # State must remain NEEDS_REVIEW, description unchanged
                assert r.state == ComplianceState.NEEDS_REVIEW
                assert "Already NEEDS_REVIEW" in r.explanation
                break

    def test_not_applicable_rule_not_overridden(self, rules):
        """NOT_APPLICABLE rules must not be touched by the confidence gate override."""
        from app.rule_engine.schema import ComplianceState, EvaluationResult

        # Build a synthetic NOT_APPLICABLE result
        fake_result = EvaluationResult(
            rule_key="MANDATORY_UNIT_SALE_PRICE",
            rule_version=1,
            legal_reference="Rule 6(11)",
            state=ComplianceState.NOT_APPLICABLE,
            confidence=1.0,
            explanation="Not applicable to this category.",
            evidence_fields=["unit_sale_price", "net_quantity"],
        )

        low_conf_regions = {"unit_sale_price", "net_quantity"}
        updated = self._apply_override([fake_result], low_conf_regions)

        assert updated[0].state == ComplianceState.NOT_APPLICABLE, (
            "NOT_APPLICABLE rules must never be overridden by the confidence gate."
        )
