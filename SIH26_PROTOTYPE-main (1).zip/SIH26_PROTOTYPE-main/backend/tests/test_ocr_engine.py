"""Unit and Integration Tests for OCREngine (EasyOCR)."""

import pytest
import numpy as np
import cv2

from app.core.config import settings
from app.pipeline.ocr_engine import OCREngine, OCRSpan, _MOCK_OCR_DATA


def _make_text_image(text: str) -> bytes:
    """Create a high-contrast image containing specific text."""
    img = np.ones((100, 400, 3), dtype=np.uint8) * 255
    cv2.putText(img, text, (15, 60), cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 0), 2)
    ok, buf = cv2.imencode(".jpg", img)
    assert ok
    return buf.tobytes()


class TestOCREngine:

    def test_production_mode_no_mock_fallback_on_blank_crop(self, monkeypatch):
        """Blank crop must return empty list [] in production, NEVER mock text."""
        monkeypatch.setattr(settings, "DEMO_MODE", False)
        monkeypatch.setattr(settings, "USE_REAL_MODELS", True)

        blank_img = np.zeros((100, 200, 3), dtype=np.uint8)
        _, buf = cv2.imencode(".jpg", blank_img)

        engine = OCREngine(use_real_model=True)
        spans = engine.extract_text(buf.tobytes(), region_label="mrp")

        # Must NOT return "M.R.P.: ₹ 120.00"
        assert spans == []

    def test_demo_mode_returns_mock_when_explicitly_enabled(self, monkeypatch):
        """When DEMO_MODE=True and use_real_model=False, returns mock spans."""
        monkeypatch.setattr(settings, "DEMO_MODE", True)
        monkeypatch.setattr(settings, "USE_REAL_MODELS", False)

        engine = OCREngine(use_real_model=False)
        spans = engine.extract_text(b"dummy", region_label="net_quantity")
        assert len(spans) > 0
        assert "500" in spans[0].text

    def test_extract_real_text_from_crop(self, monkeypatch):
        """EasyOCR extracts legible text from a generated high-contrast image.
        Skipped automatically when EasyOCR is not installed.
        """
        monkeypatch.setattr(settings, "DEMO_MODE", False)
        monkeypatch.setattr(settings, "USE_REAL_MODELS", True)

        engine = OCREngine(use_real_model=True)
        if engine.last_error and "not installed" in (engine.last_error or ""):
            pytest.skip(f"EasyOCR not installed — skipping: {engine.last_error}")
        if OCREngine._reader is None:
            pytest.skip("EasyOCR reader not initialized")

        crop_bytes = _make_text_image("NET QTY 250g")
        spans = engine.extract_text(crop_bytes, region_label="net_quantity")

        assert len(spans) > 0
        combined = " ".join(s.text for s in spans).upper()
        assert "250" in combined or "QTY" in combined or "NET" in combined
        assert spans[0].confidence > 0.0
        assert spans[0].engine_version == "easyocr-1.7.1"

    def test_invalid_crop_handling(self, monkeypatch):
        """Corrupt bytes or tiny images return empty list with structured reason, never crash.
        Skipped automatically when EasyOCR is not installed (dependency check fires before decode).
        """
        monkeypatch.setattr(settings, "DEMO_MODE", False)
        engine = OCREngine(use_real_model=True)

        spans, err = engine.extract_text_with_status(b"invalid-bytes", region_label="mrp")
        assert spans == []
        assert err is not None
        # Accept either: OCR decode error, or dependency-unavailable error (no EasyOCR installed)
        acceptable = (
            "Empty image" in err or "not installed" in err or "decode" in err.lower()
            or "cannot" in err.lower() or "failed" in err.lower()
        )
        assert acceptable, f"Unexpected error for invalid bytes: '{err}'"

        if OCREngine._reader is None:
            pytest.skip("EasyOCR reader unavailable — skipping empty-bytes test")

        # Empty bytes
        spans_empty, err_empty = engine.extract_text_with_status(b"", region_label="mrp")
        assert spans_empty == []
        assert "Empty image" in err_empty
