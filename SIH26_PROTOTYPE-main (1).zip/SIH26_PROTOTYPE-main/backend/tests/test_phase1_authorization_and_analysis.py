"""P0 API tests for ownership and durable analysis-task state."""

from uuid import uuid4

import pytest
from app.core.security import create_access_token
from app.models.inspection import Inspection, InspectionAnalysisTask
from app.models.user import Role, User


async def _user(db, username: str, role_name: str = "Officer") -> User:
    from sqlalchemy import select
    role = (await db.execute(select(Role).where(Role.name == role_name))).scalar_one_or_none()
    if not role:
        role = Role(id=uuid4(), name=role_name)
        db.add(role)
        await db.flush()
    user = User(
        id=uuid4(), username=username, email=f"{username}@test.local",
        password_hash="not-used-in-token-tests", role_id=role.id, status="active",
    )
    db.add(user)
    await db.flush()
    return user


def _headers(user: User, role: str = "Officer") -> dict:
    token = create_access_token(str(user.id), extra_claims={"username": user.username, "role": role})
    return {"Authorization": f"Bearer {token}"}


@pytest.mark.asyncio
async def test_officer_cannot_update_another_officers_inspection(async_client, db_session):
    owner = await _user(db_session, "owner")
    other = await _user(db_session, "other")
    inspection = Inspection(id=uuid4(), officer_id=owner.id, category="Packaged Food", status="draft")
    db_session.add(inspection)
    await db_session.commit()

    response = await async_client.patch(
        f"/api/v1/inspections/{inspection.id}", json={"location": "Unauthorised change"}, headers=_headers(other)
    )

    assert response.status_code == 403
    await db_session.refresh(inspection)
    assert inspection.location is None


@pytest.mark.asyncio
async def test_analysis_status_requires_authentication(async_client):
    response = await async_client.get(f"/api/v1/inspections/{uuid4()}/analysis")
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_officer_cannot_read_another_officers_analysis(async_client, db_session):
    owner = await _user(db_session, "analysis-owner")
    other = await _user(db_session, "analysis-other")
    inspection = Inspection(id=uuid4(), officer_id=owner.id, category="Packaged Food", status="analyzing")
    task = InspectionAnalysisTask(id=uuid4(), inspection_id=inspection.id, celery_task_id="task-denied")
    db_session.add_all([inspection, task])
    await db_session.commit()

    response = await async_client.get(f"/api/v1/inspections/{inspection.id}/analysis", headers=_headers(other))
    assert response.status_code == 403


@pytest.mark.asyncio
async def test_analysis_status_returns_404_for_unknown_inspection(async_client, db_session):
    user = await _user(db_session, "not-found")
    await db_session.commit()
    response = await async_client.get(f"/api/v1/inspections/{uuid4()}/analysis", headers=_headers(user))
    assert response.status_code == 404


@pytest.mark.asyncio
@pytest.mark.parametrize(
    ("task_status", "stage", "progress", "completed"),
    [
        ("queued", "QUEUED", 0, False),
        ("running", "OCR", 50, False),
        ("retrying", "RETRYING", 50, False),
        ("failed", "FAILED", 50, False),
        ("completed", "COMPLETED", 100, True),
    ],
)
async def test_analysis_status_reflects_persisted_state(
    async_client, db_session, task_status, stage, progress, completed
):
    user = await _user(db_session, f"state-{task_status}")
    inspection = Inspection(id=uuid4(), officer_id=user.id, category="Packaged Food", status="analyzing")
    task = InspectionAnalysisTask(
        id=uuid4(), inspection_id=inspection.id, celery_task_id=f"task-{task_status}",
        status=task_status, stage=stage, progress_percent=progress, attempt=1,
    )
    db_session.add_all([inspection, task])
    await db_session.commit()

    response = await async_client.get(f"/api/v1/inspections/{inspection.id}/analysis", headers=_headers(user))
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == task_status
    assert body["stage"] == stage
    assert body["progress_percent"] == progress
    assert body["completed"] is completed
