"""Computer Vision Pipeline tests using real, decodable image bytes."""

import cv2
import numpy as np

from app.pipeline.quality import ImageQualityAssessor
from app.pipeline.detector import RegionDetector
from app.pipeline.ocr_engine import OCREngine


def _valid_image_bytes() -> bytes:
    """Create a large, sharp image that clears all quality thresholds."""
    image = np.zeros((600, 800, 3), dtype=np.uint8)
    cv2.putText(image, "MRP Rs. 120", (60, 300), cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 4)
    ok, encoded = cv2.imencode(".jpg", image)
    assert ok
    return encoded.tobytes()


def test_quality_assessor_accepts_valid_image():
    assessor = ImageQualityAssessor(min_quality_score=0.65)
    result = assessor.assess(_valid_image_bytes())
    assert result["passed"] is True
    assert result["quality_score"] >= 0.65


def test_quality_assessor_rejects_undecodable_image():
    assessor = ImageQualityAssessor(min_quality_score=0.65)
    result = assessor.assess(b"not-an-image")
    assert result["passed"] is False
    assert result["quality_score"] == 0.0


def test_detector_stub(monkeypatch):
    from app.core.config import settings
    monkeypatch.setattr(settings, "DEMO_MODE", True)
    monkeypatch.setattr(settings, "USE_REAL_MODELS", False)
    detector = RegionDetector(use_real_model=False)
    regions = detector.detect_regions(b"dummy-image-bytes")
    assert len(regions) > 0
    assert regions[0].confidence > 0.90
