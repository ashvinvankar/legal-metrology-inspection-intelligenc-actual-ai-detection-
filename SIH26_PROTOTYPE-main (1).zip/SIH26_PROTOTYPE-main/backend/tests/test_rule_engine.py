"""Comprehensive Rule Engine & Validator Tests — 4-state compliance validation (PRD Section 10)."""

import pytest
from app.rule_engine.engine import RuleEngine
from app.rule_engine.schema import ComplianceState
from app.rule_engine.validator import FieldValidators


# ===== VALIDATOR UNIT TESTS ===== #

class TestMRPValidator:
    def test_valid_mrp_passes(self):
        raw = "M.R.P.: ₹ 120.00 (Incl. of all taxes)"
        norm = {"value": raw, "normalized_value": 120.0, "currency": "INR"}
        valid, reason = FieldValidators.validate_mrp(raw, norm)
        assert valid is True
        assert reason is None

    def test_missing_mrp_fails(self):
        valid, reason = FieldValidators.validate_mrp(None, None)
        assert valid is False
        assert "not found" in reason.lower()

    def test_mrp_zero_value_fails(self):
        raw = "MRP: ₹ 0.00"
        norm = {"value": raw, "normalized_value": 0.0, "currency": "INR"}
        valid, reason = FieldValidators.validate_mrp(raw, norm)
        assert valid is False
        assert "zero" in reason.lower()

    def test_mrp_missing_currency_marker_returns_needs_review_when_label_present(self):
        """When MRP keyword exists but no ₹/Rs./INR currency marker, result is NEEDS_REVIEW
        (blank-stamp or OCR miss of the symbol) — NOT a hard NON_COMPLIANT."""
        raw = "MRP 120.00"
        norm = {"value": raw, "normalized_value": 120.0, "currency": "INR"}
        valid, reason = FieldValidators.validate_mrp(raw, norm)
        # MRP keyword is structurally present; officer must confirm the currency marker
        assert valid is None, (
            f"Expected NEEDS_REVIEW (None) for MRP with keyword but missing ₹, got valid={valid}"
        )
        assert reason is not None

    def test_mrp_completely_absent_returns_non_compliant(self):
        """When the MRP region contains completely irrelevant text (no MRP/₹/tax keywords),
        result is NON_COMPLIANT. This covers detections that land in the wrong region."""
        # Text with zero structural MRP signals (no 'MRP', no '₹', no 'incl', no 'tax')
        raw = "POTATO WAFERS"
        valid, reason = FieldValidators.validate_mrp(raw, None)  # None norm → raw-only path
        assert valid is False, (
            f"Expected NON_COMPLIANT (False) for text with no MRP signal, got valid={valid}, reason={reason}"
        )
        assert reason is not None


class TestNetQuantityValidator:
    def test_valid_net_quantity_passes(self):
        raw = "Net Qty: 500 g"
        norm = {"value": raw, "normalized_value": 500.0, "unit": "g"}
        valid, reason = FieldValidators.validate_net_quantity(raw, norm)
        assert valid is True

    def test_missing_net_quantity_fails(self):
        valid, reason = FieldValidators.validate_net_quantity(None, None)
        assert valid is False
        assert "not found" in reason.lower()

    def test_invalid_unit_fails(self):
        raw = "500 lumens"
        norm = {"value": raw, "normalized_value": 500.0, "unit": "lumens"}
        valid, reason = FieldValidators.validate_net_quantity(raw, norm)
        assert valid is False
        assert "not a recognized" in reason.lower()

    def test_zero_quantity_fails(self):
        raw = "0 g"
        norm = {"value": raw, "normalized_value": 0.0, "unit": "g"}
        valid, reason = FieldValidators.validate_net_quantity(raw, norm)
        assert valid is False


class TestDateValidator:
    def test_valid_date_passes(self):
        raw = "Mfg. Date: 08/2026 Best Before: 08/2027"
        norm = {"value": raw, "month": "08", "year": "2026"}
        valid, reason = FieldValidators.validate_date_declaration(raw, norm)
        assert valid is True

    def test_missing_date_fails(self):
        valid, reason = FieldValidators.validate_date_declaration(None, None)
        assert valid is False
        assert "not found" in reason.lower()

    def test_raw_date_pattern_found_passes(self):
        # Even without normalized values, if raw contains a date-like pattern it passes
        raw = "Mfg: 09/25"
        valid, reason = FieldValidators.validate_date_declaration(raw, {"month": None, "year": None})
        assert valid is True


class TestCountryOfOriginValidator:
    def test_present_passes(self):
        raw = "Country of Origin: India"
        norm = {"value": "India", "present": True}
        valid, reason = FieldValidators.validate_country_of_origin(raw, norm)
        assert valid is True

    def test_missing_fails(self):
        valid, reason = FieldValidators.validate_country_of_origin(None, None)
        assert valid is False

    def test_too_short_fails(self):
        raw = "A"
        norm = {"value": "A", "present": True}
        valid, reason = FieldValidators.validate_country_of_origin(raw, norm)
        assert valid is False


class TestTextPresenceValidator:
    def test_present_manufacturer_passes(self):
        raw = "Bharat Foods Pvt. Ltd., Pune"
        norm = {"value": raw, "present": True}
        valid, reason = FieldValidators.validate_text_presence("manufacturer_name", raw, norm)
        assert valid is True

    def test_missing_manufacturer_fails(self):
        valid, reason = FieldValidators.validate_text_presence("manufacturer_name", None, None)
        assert valid is False

    def test_too_short_fails(self):
        raw = "AB"
        norm = {"value": "AB", "present": True}
        valid, reason = FieldValidators.validate_text_presence("manufacturer_name", raw, norm)
        assert valid is False


# ===== RULE ENGINE INTEGRATION TESTS ===== #

class TestRuleEngine:

    def _make_rule(self, rule_key: str, field: str, validator: str = None, legal_ref: str = "Rule 6(1)", categories=None):
        return {
            "rule_key": rule_key,
            "version": 1,
            "legal_reference": legal_ref,
            "input_fields": [field],
            "applicability_conditions": {"categories": categories or ["ALL"]},
            "validation_logic": {"validator": validator or f"validate_{field}"},
            "explanation_template": f"{field} is mandatory per {legal_ref}.",
        }

    def test_missing_field_returns_non_compliant(self):
        rule = self._make_rule("mrp_mandatory", "mrp", "validate_mrp")
        engine = RuleEngine([rule])
        results = engine.evaluate_inspection({}, "ALL")
        assert results[0].state == ComplianceState.NON_COMPLIANT
        assert "not detected on label" in results[0].violation_description

    def test_low_confidence_returns_needs_review(self):
        rule = self._make_rule("mrp_mandatory", "mrp", "validate_mrp")
        engine = RuleEngine([rule])
        extracted = {"mrp": {"raw_value": "₹120", "normalized_value": {"normalized_value": 120.0, "currency": "INR"}, "confidence": 0.40}}
        results = engine.evaluate_inspection(extracted, "ALL")
        assert results[0].state == ComplianceState.NEEDS_REVIEW

    def test_valid_mrp_returns_compliant(self):
        rule = self._make_rule("mrp_mandatory", "mrp", "validate_mrp")
        engine = RuleEngine([rule])
        extracted = {
            "mrp": {
                "raw_value": "M.R.P.: ₹ 120.00 (Incl. of all taxes)",
                "normalized_value": {"value": "₹120", "normalized_value": 120.0, "currency": "INR"},
                "confidence": 0.97,
                "bbox": [0, 0, 200, 30],
            }
        }
        results = engine.evaluate_inspection(extracted, "ALL")
        assert results[0].state == ComplianceState.COMPLIANT

    def test_not_applicable_for_wrong_category(self):
        rule = self._make_rule("mrp_mandatory", "mrp", "validate_mrp", categories=["Textiles"])
        engine = RuleEngine([rule])
        results = engine.evaluate_inspection({}, "Packaged Food")
        assert results[0].state == ComplianceState.NOT_APPLICABLE

    def test_missing_country_of_origin_non_compliant(self):
        rule = self._make_rule("country_of_origin_mandatory", "country_of_origin", "validate_country_of_origin")
        engine = RuleEngine([rule])
        results = engine.evaluate_inspection({}, "ALL")
        assert results[0].state == ComplianceState.NON_COMPLIANT

    def test_missing_net_quantity_non_compliant(self):
        rule = self._make_rule("net_quantity_mandatory", "net_quantity", "validate_net_quantity")
        engine = RuleEngine([rule])
        results = engine.evaluate_inspection({}, "ALL")
        assert results[0].state == ComplianceState.NON_COMPLIANT

    def test_multiple_rules_mixed_states(self):
        """Full label evaluation: some COMPLIANT, some NON_COMPLIANT, some NEEDS_REVIEW."""
        rules = [
            self._make_rule("mrp_mandatory", "mrp", "validate_mrp"),
            self._make_rule("net_quantity_mandatory", "net_quantity", "validate_net_quantity"),
            self._make_rule("country_of_origin_mandatory", "country_of_origin", "validate_country_of_origin"),
        ]
        engine = RuleEngine(rules)
        extracted = {
            # MRP: valid → COMPLIANT
            "mrp": {
                "raw_value": "M.R.P.: ₹ 120.00 (Incl. of all taxes)",
                "normalized_value": {"value": "₹120", "normalized_value": 120.0, "currency": "INR"},
                "confidence": 0.97,
                "bbox": [0, 0, 200, 30],
            },
            # net_quantity: missing unit → NON_COMPLIANT
            "net_quantity": {
                "raw_value": "500 lumens",
                "normalized_value": {"value": "500 lumens", "normalized_value": 500.0, "unit": "lumens"},
                "confidence": 0.95,
                "bbox": [0, 0, 150, 25],
            },
            # country_of_origin: low confidence → NEEDS_REVIEW
            "country_of_origin": {
                "raw_value": "India",
                "normalized_value": {"value": "India", "present": True},
                "confidence": 0.20,
                "bbox": [0, 0, 100, 20],
            },
        }
        results = engine.evaluate_inspection(extracted, "ALL")
        states = {r.rule_key: r.state for r in results}
        assert states["mrp_mandatory"] == ComplianceState.COMPLIANT
        assert states["net_quantity_mandatory"] == ComplianceState.NON_COMPLIANT
        assert states["country_of_origin_mandatory"] == ComplianceState.NEEDS_REVIEW
