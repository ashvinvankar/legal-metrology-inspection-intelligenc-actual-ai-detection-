"""Storage adapter unit contracts independent of a live MinIO instance."""

from app.core.config import settings
from app.services.storage_service import StorageService


def test_local_storage_adapter_round_trip_and_legacy_url(monkeypatch, tmp_path):
    monkeypatch.setattr(settings, "STORAGE_BACKEND", "local")
    monkeypatch.setattr(settings, "STORAGE_DIR", str(tmp_path))
    storage = StorageService()

    uri = storage.upload_file(b"evidence", "images/example.jpg", "image/jpeg")

    assert uri == "local://images/example.jpg"
    assert storage.get_file_bytes(uri) == b"evidence"
    assert storage.get_presigned_url(uri).startswith("/api/v1/storage/images/example.jpg?token=")
    storage.delete_file(uri)
    assert storage.get_file_bytes(uri) is None
