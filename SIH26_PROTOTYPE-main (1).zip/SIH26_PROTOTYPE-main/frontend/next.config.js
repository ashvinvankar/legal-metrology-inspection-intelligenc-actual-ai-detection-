/** @type {import('next').NextConfig} */
const nextConfig = {
  /**
   * API Proxy Rewrites
   *
   * Problem: NEXT_PUBLIC_API_URL must be a browser-visible URL (e.g. http://localhost:8000),
   * but when Next.js runs server-side inside a Docker container it cannot reach `localhost:8000`
   * (the backend is at http://api:8000 on the Docker bridge network).
   *
   * Solution: Rewrite all /proxy/api/* requests server-side to the internal Docker service name.
   * Client-side code continues to call NEXT_PUBLIC_API_URL directly (browser → host port 8000).
   */
  async rewrites() {
    const internalApiUrl =
      process.env.INTERNAL_API_URL || "http://localhost:8000";
    return [
      {
        source: "/proxy/api/:path*",
        destination: `${internalApiUrl}/api/:path*`,
      },
    ];
  },

  // Allow Next.js Image component to load images from backend storage
  images: {
    remotePatterns: [
      {
        protocol: "http",
        hostname: "localhost",
        port: "8000",
        pathname: "/storage/**",
      },
      {
        protocol: "http",
        hostname: "api",
        port: "8000",
        pathname: "/storage/**",
      },
    ],
  },
};

module.exports = nextConfig;
