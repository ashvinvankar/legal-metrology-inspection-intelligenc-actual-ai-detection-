"use client";

import React from "react";
import { History, Shield, Lock } from "lucide-react";

export default function AuditLogsPage() {
  const auditLogs = [
    {
      id: "AUD-8921",
      actor: "Insp. Sharma (OFF-104)",
      action: "CONFIRM_VIOLATION",
      target: "Inspection #INSP-2026-091",
      details: "Confirmed missing Country of Origin violation (Rule 6(1)(ea))",
      timestamp: "12-Sep-2026 10:45:12 UTC",
      ip: "10.42.1.84",
    },
    {
      id: "AUD-8920",
      actor: "System AI Pipeline",
      action: "EVALUATE_RULES",
      target: "Inspection #INSP-2026-091",
      details: "Evaluated 6 rules against PC Rules 2011 v1.0",
      timestamp: "12-Sep-2026 10:44:50 UTC",
      ip: "internal-worker",
    },
    {
      id: "AUD-8919",
      actor: "Insp. Sharma (OFF-104)",
      action: "UPLOAD_IMAGE",
      target: "Inspection #INSP-2026-091",
      details: "Uploaded front & label images (Quality Score: 0.88)",
      timestamp: "12-Sep-2026 10:42:15 UTC",
      ip: "10.42.1.84",
    },
    {
      id: "AUD-8918",
      actor: "Insp. Sharma (OFF-104)",
      action: "CREATE_INSPECTION",
      target: "Inspection #INSP-2026-091",
      details: "Initiated inspection for Apex Crisp Biscuits",
      timestamp: "12-Sep-2026 10:40:02 UTC",
      ip: "10.42.1.84",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Immutable Audit Log Explorer</h2>
          <p className="text-xs text-slate-500">Append-only audit trail of all enforcement, AI pipeline, and officer decisions (PRD Section 16)</p>
        </div>
        <div className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-100 rounded-lg text-xs font-semibold text-slate-700">
          <Lock className="w-3.5 h-3.5 text-slate-500" />
          <span>Append-Only Immutability Enforced</span>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase">
            <tr>
              <th className="px-4 py-3">Log ID</th>
              <th className="px-4 py-3">Actor</th>
              <th className="px-4 py-3">Action</th>
              <th className="px-4 py-3">Target Entity</th>
              <th className="px-4 py-3">Action Summary</th>
              <th className="px-4 py-3">Timestamp</th>
              <th className="px-4 py-3 text-right">IP Address</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
            {auditLogs.map((log) => (
              <tr key={log.id} className="hover:bg-slate-50/60">
                <td className="px-4 py-3 text-indigo-600 font-semibold">{log.id}</td>
                <td className="px-4 py-3 text-slate-800 font-sans">{log.actor}</td>
                <td className="px-4 py-3">
                  <span className="px-1.5 py-0.5 rounded bg-slate-100 font-bold text-slate-700">
                    {log.action}
                  </span>
                </td>
                <td className="px-4 py-3 text-slate-600 font-sans">{log.target}</td>
                <td className="px-4 py-3 text-slate-700 font-sans">{log.details}</td>
                <td className="px-4 py-3 text-slate-500">{log.timestamp}</td>
                <td className="px-4 py-3 text-right text-slate-500">{log.ip}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
