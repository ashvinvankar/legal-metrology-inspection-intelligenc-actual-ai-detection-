"use client";

import React from "react";
import { BookOpen, Plus, ShieldCheck } from "lucide-react";

export default function RuleManagementPage() {
  const rules = [
    { key: "MANDATORY_MRP_DECLARATION", citation: "Rule 6(1)(e)", version: 1, active: "Active", severity: "Critical" },
    { key: "MANDATORY_NET_QUANTITY", citation: "Rule 6(1)(f)", version: 1, active: "Active", severity: "Critical" },
    { key: "MANDATORY_COUNTRY_OF_ORIGIN", citation: "Rule 6(1)(ea)", version: 1, active: "Active", severity: "Critical" },
    { key: "MANDATORY_UNIT_SALE_PRICE", citation: "Rule 6(11)", version: 1, active: "Active", severity: "Minor" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Legal Rule Management</h2>
          <p className="text-xs text-slate-500">Versioned Legal Metrology (Packaged Commodities) Rules engine (PRD Section 10 & 25)</p>
        </div>
        <button className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-lg shadow flex items-center">
          <Plus className="w-4 h-4 mr-1" /> Author New Rule Draft
        </button>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase">
            <tr>
              <th className="px-4 py-3">Rule Key</th>
              <th className="px-4 py-3">Legal Citation</th>
              <th className="px-4 py-3">Version</th>
              <th className="px-4 py-3">Severity</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rules.map((r) => (
              <tr key={r.key} className="hover:bg-slate-50/60">
                <td className="px-4 py-3 font-semibold text-slate-800">{r.key}</td>
                <td className="px-4 py-3 text-slate-600">{r.citation}</td>
                <td className="px-4 py-3 font-mono">v{r.version}.0</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    r.severity === "Critical" ? "bg-rose-100 text-rose-800" : "bg-slate-100 text-slate-800"
                  }`}>
                    {r.severity}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                    {r.active}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
