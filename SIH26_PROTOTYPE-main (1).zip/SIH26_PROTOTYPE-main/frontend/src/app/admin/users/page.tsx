"use client";

import React from "react";
import { Users, UserPlus, Shield } from "lucide-react";

export default function UserManagementPage() {
  const users = [
    { name: "Insp. Rajesh Sharma", email: "sharma.r@legalmetrology.gov.in", role: "Officer", dept: "Delhi Zone" },
    { name: "Dr. Ananya Verma", email: "verma.a@legalmetrology.gov.in", role: "Reviewer", dept: "North Region HQ" },
    { name: "Vikram Malhotra", email: "malhotra.v@legalmetrology.gov.in", role: "DeptAdmin", dept: "Enforcement Directorate" },
    { name: "System Administrator", email: "admin@legalmetrology.gov.in", role: "SysAdmin", dept: "National IT Cell" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">User & Access Management</h2>
          <p className="text-xs text-slate-500">Department RBAC: Officer, Reviewer, DeptAdmin, SysAdmin (PRD Section 6)</p>
        </div>
        <button className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-lg shadow flex items-center">
          <UserPlus className="w-4 h-4 mr-1" /> Onboard New Officer
        </button>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase">
            <tr>
              <th className="px-4 py-3">User</th>
              <th className="px-4 py-3">Official Email</th>
              <th className="px-4 py-3">Assigned Role</th>
              <th className="px-4 py-3">Jurisdiction / Department</th>
              <th className="px-4 py-3 text-right">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {users.map((u) => (
              <tr key={u.email} className="hover:bg-slate-50/60">
                <td className="px-4 py-3 font-semibold text-slate-800">{u.name}</td>
                <td className="px-4 py-3 text-slate-600 font-mono">{u.email}</td>
                <td className="px-4 py-3">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200">
                    {u.role}
                  </span>
                </td>
                <td className="px-4 py-3 text-slate-600">{u.dept}</td>
                <td className="px-4 py-3 text-right font-semibold text-emerald-600">Active</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
