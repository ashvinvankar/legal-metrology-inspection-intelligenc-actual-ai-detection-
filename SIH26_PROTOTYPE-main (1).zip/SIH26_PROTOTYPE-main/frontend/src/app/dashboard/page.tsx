"use client";

import React, { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  CheckCircle2,
  XCircle,
  AlertTriangle,
  FileText,
  ShieldAlert,
  TrendingUp,
  BarChart3,
} from "lucide-react";
import { motion } from "framer-motion";
import {
  getDashboardSummary,
  getDashboardViolations,
  getDashboardTrends,
} from "@/lib/api";
import { SkeletonCard } from "@/components/ui/SkeletonRow";
import { ErrorBanner } from "@/components/ui/ErrorBanner";
import { useAuth } from "@/contexts/AuthContext";
import type {
  DashboardSummaryMetrics,
  DashboardViolation,
  DashboardTrendsResponse,
} from "@/types";

export default function DashboardPage() {
  const router = useRouter();
  const { isAuthenticated, isLoading: authLoading } = useAuth();

  const [summary, setSummary] = useState<DashboardSummaryMetrics | null>(null);
  const [violations, setViolations] = useState<DashboardViolation[]>([]);
  const [trends, setTrends] = useState<DashboardTrendsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [severityFilter, setSeverityFilter] = useState<string>("");

  // Auth guard — redirect unauthenticated users
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      router.replace("/login");
    }
  }, [authLoading, isAuthenticated, router]);

  const fetchDashboard = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [summaryData, violationsData, trendsData] = await Promise.all([
        getDashboardSummary(),
        getDashboardViolations(severityFilter || undefined),
        getDashboardTrends(30),
      ]);
      setSummary(summaryData);
      setViolations(violationsData);
      setTrends(trendsData);
    } catch {
      setError("Could not load dashboard metrics. Is the backend running?");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isAuthenticated) fetchDashboard();
  }, [isAuthenticated, fetchDashboard]);

  useEffect(() => {
    if (isAuthenticated && !loading) {
      getDashboardViolations(severityFilter || undefined).then(setViolations).catch(console.error);
    }
  }, [severityFilter]);

  const metrics = summary
    ? [
        {
          label: "Total Inspections",
          value: summary.total_inspections,
          color: "text-slate-900",
          bg: "bg-white",
          icon: <FileText className="w-5 h-5 text-slate-500" />,
        },
        {
          label: "Compliant Products",
          value: summary.compliant_count,
          color: "text-emerald-600",
          bg: "bg-emerald-50/50",
          icon: <CheckCircle2 className="w-5 h-5 text-emerald-500" />,
        },
        {
          label: "Non-Compliant Violations",
          value: summary.non_compliant_count,
          color: "text-rose-600",
          bg: "bg-rose-50/50",
          icon: <XCircle className="w-5 h-5 text-rose-500" />,
        },
        {
          label: "Needs Officer Review",
          value: summary.needs_review_count,
          color: "text-amber-600",
          bg: "bg-amber-50/50",
          icon: <AlertTriangle className="w-5 h-5 text-amber-500" />,
        },
      ]
    : [];

  // Trend sparkline — compute max for scaling
  const trendData = trends?.daily_data ?? [];
  const maxCount = Math.max(1, ...trendData.map((d) => d.inspection_count));

  if (authLoading) return null;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">
            Enforcement Dashboard
          </h2>
          <p className="text-xs text-slate-500">
            Legal Metrology inspection metrics &amp; repeat violation tracker
          </p>
        </div>
        <Link
          href="/inspections/new"
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-medium text-xs rounded-lg shadow transition-colors"
        >
          + Initiate Inspection
        </Link>
      </div>

      {error && <ErrorBanner message={error} onRetry={fetchDashboard} />}

      {/* Summary KPI Cards */}
      <motion.div 
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
        initial="hidden"
        animate="visible"
        variants={{
          hidden: { opacity: 0 },
          visible: {
            opacity: 1,
            transition: { staggerChildren: 0.1 }
          }
        }}
      >
        {loading
          ? Array.from({ length: 4 }).map((_, i) => (
              <SkeletonCard key={i} />
            ))
          : metrics.map((m) => (
              <motion.div
                key={m.label}
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0 }
                }}
                whileHover={{ y: -5, boxShadow: "0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)" }}
                className={`p-5 rounded-xl border border-slate-200 ${m.bg} shadow-sm cursor-default transition-colors duration-200`}
              >
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs font-medium text-slate-500">
                    {m.label}
                  </p>
                  {m.icon}
                </div>
                <p className={`text-2xl font-extrabold ${m.color}`}>
                  {m.value}
                </p>
              </motion.div>
            ))}
      </motion.div>

      {/* Compliance Rate Bar */}
      {summary && summary.total_inspections > 0 && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="premium-card"
        >
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-indigo-500" />
            <h3 className="text-sm font-bold text-slate-900">
              Overall Compliance Rate
            </h3>
            <span className="ml-auto text-xs font-mono font-bold text-emerald-600">
              {Math.round(
                (summary.compliant_count / summary.total_inspections) * 100
              )}
              %
            </span>
          </div>
          <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden flex">
            <div
              className="h-full bg-emerald-500 transition-all"
              style={{
                width: `${(summary.compliant_count / summary.total_inspections) * 100}%`,
              }}
            />
            <div
              className="h-full bg-rose-500 transition-all"
              style={{
                width: `${(summary.non_compliant_count / summary.total_inspections) * 100}%`,
              }}
            />
            <div
              className="h-full bg-amber-400 transition-all"
              style={{
                width: `${(summary.needs_review_count / summary.total_inspections) * 100}%`,
              }}
            />
          </div>
          <div className="flex items-center gap-4 text-[11px] text-slate-500">
            <span className="flex items-center gap-1">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-500" />
              Compliant
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block w-2 h-2 rounded-full bg-rose-500" />
              Non-Compliant
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block w-2 h-2 rounded-full bg-amber-400" />
              Needs Review
            </span>
          </div>
        </motion.div>
      )}

      {/* 30-Day Trend Sparkline (CSS-only bar chart) */}
      {trendData.length > 0 && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
          className="premium-card"
        >
          <div className="flex items-center space-x-2">
            <BarChart3 className="w-5 h-5 text-indigo-500" />
            <h3 className="text-sm font-bold text-slate-900">
              30-Day Inspection Trend
            </h3>
            <span className="ml-auto text-xs text-slate-400">
              Daily inspection volume
            </span>
          </div>
          <div className="flex items-end gap-0.5 h-20">
            {trendData.map((d, i) => {
              const height = Math.max(
                4,
                Math.round((d.inspection_count / maxCount) * 80)
              );
              const compliantH = d.inspection_count
                ? Math.round((d.compliant_count / d.inspection_count) * height)
                : 0;
              const nonCompliantH = height - compliantH;
              return (
                <div
                  key={i}
                  className="flex flex-col justify-end flex-1 group relative"
                  title={`${d.date}: ${d.inspection_count} inspections`}
                >
                  <div
                    style={{ height: `${nonCompliantH}px` }}
                    className="bg-rose-400 rounded-t-[2px]"
                  />
                  <div
                    style={{ height: `${compliantH}px` }}
                    className="bg-emerald-500"
                  />
                  {/* Tooltip */}
                  <div className="absolute bottom-full mb-1 left-1/2 -translate-x-1/2 hidden group-hover:flex flex-col items-center z-10 pointer-events-none">
                    <div className="bg-slate-800 text-white text-[9px] rounded px-1.5 py-1 whitespace-nowrap shadow">
                      {d.date.slice(5)}: {d.inspection_count}
                    </div>
                    <div className="w-0 h-0 border-x-[4px] border-x-transparent border-t-[4px] border-t-slate-800" />
                  </div>
                </div>
              );
            })}
          </div>
          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span className="flex items-center gap-1">
              <span className="inline-block w-2 h-2 rounded-sm bg-emerald-500" />
              Compliant
            </span>
            <span className="flex items-center gap-1">
              <span className="inline-block w-2 h-2 rounded-sm bg-rose-400" />
              Non-Compliant / In-Progress
            </span>
          </div>
        </motion.div>
      )}

      {/* Top Violation Categories */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.4 }}
        className="premium-card"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-rose-600" />
            <h3 className="text-sm font-bold text-slate-900">
              Top Violation Categories
            </h3>
          </div>
          <div className="flex items-center space-x-2">
            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value)}
              className="text-xs border-slate-200 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-slate-700 py-1"
            >
              <option value="">All Severities</option>
              <option value="Critical">Critical</option>
              <option value="Major">Major</option>
              <option value="Minor">Minor</option>
            </select>
            <span className="text-xs text-slate-400">Past 30 days</span>
          </div>
        </div>

        {loading && (
          <div className="space-y-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="animate-pulse h-8 bg-slate-100 rounded-lg" />
            ))}
          </div>
        )}

        {!loading && violations.length === 0 && !error && (
          <p className="text-xs text-slate-400 py-3 text-center">
            No violation data available yet.
          </p>
        )}

        <div className="divide-y divide-slate-100 text-xs">
          {violations.map((v) => (
            <div key={v.rule_key} className="py-2.5 space-y-1.5">
              <div className="flex items-center justify-between">
                <p className="font-semibold text-slate-800">{v.category_name}</p>
                <span className="font-mono font-bold text-rose-600">
                  {v.violation_count} cases
                </span>
              </div>
              <div className="w-full h-1.5 rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full bg-rose-500 rounded-full transition-all"
                  style={{ width: `${v.percentage}%` }}
                />
              </div>
              <p className="text-slate-400 text-[11px]">
                Rule key:{" "}
                <span className="font-mono">{v.rule_key}</span>
              </p>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
