"use client";

import React, { useState } from "react";
import { HelpCircle, ChevronDown } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const FAQS = [
  {
    question: "What is the Legal Metrology (Packaged Commodities) Rules, 2011?",
    answer: "These rules regulate the packaging of commodities in India, ensuring that consumers receive accurate information regarding the manufacturer, quantity, price, and other essential details before making a purchase. Non-compliance can result in legal penalties.",
  },
  {
    question: "What is NeuraCheck?",
    answer: "NeuraCheck is an AI-powered compliance automation tool designed specifically for enforcement officers to quickly verify whether a package complies with the PC Rules 2011. It extracts information directly from label images and flags any violations.",
  },
  {
    question: "How does the AI extract information from packages?",
    answer: "The application uses advanced Computer Vision and Optical Character Recognition (OCR) combined with state-of-the-art Large Language Models (LLMs). Once you upload a picture of a package label, the AI reads the text and contextually maps it to mandatory fields like MRP, net weight, manufacturer address, and consumer care details.",
  },
  {
    question: "Which fields are mandatory on every package under Rule 6?",
    answer: "Generally, packages must display: (a) Name and address of the manufacturer/packer/importer, (b) Common/generic name of the commodity, (c) Net quantity, (d) Month and year of manufacture, (e) Maximum Retail Price (MRP), and (f) Consumer care details. (g) Unit sale price (for applicable items).",
  },
  {
    question: "Is the unit sale price mandatory?",
    answer: "Yes, under the 2021 amendments to Rule 6(11), the unit sale price (e.g., price per gram/ml) must be declared on the package alongside the MRP, unless exempted under specific rule conditions.",
  },
  {
    question: "What happens if a package is deemed 'NON-COMPLIANT'?",
    answer: "The system automatically highlights the missing or incorrect fields. The inspecting officer reviews this result and can generate a formal compliance report to be used as legal evidence or to issue a notice to the manufacturer.",
  },
  {
    question: "Can an officer override the AI's decision?",
    answer: "Absolutely. The AI is a supportive tool. If the AI hallucinates or fails to detect a field due to poor image quality, an authorized officer can manually override the finding by providing the correct value and a mandatory written justification.",
  },
  {
    question: "Are there any exemptions to these rules?",
    answer: "Yes. Certain packages are exempted under Rule 26, such as packages meant for institutional consumers, industrial consumers, or packages containing commodities weighing less than 10 grams or 10 milliliters (with some exceptions like tobacco).",
  },
  {
    question: "How is the compliance report generated?",
    answer: "Once all required label sides are processed and verified by the officer, the system compiles the AI findings, officer overrides, and captured images into a standardized, tamper-evident PDF report that aligns with departmental formats.",
  },
  {
    question: "Does this tool support multiple languages for OCR?",
    answer: "Currently, the OCR engine is optimized for English and common Indian regional languages (like Hindi). Support for specialized regional fonts depends on the clarity of the uploaded label image.",
  },
  {
    question: "How secure is the inspection data?",
    answer: "All evidence (images and reports) is stored in a secure, private object storage system (S3/MinIO). Every action, including rule overrides and user logins, is logged in a cryptographic audit trail ensuring strict accountability and data integrity.",
  },
  {
    question: "Who can manage the rules and thresholds in the system?",
    answer: "Only users with the 'SysAdmin' or 'DeptAdmin' roles have access to the Rule Management dashboard. They can dynamically add or update legal rules, adjust AI confidence thresholds, and deploy new compliance requirements without needing code changes.",
  },
];

export default function FAQPage() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleAccordion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-3 pb-6 border-b border-slate-200">
        <div className="flex items-center justify-center w-12 h-12 rounded-xl bg-teal-50 text-teal-600">
          <HelpCircle className="w-6 h-6" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-slate-800">FAQ & About</h1>
          <p className="text-sm text-slate-500">
            Frequently asked questions about NeuraCheck and PC Rules 2011 compliance
          </p>
        </div>
      </div>

      <div className="space-y-3">
        {FAQS.map((faq, index) => {
          const isOpen = openIndex === index;

          return (
            <motion.div
              key={index}
              initial={false}
              className={`rounded-xl border transition-colors duration-200 ${
                isOpen ? "border-teal-200 bg-white shadow-sm" : "border-slate-200 bg-slate-50/50 hover:bg-slate-50"
              }`}
            >
              <button
                type="button"
                className="w-full flex items-center justify-between px-6 py-4 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-500 rounded-xl"
                onClick={() => toggleAccordion(index)}
              >
                <span className={`font-semibold ${isOpen ? "text-teal-800" : "text-slate-700"}`}>
                  {faq.question}
                </span>
                <ChevronDown
                  className={`w-5 h-5 transition-transform duration-300 ${
                    isOpen ? "rotate-180 text-teal-600" : "text-slate-400"
                  }`}
                />
              </button>

              <AnimatePresence initial={false}>
                {isOpen && (
                  <motion.div
                    initial="collapsed"
                    animate="open"
                    exit="collapsed"
                    variants={{
                      open: { opacity: 1, height: "auto", paddingBottom: "1.5rem" },
                      collapsed: { opacity: 0, height: 0, paddingBottom: 0 },
                    }}
                    transition={{ duration: 0.3, ease: "easeInOut" }}
                    className="overflow-hidden px-6 text-sm text-slate-600 leading-relaxed"
                  >
                    {faq.answer}
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}
      </div>
      
      <div className="mt-12 p-6 rounded-2xl bg-teal-900 text-teal-50 flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <h3 className="text-lg font-bold text-white mb-1">Still need help?</h3>
          <p className="text-sm text-teal-200">
            Contact the Legal Metrology Department support desk or refer to the official gazette notifications.
          </p>
        </div>
        <button className="whitespace-nowrap px-6 py-2.5 bg-teal-500 hover:bg-teal-400 text-teal-950 font-bold text-sm rounded-xl transition-colors">
          Contact Support
        </button>
      </div>
    </div>
  );
}
