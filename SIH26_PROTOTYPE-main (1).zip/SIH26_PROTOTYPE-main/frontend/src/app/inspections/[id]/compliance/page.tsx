"use client";

import React, { useState, useEffect, useCallback, useRef } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import {
  ArrowLeft,
  CheckCircle2,
  RefreshCw,
  Loader2,
  AlertTriangle,
  Eye,
  EyeOff,
  ShieldCheck,
  ShieldAlert,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  BadgeCheck,
  FileText,
  Zap,
} from "lucide-react";
import { StatusPill } from "@/components/compliance/StatusPill";
import { BoundingBoxViewer } from "@/components/evidence/BoundingBoxViewer";
import { ErrorBanner } from "@/components/ui/ErrorBanner";
import { SkeletonRow } from "@/components/ui/SkeletonRow";
import {
  getInspection,
  getComplianceFindings,
  listInspectionImages,
  reviewComplianceFinding,
  triggerComplianceEvaluation,
} from "@/lib/api";
import type {
  Inspection,
  ComplianceFindingAPI,
  ImageUploadResponse,
  ComplianceState,
} from "@/types";

// ─── Severity badge ────────────────────────────────────────────────────────────
const SEVERITY_STYLES: Record<string, string> = {
  Critical: "bg-rose-100 text-rose-700 border-rose-300",
  Major: "bg-amber-100 text-amber-700 border-amber-300",
  Minor: "bg-slate-100 text-slate-600 border-slate-300",
};

function SeverityBadge({ severity }: { severity?: string }) {
  if (!severity) return null;
  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${
        SEVERITY_STYLES[severity] ?? SEVERITY_STYLES.Minor
      }`}
    >
      {severity}
    </span>
  );
}

// ─── Officer decision badge ────────────────────────────────────────────────────
function DecisionBadge({
  decision,
}: {
  decision: "confirmed" | "overridden" | undefined;
}) {
  if (!decision) return null;
  return decision === "confirmed" ? (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700 border border-emerald-300">
      <BadgeCheck className="w-3 h-3" />
      Confirmed
    </span>
  ) : (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700 border border-amber-300">
      <RefreshCw className="w-3 h-3" />
      Overridden
    </span>
  );
}

// ─── Per-finding review state ──────────────────────────────────────────────────
interface FindingReviewState {
  expanded: boolean;     // evidence panel open?
  submitting: boolean;
  submitted: boolean;
  override: boolean;     // showing override textarea?
  justification: string;
  error: string | null;
  localDecision?: "confirmed" | "overridden";
  corrected_fields: Record<string, string>;
}

function makeDefaultReviewState(): FindingReviewState {
  return {
    expanded: false,
    submitting: false,
    submitted: false,
    override: false,
    justification: "",
    error: null,
    corrected_fields: {},
  };
}

const getImageUrl = (uri: string | null | undefined) => {
  if (!uri) return "";
  if (uri.startsWith("http")) return uri;
  const base = process.env.NEXT_PUBLIC_API_URL?.replace("/api/v1", "") ?? "http://localhost:8000";
  return `${base}${uri.startsWith("/") ? "" : "/"}${uri}`;
};

// ─── Page component ────────────────────────────────────────────────────────────
export default function ComplianceResultsPage() {
  const params = useParams();
  const id = params.id as string;

  const [inspection, setInspection] = useState<Inspection | null>(null);
  const [findings, setFindings] = useState<ComplianceFindingAPI[]>([]);
  const [images, setImages] = useState<ImageUploadResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [evaluating, setEvaluating] = useState(false);
  const [evaluateError, setEvaluateError] = useState<string | null>(null);

  // Per-finding review UI state (keyed by finding.id)
  const [reviewStates, setReviewStates] = useState<
    Record<string, FindingReviewState>
  >({});

  // Polling ref — auto-refresh every 5s while status is 'analyzing'
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [insp, fndngs, imgs] = await Promise.all([
        getInspection(id),
        getComplianceFindings(id),
        listInspectionImages(id),
      ]);
      setInspection(insp);
      setFindings(fndngs);
      setImages(imgs);

      // Seed review state for each finding, preserving already-reviewed ones
      setReviewStates((prev) => {
        const next: Record<string, FindingReviewState> = {};
        fndngs.forEach((f) => {
          next[f.id] = prev[f.id] ?? makeDefaultReviewState();
          // If finding already has an officer decision, mark as submitted
          if (f.officer_decision) {
            next[f.id] = {
              ...next[f.id],
              submitted: true,
              localDecision: f.officer_decision,
            };
          }
        });
        return next;
      });

      // Stop polling once the pipeline has finished (findings present OR no longer analyzing)
      if (insp.status !== "analyzing") {
        if (pollRef.current) {
          clearInterval(pollRef.current);
          pollRef.current = null;
        }
      }
    } catch {
      setError("Could not load compliance data. Is the backend running?");
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  // Auto-poll while inspection is analyzing
  useEffect(() => {
    if (inspection?.status === "analyzing" && findings.length === 0) {
      if (!pollRef.current) {
        pollRef.current = setInterval(() => {
          fetchAll();
        }, 5000);
      }
    } else {
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    }
    return () => {
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
    };
  }, [inspection?.status, findings.length, fetchAll]);

  // Manual compliance evaluation trigger (fallback when Celery stalled)
  const handleTriggerEvaluation = async () => {
    setEvaluating(true);
    setEvaluateError(null);
    try {
      const newFindings = await triggerComplianceEvaluation(id);
      setFindings(newFindings);
    } catch {
      setEvaluateError(
        "Could not trigger evaluation. Ensure the backend is running."
      );
    } finally {
      setEvaluating(false);
    }
  };

  // ── Review state helpers ────────────────────────────────────────
  const updateReview = (
    findingId: string,
    patch: Partial<FindingReviewState>
  ) => {
    setReviewStates((prev) => ({
      ...prev,
      [findingId]: { ...prev[findingId], ...patch },
    }));
  };

  const handleConfirm = async (finding: ComplianceFindingAPI) => {
    const rs = reviewStates[finding.id] ?? makeDefaultReviewState();
    updateReview(finding.id, { submitting: true, error: null });
    try {
      await reviewComplianceFinding(finding.id, "confirmed", undefined, rs.corrected_fields);
      updateReview(finding.id, {
        submitting: false,
        submitted: true,
        localDecision: "confirmed",
      });
    } catch {
      updateReview(finding.id, {
        submitting: false,
        error: "Failed to submit review. Please try again.",
      });
    }
  };

  const handleOverride = async (finding: ComplianceFindingAPI) => {
    const rs = reviewStates[finding.id] ?? makeDefaultReviewState();
    if (!rs?.justification.trim()) return;
    updateReview(finding.id, { submitting: true, error: null });
    try {
      await reviewComplianceFinding(
        finding.id,
        "overridden",
        rs.justification.trim(),
        rs.corrected_fields
      );
      updateReview(finding.id, {
        submitting: false,
        submitted: true,
        localDecision: "overridden",
      });
    } catch {
      updateReview(finding.id, {
        submitting: false,
        error: "Failed to submit override. Please try again.",
      });
    }
  };

  // ── Derived state ───────────────────────────────────────────────
  const labelImage = images.find((img) => img.image_type === "label");
  const labelImageUrl = labelImage?.original_uri
    ? getImageUrl(labelImage.original_uri)
    : "/placeholder-package.png";

  // Findings that require officer review (NON_COMPLIANT / NEEDS_REVIEW)
  const findingsNeedingReview = findings.filter(
    (f) =>
      (f.result === "NON_COMPLIANT" || f.result === "NEEDS_REVIEW") &&
      !f.officer_decision
  );
  const allRequiredReviewed = findingsNeedingReview.every(
    (f) => reviewStates[f.id]?.submitted
  );

  // ── Result icon helpers ─────────────────────────────────────────
  const resultIcon = (result: ComplianceState) => {
    if (result === "COMPLIANT")
      return <ShieldCheck className="w-4 h-4 text-emerald-600" />;
    if (result === "NON_COMPLIANT")
      return <ShieldAlert className="w-4 h-4 text-rose-600" />;
    if (result === "NEEDS_REVIEW")
      return <AlertTriangle className="w-4 h-4 text-amber-500" />;
    return <HelpCircle className="w-4 h-4 text-slate-400" />;
  };

  return (
    <div className="space-y-6">
      {/* ── Page Header ─────────────────────────────────────────── */}
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-3">
          <Link
            href="/inspections"
            className="p-2 border border-slate-200 rounded-lg bg-white hover:bg-slate-50 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-slate-600" />
          </Link>
          <div>
            <h2 className="text-xl font-bold text-slate-900">
              Legal Compliance Findings
            </h2>
            <p className="text-xs text-slate-500">
              Deterministic rule engine evaluation — PRD Section 10 &amp; 12
            </p>
          </div>
        </div>

        {/* Inspection summary pill */}
        {inspection && (
          <div className="flex items-center gap-3 bg-white border border-slate-200 rounded-xl px-4 py-2.5 shadow-sm text-xs shrink-0">
            <div className="text-right">
              <p className="font-bold text-slate-800">
                {inspection.product_name ?? "Unnamed Product"}
              </p>
              <p className="text-slate-400 text-[11px]">
                {inspection.category} •{" "}
                {new Date(inspection.inspection_date).toLocaleDateString(
                  "en-IN"
                )}
              </p>
            </div>
            {inspection.overall_result && (
              <StatusPill status={inspection.overall_result} />
            )}
          </div>
        )}
      </div>

      {error && <ErrorBanner message={error} onRetry={fetchAll} />}

      {/* ── Summary Counts Row ───────────────────────────────────── */}
      {!loading && findings.length > 0 && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {(
            [
              "COMPLIANT",
              "NON_COMPLIANT",
              "NEEDS_REVIEW",
              "NOT_APPLICABLE",
            ] as ComplianceState[]
          ).map((state) => {
            const count = findings.filter((f) => f.result === state).length;
            return (
              <div
                key={state}
                className="bg-white border border-slate-200 rounded-xl px-4 py-3 shadow-sm flex items-center gap-2"
              >
                {resultIcon(state)}
                <div>
                  <p className="text-[10px] text-slate-500 font-medium leading-none mb-0.5">
                    {state.replace(/_/g, " ")}
                  </p>
                  <p className="text-lg font-extrabold text-slate-900 leading-none">
                    {count}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ── Findings Table + Inline Review ──────────────────────── */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase text-[11px]">
            <tr>
              <th className="px-4 py-3 w-6" />
              <th className="px-4 py-3">Legal Citation</th>
              <th className="px-4 py-3">Requirement</th>
              <th className="px-4 py-3">Severity</th>
              <th className="px-4 py-3">Result</th>
              <th className="px-4 py-3">Confidence</th>
              <th className="px-4 py-3">Officer Status</th>
              <th className="px-4 py-3 text-right">Evidence</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {loading &&
              Array.from({ length: 4 }).map((_, i) => (
                <SkeletonRow key={i} cols={8} />
              ))}

            {!loading && findings.length === 0 && (
              <tr>
                <td
                  colSpan={8}
                  className="px-4 py-10 text-center"
                >
                  {inspection?.status === "analyzing" ? (
                    <div className="flex flex-col items-center gap-3 text-indigo-600">
                      <Loader2 className="w-7 h-7 animate-spin" />
                      <p className="text-xs font-semibold">
                        AI CV/OCR pipeline is running… Auto-refreshing every 5s
                      </p>
                      <p className="text-[11px] text-slate-400">
                        Region detection → OCR → Field extraction → Rule evaluation
                      </p>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-3">
                      <p className="text-xs text-slate-400">
                        No compliance findings yet.
                        {inspection?.status === "completed"
                          ? " Pipeline completed but no findings were generated."
                          : " Run the analysis pipeline first."}
                      </p>
                      {inspection?.status === "completed" && (
                        <>
                          {evaluateError && (
                            <p className="text-xs text-rose-600">{evaluateError}</p>
                          )}
                          <button
                            id="trigger-eval-btn"
                            onClick={handleTriggerEvaluation}
                            disabled={evaluating}
                            className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white text-xs font-semibold rounded-lg shadow transition-colors"
                          >
                            {evaluating ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <Zap className="w-3.5 h-3.5" />
                            )}
                            {evaluating ? "Evaluating…" : "Trigger Rule Evaluation"}
                          </button>
                        </>
                      )}
                    </div>
                  )}
                </td>
              </tr>
            )}

            {!loading &&
              findings.map((finding) => {
                const rs =
                  reviewStates[finding.id] ?? makeDefaultReviewState();
                const isExpanded = rs.expanded;
                const needsReview =
                  finding.result === "NON_COMPLIANT" ||
                  finding.result === "NEEDS_REVIEW";
                const currentDecision =
                  rs.localDecision ?? finding.officer_decision;

                // Bounding boxes for this finding from its evidence items
                const boxes = finding.evidence_items
                  .filter((e) => e.cropped_image_uri)
                  .map((e, i) => ({
                    bbox: [0.05, 0.1 + i * 0.15, 0.95, 0.25 + i * 0.15] as [
                      number,
                      number,
                      number,
                      number,
                    ],
                    label: finding.rule_key ?? "Evidence",
                    confidence: finding.confidence,
                    isActive: true,
                  }));

                return (
                  <React.Fragment key={finding.id}>
                    {/* ── Main row ──────────────────────────────── */}
                    <tr
                      className={`hover:bg-slate-50/60 transition-colors ${
                        isExpanded ? "bg-indigo-50/30" : ""
                      }`}
                    >
                      {/* Expand toggle */}
                      <td className="px-3 py-3">
                        {needsReview && (
                          <button
                            onClick={() =>
                              updateReview(finding.id, {
                                expanded: !isExpanded,
                              })
                            }
                            className="p-1 rounded text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 transition-colors"
                            title={
                              isExpanded
                                ? "Collapse review panel"
                                : "Open evidence & review"
                            }
                          >
                            {isExpanded ? (
                              <ChevronUp className="w-4 h-4" />
                            ) : (
                              <ChevronDown className="w-4 h-4" />
                            )}
                          </button>
                        )}
                      </td>

                      <td className="px-4 py-3 font-semibold text-slate-800 whitespace-nowrap">
                        {finding.legal_reference ?? "—"}
                      </td>
                      <td className="px-4 py-3 text-slate-600 max-w-xs">
                        {finding.requirement ?? (
                          <span className="text-slate-300 italic">
                            No description
                          </span>
                        )}
                        {finding.violations?.length > 0 && (
                          <div className="mt-1 space-y-0.5">
                            {finding.violations.map((v) => (
                              <p
                                key={v.id}
                                className="text-[11px] text-rose-600"
                              >
                                • {v.description}
                              </p>
                            ))}
                          </div>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <SeverityBadge
                          severity={finding.violations?.[0]?.severity}
                        />
                      </td>
                      <td className="px-4 py-3">
                        <StatusPill status={finding.result} />
                      </td>
                      <td className="px-4 py-3 text-slate-500 font-mono">
                        {finding.confidence !== undefined
                          ? `${(finding.confidence * 100).toFixed(0)}%`
                          : "—"}
                      </td>
                      <td className="px-4 py-3">
                        {currentDecision ? (
                          <DecisionBadge decision={currentDecision} />
                        ) : needsReview ? (
                          <span className="text-[10px] text-amber-600 font-semibold">
                            Awaiting Review
                          </span>
                        ) : (
                          <span className="text-slate-300 text-[10px]">—</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={() =>
                            updateReview(finding.id, {
                              expanded: !isExpanded,
                            })
                          }
                          className="inline-flex items-center gap-1 text-indigo-600 hover:text-indigo-800 font-semibold"
                        >
                          {isExpanded ? (
                            <EyeOff className="w-3.5 h-3.5" />
                          ) : (
                            <Eye className="w-3.5 h-3.5" />
                          )}
                          {isExpanded ? "Hide" : "View"}
                        </button>
                      </td>
                    </tr>

                    {/* ── Expanded: Evidence Viewer + Officer Review ─ */}
                    {isExpanded && (
                      <tr>
                        <td colSpan={8} className="p-0">
                          <div className="border-t border-indigo-100 bg-slate-50 p-5 space-y-5">
                            <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
                              {/* Evidence image viewer */}
                              <div className="lg:col-span-3 space-y-2">
                                <p className="text-[11px] font-bold text-slate-600 uppercase tracking-wide">
                                  Evidence Region
                                </p>
                                <BoundingBoxViewer
                                  imageUrl={labelImageUrl}
                                  boxes={
                                    boxes.length > 0
                                      ? boxes
                                      : [
                                          {
                                            bbox: [0.05, 0.05, 0.95, 0.35],
                                            label:
                                              finding.legal_reference ??
                                              "Label",
                                            confidence: finding.confidence,
                                            isActive: true,
                                          },
                                        ]
                                  }
                                />
                                {finding.evidence_items.length > 0 && (
                                  <div className="grid grid-cols-2 gap-2">
                                    {finding.evidence_items.map((e) =>
                                      e.cropped_image_uri ? (
                                        <div
                                          key={e.id}
                                          className="rounded-lg overflow-hidden border border-slate-200"
                                        >
                                          <img
                                            src={getImageUrl(e.cropped_image_uri)}
                                            alt="Evidence crop"
                                            className="w-full object-cover h-20"
                                          />
                                        </div>
                                      ) : null
                                    )}
                                  </div>
                                )}
                              </div>

                              {/* Officer Review Panel */}
                              <div className="lg:col-span-2 space-y-4">
                                <div>
                                  <p className="text-[11px] font-bold text-slate-600 uppercase tracking-wide mb-2">
                                    Officer Review
                                  </p>
                                  <div className="rounded-lg border border-slate-200 bg-white px-4 py-3 text-xs space-y-2">
                                    <p className="font-semibold text-slate-800">
                                      {finding.legal_reference}
                                    </p>
                                    <p className="text-slate-500">
                                      AI Result:{" "}
                                      <StatusPill
                                        status={finding.result}
                                        showIcon={false}
                                      />
                                    </p>
                                  </div>
                                </div>

                                {/* Dynamic Input Fields */}
                                {finding.input_fields && finding.input_fields.length > 0 && !rs.submitted && (
                                  <div className="space-y-3">
                                    <p className="text-[11px] font-bold text-slate-600 uppercase tracking-wide">
                                      Data Capture
                                    </p>
                                    {finding.input_fields.map((field) => (
                                      <div key={field}>
                                        <label className="block text-xs font-semibold text-slate-700 mb-1 capitalize">
                                          {field.replace(/_/g, " ")}
                                        </label>
                                        <input
                                          type="text"
                                          value={rs.corrected_fields[field] ?? ""}
                                          onChange={(e) =>
                                            updateReview(finding.id, {
                                              corrected_fields: {
                                                ...rs.corrected_fields,
                                                [field]: e.target.value,
                                              },
                                            })
                                          }
                                          className="w-full text-xs p-2.5 border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                          placeholder={`Enter actual ${field.replace(/_/g, " ")}`}
                                          disabled={rs.submitted || rs.submitting}
                                        />
                                      </div>
                                    ))}
                                  </div>
                                )}

                                {/* Review submitted state */}
                                {rs.submitted ? (
                                  <div
                                    className={`rounded-lg border px-4 py-3 text-xs space-y-1 ${
                                      rs.localDecision === "confirmed"
                                        ? "border-emerald-200 bg-emerald-50"
                                        : "border-amber-200 bg-amber-50"
                                    }`}
                                  >
                                    <div className="flex items-center gap-2 font-bold">
                                      <CheckCircle2
                                        className={`w-4 h-4 ${
                                          rs.localDecision === "confirmed"
                                            ? "text-emerald-600"
                                            : "text-amber-600"
                                        }`}
                                      />
                                      <span
                                        className={
                                          rs.localDecision === "confirmed"
                                            ? "text-emerald-700"
                                            : "text-amber-700"
                                        }
                                      >
                                        {rs.localDecision === "confirmed"
                                          ? "Finding Confirmed"
                                          : "Finding Overridden"}
                                      </span>
                                    </div>
                                    {rs.justification && (
                                      <p className="text-slate-600 text-[11px] italic pl-6">
                                        &ldquo;{rs.justification}&rdquo;
                                      </p>
                                    )}
                                    <p className="text-[10px] text-slate-400 pl-6">
                                      Immutably logged to audit trail (PRD §16)
                                    </p>
                                  </div>
                                ) : (
                                  <>
                                    {/* Action buttons */}
                                    <div className="flex gap-2">
                                      <button
                                        onClick={() => {
                                          updateReview(finding.id, {
                                            override: false,
                                          });
                                          handleConfirm(finding);
                                        }}
                                        disabled={rs.submitting}
                                        className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border border-emerald-300 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 disabled:opacity-50 transition-colors"
                                      >
                                        {rs.submitting && !rs.override ? (
                                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                        ) : (
                                          <CheckCircle2 className="w-3.5 h-3.5" />
                                        )}
                                        Confirm Finding
                                      </button>
                                      <button
                                        onClick={() =>
                                          updateReview(finding.id, {
                                            override: !rs.override,
                                          })
                                        }
                                        disabled={rs.submitting}
                                        className={`flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border transition-colors ${
                                          rs.override
                                            ? "border-amber-500 bg-amber-600 text-white"
                                            : "border-amber-300 bg-amber-50 text-amber-700 hover:bg-amber-100"
                                        } disabled:opacity-50`}
                                      >
                                        <RefreshCw className="w-3.5 h-3.5" />
                                        Override
                                      </button>
                                    </div>

                                    {/* Override justification panel */}
                                    {rs.override && (
                                      <div className="space-y-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                                        <div className="flex items-center gap-1.5 text-amber-800 text-[11px] font-bold">
                                          <AlertTriangle className="w-3.5 h-3.5" />
                                          Mandatory Justification (PRD §16 —
                                          Immutably Logged)
                                        </div>
                                        <textarea
                                          rows={3}
                                          value={rs.justification}
                                          onChange={(e) =>
                                            updateReview(finding.id, {
                                              justification: e.target.value,
                                            })
                                          }
                                          placeholder="State precise legal/physical evidence justification for overriding this AI finding…"
                                          className="w-full text-xs p-2.5 border border-amber-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-amber-500 resize-none"
                                        />
                                        <button
                                          onClick={() =>
                                            handleOverride(finding)
                                          }
                                          disabled={
                                            !rs.justification.trim() ||
                                            rs.submitting
                                          }
                                          className="w-full inline-flex items-center justify-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-amber-600 hover:bg-amber-700 disabled:bg-slate-300 disabled:text-slate-500 text-white transition-colors"
                                        >
                                          {rs.submitting ? (
                                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                          ) : (
                                            <RefreshCw className="w-3.5 h-3.5" />
                                          )}
                                          Submit Override
                                        </button>
                                      </div>
                                    )}

                                    {rs.error && (
                                      <p className="text-[11px] text-rose-600">
                                        {rs.error}
                                      </p>
                                    )}
                                  </>
                                )}
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
          </tbody>
        </table>
      </div>

      {/* ── Finalize Button ──────────────────────────────────────── */}
      {!loading && findings.length > 0 && (
        <div className="flex items-center justify-between bg-white border border-slate-200 rounded-xl px-5 py-4 shadow-sm">
          <div className="text-xs text-slate-500">
            {findingsNeedingReview.length > 0 && !allRequiredReviewed ? (
              <span className="text-amber-600 font-semibold">
                {
                  findingsNeedingReview.filter(
                    (f) => !reviewStates[f.id]?.submitted
                  ).length
                }{" "}
                finding(s) still require officer review before finalizing.
              </span>
            ) : (
              <span className="text-emerald-600 font-semibold">
                All required findings reviewed. Ready to generate report.
              </span>
            )}
          </div>
          <Link
            href={`/inspections/${id}/report`}
            className={`inline-flex items-center gap-1.5 px-5 py-2.5 text-xs font-semibold rounded-lg shadow transition-colors ${
              allRequiredReviewed
                ? "bg-indigo-600 hover:bg-indigo-700 text-white"
                : "bg-slate-200 text-slate-400 pointer-events-none"
            }`}
            aria-disabled={!allRequiredReviewed}
          >
            <FileText className="w-4 h-4" />
            Generate Compliance Report
          </Link>
        </div>
      )}
    </div>
  );
}
