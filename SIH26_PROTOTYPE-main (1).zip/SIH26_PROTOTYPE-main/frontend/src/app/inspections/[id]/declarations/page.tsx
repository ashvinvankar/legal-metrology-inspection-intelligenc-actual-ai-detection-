"use client";

import React, { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  Edit3,
  Check,
  RefreshCw,
  Loader2,
  HelpCircle,
  LayoutGrid,
  Table as TableIcon,
  ShieldCheck,
  Calculator,
} from "lucide-react";
import { getExtractedDeclarations, getInspection, updateExtractedDeclaration } from "@/lib/api";
import { ErrorBanner } from "@/components/ui/ErrorBanner";
import { AICopilotDrawer } from "@/components/copilot/AICopilotDrawer";
import { InspectionStepper } from "@/components/layout/InspectionStepper";
import type { ExtractedField, Inspection } from "@/types";

const CANONICAL_FIELD_TITLES: Record<string, string> = {
  mrp: "Maximum Retail Price (MRP)",
  net_quantity: "Net Quantity Declaration",
  unit_sale_price: "Unit Sale Price (USP)",
  date_of_manufacture: "Date of Manufacture / Pkd",
  consumer_care_contact: "Consumer Care Details",
  manufacturer_name: "Manufacturer Corporate Name",
  manufacturer_address: "Manufacturer Physical Address",
  packer_name: "Packer Corporate Name",
  importer_name: "Importer Corporate Name",
  country_of_origin: "Country of Origin",
};

export default function DeclarationsPage() {
  const params = useParams();
  const id = params.id as string;

  const [inspection, setInspection] = useState<Inspection | null>(null);
  const [declarations, setDeclarations] = useState<ExtractedField[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"cards" | "table">("cards");

  const [editingField, setEditingField] = useState<ExtractedField | null>(null);
  const [editRawValue, setEditRawValue] = useState("");
  const [editJustification, setEditJustification] = useState("");
  const [savingEdit, setSavingEdit] = useState(false);
  const [editSuccessMsg, setEditSuccessMsg] = useState<string | null>(null);

  const fetchDeclarations = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [inspData, fieldsData] = await Promise.all([
        getInspection(id),
        getExtractedDeclarations(id),
      ]);
      setInspection(inspData);
      setDeclarations(fieldsData);
    } catch {
      setError("Could not load extracted declarations. Is the backend running?");
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchDeclarations();
  }, [fetchDeclarations]);

  const handleOpenEdit = (field: ExtractedField) => {
    setEditingField(field);
    setEditRawValue(field.raw_value || "");
    setEditJustification("");
    setEditSuccessMsg(null);
  };

  const handleSaveEdit = async () => {
    if (!editingField) return;
    setSavingEdit(true);
    try {
      const updated = await updateExtractedDeclaration(id, editingField.id, {
        raw_value: editRawValue,
        officer_confirmed: true,
        justification: editJustification || "Officer verified during visual inspection",
      });

      setDeclarations((prev) =>
        prev.map((f) => (f.id === updated.id ? updated : f))
      );
      setEditSuccessMsg("Declaration verified & updated in audit log.");
      setTimeout(() => {
        setEditingField(null);
        setEditSuccessMsg(null);
      }, 1200);
    } catch {
      alert("Failed to save correction. Please check backend connection.");
    } finally {
      setSavingEdit(false);
    }
  };

  return (
    <div className="space-y-5 max-w-7xl mx-auto pb-12 px-4">
      {/* Stepper */}
      <InspectionStepper inspectionId={id} />

      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 animate-fade-in-up">
        <div className="flex items-center gap-3">
          <Link
            href={`/inspections/${id}/progress`}
            className="p-2 border border-slate-200 rounded-xl bg-white hover:bg-slate-50 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-slate-600" />
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-slate-900 tracking-tight">
                Extracted Declarations
              </h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 border border-indigo-200">
                Rule 6 Engine
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              Information parsed by Vision AI & OCR from the packaging evidence
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <div className="bg-slate-100 p-1 rounded-xl flex items-center border border-slate-200/60 shadow-inner">
            <button
              onClick={() => setViewMode("cards")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                viewMode === "cards"
                  ? "bg-white text-slate-900 shadow-sm"
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" /> Cards
            </button>
            <button
              onClick={() => setViewMode("table")}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                viewMode === "table"
                  ? "bg-white text-slate-900 shadow-sm"
                  : "text-slate-500 hover:text-slate-800"
              }`}
            >
              <TableIcon className="w-3.5 h-3.5" /> Table
            </button>
          </div>

          <Link
            href={`/inspections/${id}/evidence`}
            className="btn-primary"
          >
            Review Evidence <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>

      {error && <ErrorBanner message={error} onRetry={fetchDeclarations} />}

      {/* Loading Skeleton */}
      {loading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 animate-fade-in-up">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="premium-card p-5 space-y-4">
              <div className="skeleton h-4 w-1/2" />
              <div className="skeleton h-8 w-full rounded-xl" />
              <div className="skeleton h-3 w-1/3" />
            </div>
          ))}
        </div>
      )}

      {/* Empty State */}
      {!loading && declarations.length === 0 && (
        <div className="premium-card p-12 text-center space-y-4 animate-fade-in-scale">
          <div className="w-16 h-16 rounded-2xl bg-indigo-50 flex items-center justify-center mx-auto animate-float">
            <HelpCircle className="w-8 h-8 text-indigo-500" />
          </div>
          <div>
            <h3 className="text-base font-black text-slate-900">No Declarations Found</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 leading-relaxed">
              The pipeline did not extract any standard fields. The images might be blurry, or analysis hasn&apos;t completed.
            </p>
          </div>
          <Link href={`/inspections/${id}/upload`} className="btn-primary">
            Upload Better Photos
          </Link>
        </div>
      )}

      {/* Card Grid View */}
      {!loading && declarations.length > 0 && viewMode === "cards" && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {declarations.map((field, i) => {
            const canonicalTitle = CANONICAL_FIELD_TITLES[field.field_name] || field.field_name.replace(/_/g, " ");
            const norm = (field.normalized_value || {}) as Record<string, any>;
            const mathConsistent = norm.math_consistency;
            const conf = field.confidence ?? 0;
            const isHigh = conf >= 0.9;
            const isMed = conf >= 0.6;

            return (
              <div
                key={field.id}
                className={`premium-card p-5 flex flex-col justify-between stagger-${Math.min(i + 1, 8)} ${
                  field.officer_confirmed ? "premium-card-compliant" : ""
                }`}
              >
                <div className="space-y-4">
                  {/* Top Bar */}
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h4 className="text-xs font-black text-slate-900 leading-snug">
                        {canonicalTitle}
                      </h4>
                      <p className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest mt-0.5">
                        {field.field_name}
                      </p>
                    </div>
                    {/* Confidence gauge mini */}
                    <div className="flex flex-col items-end gap-1 shrink-0">
                      <span className={`text-[10px] font-black tabular-nums ${isHigh ? "text-emerald-600" : isMed ? "text-amber-600" : "text-rose-600"}`}>
                        {(conf * 100).toFixed(0)}%
                      </span>
                      <div className="w-12 h-1.5 rounded-full bg-slate-100 overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-1000 ${isHigh ? "bg-emerald-500" : isMed ? "bg-amber-500" : "bg-rose-500"}`}
                          style={{ width: `${conf * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Value Block */}
                  <div className="p-3.5 bg-slate-50/80 rounded-xl border border-slate-100 shadow-inner">
                    <p className="text-[9px] uppercase font-bold text-slate-400 tracking-wider mb-1">
                      Detected Value
                    </p>
                    <p className="text-xs font-mono font-bold text-slate-800 break-words">
                      {field.raw_value ? `"${field.raw_value}"` : <span className="text-rose-500 italic font-sans">Not detected</span>}
                    </p>
                  </div>

                  {/* Math / Normalization details */}
                  {mathConsistent && (
                    <div className={`p-2.5 rounded-xl text-[10px] font-bold flex items-center gap-2 border ${
                        mathConsistent.consistent ? "bg-emerald-50 text-emerald-800 border-emerald-200" : "bg-rose-50 text-rose-800 border-rose-200"
                      }`}
                    >
                      <Calculator className="w-3.5 h-3.5 shrink-0" />
                      <span>
                        {mathConsistent.consistent
                          ? `USP math verified (Expected: ₹${mathConsistent.expected_usp})`
                          : `USP mismatch: math indicates ₹${mathConsistent.expected_usp}`}
                      </span>
                    </div>
                  )}

                  {norm.pincode && (
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-indigo-50 border border-indigo-200 text-indigo-700 text-[10px] font-bold">
                      <span>PIN Code:</span>
                      <span className="font-mono">{norm.pincode}</span>
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between">
                  <div>
                    {field.officer_confirmed ? (
                      <span className="badge-compliant">
                        <Check className="w-3 h-3" /> Verified
                      </span>
                    ) : (
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">AI Parse</span>
                    )}
                  </div>
                  <button
                    onClick={() => handleOpenEdit(field)}
                    className="btn-ghost !px-2.5 !py-1"
                  >
                    <Edit3 className="w-3.5 h-3.5" /> Edit
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Table View */}
      {!loading && declarations.length > 0 && viewMode === "table" && (
        <div className="premium-card overflow-hidden animate-fade-in-up">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 font-black uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="px-5 py-4">Field</th>
                  <th className="px-5 py-4">Value</th>
                  <th className="px-5 py-4">Confidence</th>
                  <th className="px-5 py-4">Status</th>
                  <th className="px-5 py-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {declarations.map((field, i) => {
                  const canonicalTitle = CANONICAL_FIELD_TITLES[field.field_name] || field.field_name;
                  const conf = field.confidence ?? 0;
                  const isHigh = conf >= 0.9;
                  const isMed = conf >= 0.6;

                  return (
                    <tr key={field.id} className={`hover:bg-slate-50/70 transition-colors stagger-${Math.min(i + 1, 8)}`}>
                      <td className="px-5 py-3.5">
                        <p className="font-bold text-slate-900">{canonicalTitle}</p>
                        <p className="text-[10px] font-mono text-slate-400">{field.field_name}</p>
                      </td>
                      <td className="px-5 py-3.5 font-mono text-slate-700 font-bold max-w-xs break-words">
                        {field.raw_value || <span className="text-slate-300 italic font-sans">None</span>}
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <span className={`text-[10px] font-black tabular-nums w-8 ${isHigh ? "text-emerald-600" : isMed ? "text-amber-600" : "text-rose-600"}`}>
                            {(conf * 100).toFixed(0)}%
                          </span>
                          <div className="w-16 h-1.5 rounded-full bg-slate-100 overflow-hidden">
                            <div
                              className={`h-full rounded-full ${isHigh ? "bg-emerald-500" : isMed ? "bg-amber-500" : "bg-rose-500"}`}
                              style={{ width: `${conf * 100}%` }}
                            />
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3.5">
                        {field.officer_confirmed ? (
                          <span className="badge-compliant"><Check className="w-3 h-3" /> Confirmed</span>
                        ) : (
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Pending</span>
                        )}
                      </td>
                      <td className="px-5 py-3.5 text-right">
                        <button
                          onClick={() => handleOpenEdit(field)}
                          className="btn-ghost !px-2.5 !py-1"
                        >
                          <Edit3 className="w-3.5 h-3.5" /> Edit
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Edit Modal */}
      {editingField && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 glass-dark">
          <div className="premium-card max-w-lg w-full p-6 space-y-5 animate-fade-in-scale shadow-2xl">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-black text-slate-900">Correct Declaration</h3>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">
                  {CANONICAL_FIELD_TITLES[editingField.field_name] || editingField.field_name}
                </p>
              </div>
              <button
                onClick={() => setEditingField(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition-colors"
              >
                ✕
              </button>
            </div>

            {editSuccessMsg && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-800 flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600" />
                {editSuccessMsg}
              </div>
            )}

            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 tracking-wider mb-1.5 block">
                  Detected Text
                </label>
                <textarea
                  rows={3}
                  value={editRawValue}
                  onChange={(e) => setEditRawValue(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 font-mono text-xs font-bold text-slate-800 transition-all shadow-inner"
                />
              </div>

              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 tracking-wider mb-1.5 block">
                  Verification Justification
                </label>
                <input
                  type="text"
                  value={editJustification}
                  onChange={(e) => setEditJustification(e.target.value)}
                  placeholder="e.g. Physically verified on label"
                  className="w-full p-3 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-xs font-medium text-slate-800 transition-all shadow-sm"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button onClick={() => setEditingField(null)} className="btn-ghost">
                Cancel
              </button>
              <button onClick={handleSaveEdit} disabled={savingEdit} className="btn-primary">
                {savingEdit ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ShieldCheck className="w-3.5 h-3.5" />}
                Confirm &amp; Log
              </button>
            </div>
          </div>
        </div>
      )}

      <AICopilotDrawer inspectionId={id} productName={inspection?.product_name} />
    </div>
  );
}
