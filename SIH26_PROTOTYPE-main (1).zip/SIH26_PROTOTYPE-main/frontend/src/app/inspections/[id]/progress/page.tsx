"use client";

import React, { useEffect, useState, useRef } from "react";
import { useRouter, useParams } from "next/navigation";
import Link from "next/link";
import {
  CheckCircle2,
  Loader2,
  AlertCircle,
  ArrowRight,
  Cpu,
  Scan,
  FileSearch,
  Scale,
  Sparkles,
  Zap,
} from "lucide-react";
import { getAnalysisStatus } from "@/lib/api";
import { InspectionStepper } from "@/components/layout/InspectionStepper";
import type { AnalysisStatusResponse } from "@/types";

interface PipelineStep {
  key: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  color: string;
  activeColor: string;
}

const PIPELINE_STEPS: PipelineStep[] = [
  {
    key: "PREPROCESSING",
    name: "Image Enhancement",
    description: "CLAHE contrast boost · glare suppression · Hough deskew",
    icon: <Scan className="w-4 h-4" />,
    color: "bg-sky-100 text-sky-600",
    activeColor: "bg-sky-600",
  },
  {
    key: "REGION_DETECTION",
    name: "Declaration Localization",
    description: "Gemini 3.8 Flash multimodal · YOLO spatial bounding boxes",
    icon: <Cpu className="w-4 h-4" />,
    color: "bg-violet-100 text-violet-600",
    activeColor: "bg-violet-600",
  },
  {
    key: "TEXT_EXTRACTION",
    name: "Multilingual OCR",
    description: "Multi-pass EasyOCR · Hindi / English · dot-matrix recovery",
    icon: <FileSearch className="w-4 h-4" />,
    color: "bg-amber-100 text-amber-600",
    activeColor: "bg-amber-500",
  },
  {
    key: "COMPLIANCE_EVALUATION",
    name: "Legal Metrology Engine",
    description: "Rule 6 · Rule 6(11) USP math · FSSAI validation",
    icon: <Scale className="w-4 h-4" />,
    color: "bg-emerald-100 text-emerald-600",
    activeColor: "bg-emerald-600",
  },
];

export default function AnalysisProgressPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;

  const [taskStatus, setTaskStatus] = useState<AnalysisStatusResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const stageOrder = ["QUEUED", "PREPROCESSING", "REGION_DETECTION", "TEXT_EXTRACTION", "COMPLIANCE_EVALUATION", "COMPLETED"];

  const getStageIndex = (stageName: string) => {
    const idx = stageOrder.indexOf(stageName.toUpperCase());
    return idx >= 0 ? idx : 1;
  };

  const currentStageIdx = taskStatus ? getStageIndex(taskStatus.stage || "") : 0;

  useEffect(() => {
    const poll = async () => {
      try {
        const res = await getAnalysisStatus(id);
        setTaskStatus(res);

        if (res.status === "completed") {
          if (pollRef.current) clearInterval(pollRef.current);
          setDone(true);
          setTimeout(() => { router.push(`/inspections/${id}/declarations`); }, 200);
        } else if (res.status === "failed") {
          if (pollRef.current) clearInterval(pollRef.current);
          setError(res.error_message || "Analysis pipeline encountered a failure.");
        }
      } catch {
        // Task still spinning up
      }
    };

    poll();
    pollRef.current = setInterval(poll, 500);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [id, router]);

  const progressPct = taskStatus ? taskStatus.progress_percent : 8;

  return (
    <div className="max-w-2xl mx-auto space-y-4 py-8 px-4">
      {/* Stepper */}
      <InspectionStepper inspectionId={id} />

      {/* Header badge */}
      <div className="text-center space-y-2 pt-2">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass-brand text-xs font-bold text-indigo-700 animate-fade-in-scale">
          <Sparkles className="w-3.5 h-3.5 text-violet-500 animate-pulse" />
          Multimodal Perception Pipeline Active
        </div>
        <h2 className="text-2xl font-black text-slate-900 tracking-tight">
          Processing Evidence
        </h2>
        <p className="text-xs text-slate-500">
          Gemini Vision · OCR · Legal Metrology Rule Engine
        </p>
      </div>

      {/* Error state */}
      {error && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-800 flex items-start gap-3 animate-fade-in-up">
          <AlertCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
          <div className="space-y-2">
            <p className="font-bold">Pipeline Failure</p>
            <p className="text-slate-600">{error}</p>
            <Link href={`/inspections/${id}/upload`} className="font-semibold text-rose-700 hover:underline inline-flex items-center gap-1">
              ← Return to Upload
            </Link>
          </div>
        </div>
      )}

      {/* Main progress card */}
      <div className="premium-card p-6 space-y-5 animate-fade-in-up">

        {/* Progress bar */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-700">Pipeline Progress</span>
            <span className="font-mono font-black text-indigo-600 tabular-nums">
              {progressPct}%
            </span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
            {done ? (
              <div className="h-3 rounded-full bg-gradient-to-r from-emerald-500 to-emerald-400 w-full transition-all duration-700 animate-success-pop" />
            ) : (
              <div
                className="h-3 rounded-full bg-gradient-to-r from-indigo-600 via-violet-500 to-indigo-600 pipeline-track transition-all duration-700"
                style={{ width: `${progressPct}%` }}
              />
            )}
          </div>
        </div>

        {/* Stage steps */}
        <div className="space-y-2.5">
          {PIPELINE_STEPS.map((step, idx) => {
            const stepStageIdx = idx + 1;
            const isDone = currentStageIdx > stepStageIdx || done;
            const isCurrent = currentStageIdx === stepStageIdx && !done;

            return (
              <div
                key={step.key}
                className={`p-3.5 rounded-2xl border flex items-center gap-3.5 transition-all duration-300 ${
                  isDone
                    ? "bg-emerald-50/60 border-emerald-200/60"
                    : isCurrent
                    ? "bg-indigo-50/70 border-indigo-200 shadow-sm"
                    : "bg-slate-50/30 border-slate-100 opacity-50"
                }`}
              >
                {/* Icon */}
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition-all duration-300 ${
                    isDone
                      ? "bg-emerald-100 text-emerald-600"
                      : isCurrent
                      ? `${step.activeColor} text-white shadow-lg`
                      : step.color
                  }`}
                >
                  {isDone ? (
                    <CheckCircle2 className="w-4 h-4" />
                  ) : isCurrent ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    step.icon
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className={`text-xs font-bold ${isDone ? "text-slate-700" : isCurrent ? "text-indigo-900" : "text-slate-400"}`}>
                      {step.name}
                    </p>
                    {isDone && (
                      <span className="text-[10px] font-bold text-emerald-600 uppercase tracking-widest">Done</span>
                    )}
                    {isCurrent && (
                      <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest animate-pulse">Running</span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5 font-mono">{step.description}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Backend-backed status */}
        <div className="bg-slate-950 rounded-2xl p-4 font-mono text-[11px]">
          <div className="flex items-center gap-1.5 mb-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400" />
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
            <span className="text-slate-500 ml-2 text-[10px]">live pipeline status</span>
          </div>
          <p className={done ? "text-emerald-400" : "text-slate-300"}><span className="mr-1.5 text-teal-400">&gt;</span>{done ? "Analysis completed. Opening extracted declarations…" : `Current stage: ${taskStatus?.stage || "waiting for worker"}`}</p>
          {taskStatus?.error_message && <p className="mt-2 text-rose-300"><span className="mr-1.5 text-rose-400">&gt;</span>{taskStatus.error_message}</p>}
        </div>

        {/* Footer */}
        <div className="pt-1 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
          <span className="font-mono">Task: {taskStatus?.task_id?.slice(0, 12) ?? "initializing..."}</span>
          {done ? (
            <span className="flex items-center gap-1 text-emerald-600 font-bold">
              <Zap className="w-3.5 h-3.5" /> Redirecting...
            </span>
          ) : (
            <span className="flex items-center gap-1">
              <Loader2 className="w-3 h-3 animate-spin" /> Auto-redirecting on finish
            </span>
          )}
        </div>
      </div>

      {/* Manual skip link */}
      {!done && (
        <div className="text-center">
          <Link
            href={`/inspections/${id}/declarations`}
            className="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-indigo-600 transition-colors font-medium"
          >
            Skip to Declarations <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      )}
    </div>
  );
}
