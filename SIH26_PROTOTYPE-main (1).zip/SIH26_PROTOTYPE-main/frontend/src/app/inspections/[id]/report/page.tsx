"use client";

import React, { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import {
  Download,
  FileText,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ArrowLeft,
  QrCode,
  Printer,
  Scale,
  RefreshCw,
  Loader2,
  AlertCircle,
  BarChart3,
  Shield,
  Clock,
  TrendingUp,
  Zap,
} from "lucide-react";
import { downloadGeneratedReport, generateInspectionReport, getInspection, getComplianceFindings, getExtractedDeclarations, triggerAnalysis } from "@/lib/api";
import { StatusPill } from "@/components/compliance/StatusPill";
import { AICopilotDrawer } from "@/components/copilot/AICopilotDrawer";
import { InspectionStepper } from "@/components/layout/InspectionStepper";
import type { Inspection, ComplianceFindingAPI, ExtractedField } from "@/types";

const FIELD_LABELS: Record<string, string> = {
  mrp: "Maximum Retail Price",
  net_quantity: "Net Quantity",
  unit_sale_price: "Unit Sale Price",
  date_of_manufacture: "Mfg / Pkd Date",
  consumer_care_contact: "Consumer Care",
  manufacturer_name: "Manufacturer",
  manufacturer_address: "Manufacturer Address",
  packer_name: "Packer",
  importer_name: "Importer",
  country_of_origin: "Country of Origin",
};

function SkeletonBlock({ className = "" }: { className?: string }) {
  return <div className={`skeleton ${className}`} />;
}

export default function ReportPreviewPage() {
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;

  const [inspection, setInspection] = useState<Inspection | null>(null);
  const [findings, setFindings] = useState<ComplianceFindingAPI[]>([]);
  const [declarations, setDeclarations] = useState<ExtractedField[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [rerunning, setRerunning] = useState(false);
  const [exporting, setExporting] = useState(false);

  const fetchReportData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [insp, fnd, decl] = await Promise.all([
        getInspection(id),
        getComplianceFindings(id),
        getExtractedDeclarations(id),
      ]);
      setInspection(insp);
      setFindings(fnd);
      setDeclarations(decl);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed to load report data.";
      setError(msg);
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => { fetchReportData(); }, [fetchReportData]);

  const handleRerunAnalysis = async () => {
    setRerunning(true);
    try {
      await triggerAnalysis(id);
      router.push(`/inspections/${id}/progress`);
    } catch {
      setRerunning(false);
    }
  };

  const handleDownloadReport = async () => {
    setExporting(true);
    setError(null);
    try {
      const report = await generateInspectionReport(id);
      const file = await downloadGeneratedReport(report.id);
      const downloadUrl = URL.createObjectURL(file);
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.download = `neuracheck-report-${id.slice(0, 8)}.pdf`;
      link.click();
      URL.revokeObjectURL(downloadUrl);
    } catch {
      setError("The report could not be generated. Confirm that the report service is available and try again.");
    } finally {
      setExporting(false);
    }
  };

  const violations = findings.filter((f) => f.result === "NON_COMPLIANT");
  const compliantCount = findings.filter((f) => f.result === "COMPLIANT").length;
  const reviewCount = findings.filter((f) => f.result === "NEEDS_REVIEW").length;
  const overallResult = inspection?.overall_result
    || (violations.length > 0 ? "NON_COMPLIANT" : reviewCount > 0 ? "NEEDS_REVIEW" : findings.length > 0 ? "COMPLIANT" : null);

  const dateStr = new Date().toLocaleDateString("en-IN", {
    day: "2-digit", month: "long", year: "numeric",
  });

  return (
    <div className="max-w-4xl mx-auto space-y-5 pb-16 px-4">
      {/* Stepper */}
      <InspectionStepper inspectionId={id} />

      {/* Top action bar */}
      <div className="flex items-center justify-between print:hidden animate-fade-in-up">
        <div className="flex items-center gap-3">
          <Link
            href={`/inspections/${id}/review`}
            className="p-2 border border-slate-200 rounded-xl bg-white hover:bg-slate-50 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-slate-600" />
          </Link>
          <div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              Compliance Report
            </h2>
            <p className="text-xs text-slate-400 font-medium">
              Legal Metrology Act, 2009 · Packaged Commodities Rules, 2011
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchReportData}
            className="btn-ghost text-xs"
            disabled={loading}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
            Refresh
          </button>
          <button
            onClick={() => window.print()}
            className="btn-ghost text-xs"
          >
            <Printer className="w-3.5 h-3.5" /> Print
          </button>
          <button onClick={handleDownloadReport} disabled={exporting || loading} className="btn-primary">
            {exporting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />} {exporting ? "Generating…" : "Download PDF"}
          </button>
        </div>
      </div>

      {/* Error banner */}
      {error && !loading && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-3 text-xs animate-fade-in-up">
          <AlertCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-bold text-rose-800">Failed to load report</p>
            <p className="text-slate-600">{error}</p>
            <button onClick={fetchReportData} className="font-semibold text-rose-700 hover:underline">
              Try again →
            </button>
          </div>
        </div>
      )}

      {/* Not analyzed yet */}
      {!loading && !error && findings.length === 0 && (
        <div className="premium-card p-10 text-center space-y-5 animate-fade-in-scale">
          <div className="w-16 h-16 rounded-2xl bg-indigo-50 flex items-center justify-center mx-auto animate-float">
            <BarChart3 className="w-8 h-8 text-indigo-500" />
          </div>
          <div className="space-y-2">
            <h3 className="text-base font-black text-slate-900">No Analysis Data Yet</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              The inspection pipeline has not run yet for this inspection, or results haven&apos;t been generated. Run analysis to generate the compliance report.
            </p>
          </div>
          <div className="flex items-center justify-center gap-3">
            <button
              onClick={handleRerunAnalysis}
              disabled={rerunning}
              className="btn-primary"
            >
              {rerunning ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
              {rerunning ? "Queuing..." : "Run Inspection Analysis"}
            </button>
            <Link href={`/inspections/${id}/upload`} className="btn-ghost">
              ← Back to Upload
            </Link>
          </div>
        </div>
      )}

      {/* Loading skeleton */}
      {loading && (
        <div className="space-y-4 animate-fade-in-up">
          <div className="premium-card p-8 space-y-4">
            <SkeletonBlock className="h-6 w-1/2" />
            <div className="grid grid-cols-4 gap-4">
              {[...Array(4)].map((_, i) => <SkeletonBlock key={i} className="h-16" />)}
            </div>
          </div>
          <div className="premium-card p-6 space-y-3">
            <SkeletonBlock className="h-5 w-40" />
            {[...Array(5)].map((_, i) => <SkeletonBlock key={i} className="h-10" />)}
          </div>
        </div>
      )}

      {/* Main Report Certificate */}
      {!loading && (findings.length > 0 || declarations.length > 0) && (
        <div className="space-y-5 animate-fade-in-up">
          {/* Certificate header card */}
          <div className="bg-slate-950 rounded-3xl p-8 text-white relative overflow-hidden print:bg-white print:text-slate-900">
            {/* Background decoration */}
            <div className="absolute inset-0 opacity-10">
              <div className="absolute -top-16 -right-16 w-64 h-64 rounded-full bg-indigo-500 blur-3xl" />
              <div className="absolute -bottom-16 -left-16 w-64 h-64 rounded-full bg-violet-500 blur-3xl" />
            </div>

            <div className="relative flex items-start justify-between gap-6">
              <div className="space-y-3">
                {/* Ministry header */}
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-indigo-300">
                    Government of India · Ministry of Consumer Affairs
                  </p>
                  <h1 className="text-xl font-black tracking-tight mt-1">
                    DEPARTMENT OF LEGAL METROLOGY
                  </h1>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Statutory Verification Certificate · Packaged Commodities Rules, 2011
                  </p>
                </div>

                {/* Product info */}
                <div className="flex items-center gap-4 pt-3 border-t border-white/10">
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Product</p>
                    <p className="text-sm font-bold text-white mt-0.5">
                      {inspection?.product_name || "Pre-packaged Commodity"}
                    </p>
                    <p className="text-xs text-slate-400">{inspection?.category || "Packaged Food"}</p>
                  </div>
                  <div className="w-px h-10 bg-white/10" />
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Report Date</p>
                    <p className="text-xs font-semibold text-white mt-0.5 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-indigo-400" /> {dateStr}
                    </p>
                  </div>
                  <div className="w-px h-10 bg-white/10" />
                  <div>
                    <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold">Report ID</p>
                    <p className="text-xs font-mono font-bold text-indigo-300 mt-0.5">
                      #{id.slice(0, 8).toUpperCase()}
                    </p>
                  </div>
                </div>
              </div>

              {/* QR + Status */}
              <div className="flex flex-col items-center gap-3 shrink-0">
                <div className="w-16 h-16 bg-white/10 border border-white/20 rounded-2xl flex items-center justify-center">
                  <QrCode className="w-10 h-10 text-white/70" />
                </div>
                {overallResult && (
                  <div className={`px-4 py-1.5 rounded-full text-[11px] font-black uppercase tracking-widest border ${
                    overallResult === "COMPLIANT"
                      ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-300 status-ring-compliant"
                      : overallResult === "NON_COMPLIANT"
                      ? "bg-rose-500/20 border-rose-500/40 text-rose-300 status-ring-violation"
                      : "bg-amber-500/20 border-amber-500/40 text-amber-300"
                  }`}>
                    {overallResult === "COMPLIANT" ? "✓ Compliant" : overallResult === "NON_COMPLIANT" ? "✗ Non-Compliant" : "⚠ Review"}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Stats summary row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              { label: "Total Rules Evaluated", value: findings.length, icon: <Scale className="w-5 h-5 text-indigo-500" />, bg: "bg-indigo-50", color: "text-indigo-700" },
              { label: "Compliant Rules", value: compliantCount, icon: <CheckCircle2 className="w-5 h-5 text-emerald-500" />, bg: "bg-emerald-50", color: "text-emerald-700" },
              { label: "Violations Found", value: violations.length, icon: <XCircle className="w-5 h-5 text-rose-500" />, bg: "bg-rose-50", color: "text-rose-700" },
              { label: "Declarations Extracted", value: declarations.length, icon: <FileText className="w-5 h-5 text-violet-500" />, bg: "bg-violet-50", color: "text-violet-700" },
            ].map((stat, i) => (
              <div key={i} className={`premium-card p-4 flex items-center gap-3 stagger-${i + 1}`}>
                <div className={`w-10 h-10 rounded-xl ${stat.bg} flex items-center justify-center shrink-0`}>
                  {stat.icon}
                </div>
                <div>
                  <p className={`text-xl font-black ${stat.color}`}>{stat.value}</p>
                  <p className="text-[10px] text-slate-500 font-medium leading-tight">{stat.label}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Declarations audit table */}
          {declarations.length > 0 && (
            <div className="premium-card overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-indigo-600" />
                  <h3 className="text-sm font-black text-slate-900">Mandatory Declarations Audit</h3>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 border border-indigo-200">Rule 6 Examination</span>
                </div>
                <TrendingUp className="w-4 h-4 text-slate-400" />
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-100">
                    <tr>
                      {["Statutory Field", "Detected Transcription", "AI Confidence", "Officer Status"].map((h) => (
                        <th key={h} className="px-5 py-3 text-[10px] font-black text-slate-500 uppercase tracking-wider">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {declarations.map((d, i) => {
                      const conf = d.confidence ?? 0;
                      const isHigh = conf >= 0.9;
                      const isMed = conf >= 0.6;
                      return (
                        <tr key={d.id} className={`hover:bg-slate-50/70 transition-colors stagger-${Math.min(i + 1, 8)}`}>
                          <td className="px-5 py-3.5">
                            <p className="font-bold text-slate-800">{FIELD_LABELS[d.field_name] ?? d.field_name.replace(/_/g, " ")}</p>
                            <p className="text-[10px] font-mono text-slate-400">{d.field_name}</p>
                          </td>
                          <td className="px-5 py-3.5 font-mono text-slate-700 max-w-xs">
                            {d.raw_value ? (
                              <span className="text-slate-800">&ldquo;{d.raw_value}&rdquo;</span>
                            ) : (
                              <span className="text-rose-500 italic font-sans">Missing / Not Detected</span>
                            )}
                          </td>
                          <td className="px-5 py-3.5">
                            <div className="space-y-1.5">
                              <div className="confidence-bar w-20">
                                <div
                                  className={`confidence-fill ${isHigh ? "confidence-fill-high" : isMed ? "confidence-fill-medium" : "confidence-fill-low"}`}
                                  style={{ width: `${conf * 100}%` }}
                                />
                              </div>
                              <span className={`text-[10px] font-bold ${isHigh ? "text-emerald-700" : isMed ? "text-amber-700" : "text-rose-700"}`}>
                                {(conf * 100).toFixed(0)}%
                              </span>
                            </div>
                          </td>
                          <td className="px-5 py-3.5">
                            {d.officer_confirmed ? (
                              <span className="badge-compliant">
                                <CheckCircle2 className="w-3 h-3" /> Verified
                              </span>
                            ) : (
                              <span className="text-[11px] text-slate-400 font-medium">AI Transcription</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Compliance findings table */}
          {findings.length > 0 && (
            <div className="premium-card overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-100 flex items-center gap-2">
                <Scale className="w-4 h-4 text-violet-600" />
                <h3 className="text-sm font-black text-slate-900">Statutory Rule Compliance Findings</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-100">
                    <tr>
                      {["Legal Citation", "Requirement", "Compliance State", "Violation Details"].map((h) => (
                        <th key={h} className="px-5 py-3 text-[10px] font-black text-slate-500 uppercase tracking-wider">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {findings.map((f, i) => (
                      <tr key={f.id} className={`hover:bg-slate-50/50 transition-colors stagger-${Math.min(i + 1, 8)}`}>
                        <td className="px-5 py-4">
                          <p className="font-black text-slate-900 font-mono">{f.legal_reference || f.rule_key}</p>
                        </td>
                        <td className="px-5 py-4 text-slate-600 max-w-xs">{f.requirement}</td>
                        <td className="px-5 py-4">
                          <StatusPill status={f.result} />
                        </td>
                        <td className="px-5 py-4">
                          {f.violations && f.violations.length > 0 ? (
                            <div className="space-y-1">
                              {f.violations.map((v, vi) => (
                                <p key={vi} className="text-rose-600 font-semibold text-[11px] flex items-center gap-1">
                                  <XCircle className="w-3 h-3 shrink-0" /> {v.description}
                                </p>
                              ))}
                            </div>
                          ) : (
                            <span className="text-slate-300">—</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Certificate footer */}
          <div className="premium-card p-6 print:border print:border-slate-300">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 text-xs text-slate-600">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-indigo-700 font-bold">
                  <Shield className="w-4 h-4" />
                  Tamper-Proof Audit Provenance
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  This report is electronically generated under Section 16 of the Legal Metrology (Packaged Commodities) Rules, 2011.
                  Evidence images and OCR traces are cryptographically anchored to the inspection record.
                  Report ID: <span className="font-mono text-indigo-600">#{id.slice(0, 8).toUpperCase()}</span>
                </p>
              </div>

              <div className="text-right space-y-4">
                <div className="inline-block border-b-2 border-slate-800 w-48 text-center pb-2">
                  <p className="text-slate-800 font-bold text-sm">
                    {inspection ? `Officer · ${inspection.officer_id?.slice(0, 6)}` : "Enforcement Officer"}
                  </p>
                </div>
                <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest">
                  Signature of Inspecting Officer
                </p>
                <p className="text-[10px] text-slate-400 font-mono">
                  Seal: {dateStr}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      <AICopilotDrawer inspectionId={id} productName={inspection?.product_name} />
    </div>
  );
}
