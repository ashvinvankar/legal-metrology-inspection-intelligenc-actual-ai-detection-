"use client";

import React, { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { StatusPill } from "@/components/compliance/StatusPill";
import {
  CheckCircle2,
  RefreshCw,
  FileText,
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  ShieldAlert,
  Loader2,
  Check,
} from "lucide-react";
import { getInspection, getComplianceFindings, reviewComplianceFinding } from "@/lib/api";
import { AICopilotDrawer } from "@/components/copilot/AICopilotDrawer";
import type { Inspection, ComplianceFindingAPI } from "@/types";

export default function OfficerReviewPage() {
  const params = useParams();
  const router = useRouter();
  const id = params.id as string;

  const [inspection, setInspection] = useState<Inspection | null>(null);
  const [findings, setFindings] = useState<ComplianceFindingAPI[]>([]);
  const [loading, setLoading] = useState(true);

  // Per-finding override form state
  const [overrideActive, setOverrideActive] = useState<Record<string, boolean>>({});
  const [justifications, setJustifications] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState<Record<string, boolean>>({});

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [insp, fnd] = await Promise.all([
        getInspection(id),
        getComplianceFindings(id),
      ]);
      setInspection(insp);
      setFindings(fnd);
    } catch {
      // Fallback
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleConfirm = async (findingId: string) => {
    setSubmitting((prev) => ({ ...prev, [findingId]: true }));
    try {
      const updated = await reviewComplianceFinding(findingId, "confirmed");
      setFindings((prev) => prev.map((f) => (f.id === updated.id ? updated : f)));
    } catch {
      alert("Failed to record confirmation.");
    } finally {
      setSubmitting((prev) => ({ ...prev, [findingId]: false }));
    }
  };

  const handleOverride = async (findingId: string) => {
    const text = justifications[findingId]?.trim();
    if (!text) {
      alert("Please provide a mandatory justification for overriding an AI finding.");
      return;
    }
    setSubmitting((prev) => ({ ...prev, [findingId]: true }));
    try {
      const updated = await reviewComplianceFinding(findingId, "overridden", text);
      setFindings((prev) => prev.map((f) => (f.id === updated.id ? updated : f)));
      setOverrideActive((prev) => ({ ...prev, [findingId]: false }));
    } catch {
      alert("Failed to submit override.");
    } finally {
      setSubmitting((prev) => ({ ...prev, [findingId]: false }));
    }
  };

  const pendingReviews = findings.filter(
    (f) => (f.result === "NON_COMPLIANT" || f.result === "NEEDS_REVIEW") && !f.officer_decision
  );

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-16">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Link
            href={`/inspections/${id}/compliance`}
            className="p-2 border border-slate-200 rounded-xl bg-white hover:bg-slate-50 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-slate-600" />
          </Link>
          <div>
            <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
              Officer Verification &amp; Sign-off
            </h2>
            <p className="text-xs text-slate-500">
              Human-in-the-loop review. Confirm AI findings or provide audited overrides (PRD Section 12 &amp; 16)
            </p>
          </div>
        </div>

        <Link
          href={`/inspections/${id}/report`}
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl shadow-sm"
        >
          Proceed to Report <ArrowRight className="w-4 h-4" />
        </Link>
      </div>

      {/* Overview Card */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm flex items-center justify-between">
        <div>
          <h3 className="text-sm font-bold text-slate-900">
            {inspection?.product_name || "Packaged Good Inspection"}
          </h3>
          <p className="text-xs text-slate-500">
            {pendingReviews.length === 0
              ? "All findings reviewed and signed off by inspecting officer."
              : `${pendingReviews.length} statutory finding(s) pending officer confirmation.`}
          </p>
        </div>
        <div>
          {pendingReviews.length === 0 ? (
            <span className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-100 border border-emerald-300 text-emerald-800 rounded-full text-xs font-bold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" /> All Signed Off
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 px-3 py-1 bg-amber-100 border border-amber-300 text-amber-800 rounded-full text-xs font-bold">
              <AlertTriangle className="w-4 h-4 text-amber-600" /> Review Required
            </span>
          )}
        </div>
      </div>

      {/* Review List */}
      <div className="space-y-4">
        {findings.map((f) => {
          const isPending = !f.officer_decision;
          const isOverriding = overrideActive[f.id] || false;
          const isBusy = submitting[f.id] || false;

          return (
            <div
              key={f.id}
              className={`bg-white border rounded-2xl p-6 shadow-sm space-y-4 transition-all ${
                f.officer_decision === "confirmed"
                  ? "border-emerald-200 bg-emerald-50/10"
                  : f.officer_decision === "overridden"
                  ? "border-amber-200 bg-amber-50/10"
                  : "border-slate-200"
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-slate-900">
                      {f.legal_reference || f.rule_key}
                    </h4>
                    <StatusPill status={f.result} />
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5">{f.requirement}</p>
                </div>

                <div className="flex items-center gap-2">
                  {f.officer_decision ? (
                    <span
                      className={`inline-flex items-center gap-1 px-3 py-1 rounded-xl text-xs font-bold ${
                        f.officer_decision === "confirmed"
                          ? "bg-emerald-100 text-emerald-800"
                          : "bg-amber-100 text-amber-800"
                      }`}
                    >
                      <Check className="w-3.5 h-3.5" />
                      Officer {f.officer_decision === "confirmed" ? "Confirmed" : "Overridden"}
                    </span>
                  ) : (
                    <>
                      <button
                        onClick={() => handleConfirm(f.id)}
                        disabled={isBusy}
                        className="px-3.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors"
                      >
                        {isBusy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                        Confirm Finding
                      </button>
                      <button
                        onClick={() =>
                          setOverrideActive((prev) => ({ ...prev, [f.id]: !isOverriding }))
                        }
                        disabled={isBusy}
                        className="px-3.5 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        Override
                      </button>
                    </>
                  )}
                </div>
              </div>

              {/* Violations listing */}
              {f.violations && f.violations.length > 0 && (
                <div className="p-3 bg-rose-50/70 border border-rose-100 rounded-xl text-xs text-rose-800 space-y-1">
                  <p className="font-bold text-[11px] uppercase tracking-wide">Identified Violation:</p>
                  {f.violations.map((v) => (
                    <p key={v.id}>• {v.description}</p>
                  ))}
                </div>
              )}

              {/* Override Form */}
              {isOverriding && (
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-3 text-xs">
                  <div className="flex items-center gap-2 text-amber-900 font-bold">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    <span>Mandatory Override Justification (Immutably Logged in Audit Trail)</span>
                  </div>
                  <textarea
                    rows={2}
                    value={justifications[f.id] || ""}
                    onChange={(e) =>
                      setJustifications((prev) => ({ ...prev, [f.id]: e.target.value }))
                    }
                    placeholder="Provide specific legal or physical evidence justification for overriding this AI finding..."
                    className="w-full p-2.5 bg-white border border-amber-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500 font-sans text-xs"
                  />
                  <div className="flex justify-end gap-2">
                    <button
                      onClick={() =>
                        setOverrideActive((prev) => ({ ...prev, [f.id]: false }))
                      }
                      className="px-3 py-1.5 text-slate-600 text-xs font-semibold rounded-lg"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => handleOverride(f.id)}
                      disabled={isBusy}
                      className="px-4 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold rounded-lg shadow-sm"
                    >
                      Submit Audited Override
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Embedded Floating AI Copilot */}
      <AICopilotDrawer
        inspectionId={id}
        productName={inspection?.product_name}
      />
    </div>
  );
}
