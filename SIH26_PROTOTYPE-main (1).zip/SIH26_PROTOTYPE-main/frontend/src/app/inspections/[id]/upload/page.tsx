"use client";

import React, { useState, useEffect, useCallback } from "react";
import { useRouter, useParams } from "next/navigation";
import Link from "next/link";
import {
  UploadCloud,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  Zap,
  Loader2,
  Image as ImageIcon,
  Sparkles,
  Info,
} from "lucide-react";
import {
  uploadInspectionImage,
  listInspectionImages,
  runFastAIInspection,
  triggerAnalysis,
  getInspection,
} from "@/lib/api";
import { ImageUploadSlot } from "@/components/inspections/ImageUploadSlot";
import { AICopilotDrawer } from "@/components/copilot/AICopilotDrawer";
import { InspectionStepper } from "@/components/layout/InspectionStepper";
import type { ImageUploadResponse, Inspection } from "@/types";

export default function ImageUploadPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;

  const [inspection, setInspection] = useState<Inspection | null>(null);
  const [existingImages, setExistingImages] = useState<ImageUploadResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [fastInspecting, setFastInspecting] = useState(false);
  const [asyncStarting, setAsyncStarting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const fetchInitialData = useCallback(async () => {
    setLoading(true);
    try {
      const [insp, imgs] = await Promise.all([
        getInspection(id),
        listInspectionImages(id),
      ]);
      setInspection(insp);
      setExistingImages(imgs);
    } catch {
      setErrorMessage("Could not load inspection details.");
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchInitialData();
  }, [fetchInitialData]);

  const handleUploadStart = async (
    imageType: "front" | "back" | "label",
    file: File,
    onProgress: (progress: number) => void
  ) => {
    const uploaded = await uploadInspectionImage(id, imageType, file, onProgress);
    setExistingImages((prev) => [...prev.filter((img) => img.image_type !== imageType), uploaded]);
    return uploaded;
  };

  const handleRunFastAI = async () => {
    if (existingImages.length === 0) {
      alert("Please upload at least one packaging image before starting analysis.");
      return;
    }
    setFastInspecting(true);
    setErrorMessage(null);
    try {
      await runFastAIInspection(id);
      router.push(`/inspections/${id}/progress`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Fast AI inspection failed.";
      setErrorMessage(msg);
      setFastInspecting(false);
    }
  };

  const handleRunStandardAsync = async () => {
    if (existingImages.length === 0) {
      alert("Please upload at least one packaging image before starting analysis.");
      return;
    }
    setAsyncStarting(true);
    setErrorMessage(null);
    try {
      await triggerAnalysis(id);
      router.push(`/inspections/${id}/progress`);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed to queue analysis.";
      setErrorMessage(msg);
      setAsyncStarting(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6 pb-12 px-4">
      <InspectionStepper inspectionId={id} />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 animate-fade-in-up">
        <div className="flex items-center gap-3">
          <Link
            href="/inspections"
            className="p-2 border border-slate-200 rounded-xl bg-white hover:bg-slate-50 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-slate-600" />
          </Link>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-slate-900 tracking-tight">
                Upload Evidence
              </h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 border border-indigo-200 uppercase tracking-widest">
                Rule 8 & 9
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              Capture orthogonal, high-resolution photos of all packaging panels
            </p>
          </div>
        </div>

        {inspection && (
          <div className="text-right hidden sm:block">
            <p className="text-xs font-black text-slate-800">{inspection.product_name || "Packaged Good"}</p>
            <p className="text-[10px] font-mono text-slate-400">ID: {id.slice(0, 8).toUpperCase()}</p>
          </div>
        )}
      </div>

      {errorMessage && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-800 flex items-center gap-2 animate-fade-in-up">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
          <span className="font-semibold">{errorMessage}</span>
        </div>
      )}

      {/* Guidelines Alert */}
      <div className="bg-indigo-50/50 border border-indigo-200/60 rounded-2xl p-4 text-xs flex items-start gap-3 animate-fade-in-up">
        <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center shrink-0 mt-0.5">
          <Info className="w-4 h-4 text-indigo-600" />
        </div>
        <div className="space-y-1 text-indigo-900">
          <p className="font-black text-sm">Metrology Photography Guidelines</p>
          <ul className="list-disc pl-4 space-y-0.5 text-indigo-700/80 font-medium">
            <li>Ensure the **MRP & Net Quantity** stamps are clearly legible without glare.</li>
            <li>For cylindrical packaging (bottles), ensure all text is visible in a single frame or take multiple angles.</li>
            <li>Use the highest resolution available; AI will automatically correct skew and blur.</li>
          </ul>
        </div>
      </div>

      {/* Upload Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {[
          { type: "front", label: "Front Panel (Principal Display)" },
          { type: "label", label: "Rear Panel (Declarations)" },
          { type: "back", label: "Side Panel (Nutritional / extra)" },
        ].map((slot, i) => (
          <div key={slot.type} className={`stagger-${i + 1}`}>
            <ImageUploadSlot
              label={slot.label}
              imageType={slot.type as any}
              onUploadStart={(file, onProgress) => handleUploadStart(slot.type as "front" | "back" | "label", file, onProgress)}
              onUploadComplete={() => {}}
              // We pass existing image if any, to the slot so it can show the preview natively
              initialImageUri={existingImages.find(img => img.image_type === slot.type)?.original_uri}
            />
          </div>
        ))}
      </div>

      {/* Action Bar */}
      <div className="premium-card p-6 flex flex-col sm:flex-row items-center justify-between gap-5 animate-fade-in-scale">
        <div className="flex items-center gap-3">
          <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-colors ${existingImages.length > 0 ? "bg-emerald-100 text-emerald-600" : "bg-slate-100 text-slate-400"}`}>
            {existingImages.length > 0 ? <CheckCircle2 className="w-6 h-6" /> : <UploadCloud className="w-6 h-6" />}
          </div>
          <div>
            <h4 className="text-sm font-black text-slate-900">
              {existingImages.length > 0 ? "Evidence Ready" : "Awaiting Evidence"}
            </h4>
            <p className="text-[11px] text-slate-500 font-medium mt-0.5">
              {existingImages.length} of 3 recommended panels uploaded
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3 w-full sm:w-auto">
          <button
            onClick={handleRunStandardAsync}
            disabled={asyncStarting || fastInspecting || existingImages.length === 0}
            className="flex-1 sm:flex-initial btn-ghost h-11"
          >
            {asyncStarting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
            Background Queue
          </button>

          <button
            onClick={handleRunFastAI}
            disabled={fastInspecting || asyncStarting || existingImages.length === 0}
            className="flex-1 sm:flex-initial btn-primary h-11 text-sm px-6 shadow-lg shadow-indigo-500/25 relative overflow-hidden group"
          >
            {/* Shimmer effect */}
            <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-[150%] group-hover:animate-[shimmer_1.5s_infinite]" />

            {fastInspecting ? (
              <Loader2 className="w-4 h-4 animate-spin relative z-10" />
            ) : (
              <Sparkles className="w-4 h-4 text-amber-300 relative z-10" />
            )}
            <span className="relative z-10">Start AI Pipeline</span>
          </button>
        </div>
      </div>

      <AICopilotDrawer inspectionId={id} productName={inspection?.product_name} />
    </div>
  );
}
