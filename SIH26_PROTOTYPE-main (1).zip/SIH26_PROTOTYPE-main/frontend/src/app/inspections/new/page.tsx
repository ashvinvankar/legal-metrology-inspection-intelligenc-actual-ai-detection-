"use client";

import React, { useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import {
  Package,
  MapPin,
  Tag,
  ArrowRight,
  CheckCircle2,
  Loader2,
  ChevronRight,
  Zap,
} from "lucide-react";
import { ImageUploadSlot } from "@/components/inspections/ImageUploadSlot";
import { ErrorBanner } from "@/components/ui/ErrorBanner";
import {
  createInspection,
  uploadInspectionImage,
  updateInspectionStatus,
  triggerAnalysis,
} from "@/lib/api";
import type { ImageUploadResponse } from "@/types";

type Step = "metadata" | "upload";

interface SlotState {
  result: ImageUploadResponse | null;
}

const SLOT_CONFIGS: Array<{
  key: "front" | "back" | "label";
  label: string;
  hint: string;
}> = [
  { key: "front", label: "Front of Package", hint: "Main face of the product" },
  { key: "back", label: "Back of Package", hint: "Reverse side declarations" },
  {
    key: "label",
    label: "Declaration Label",
    hint: "Close-up of all mandatory declarations (Required)",
  },
];

export default function NewInspectionPage() {
  const router = useRouter();

  // ── Step 1: Metadata ─────────────────────────────────────────────
  const [step, setStep] = useState<Step>("metadata");
  const [productName, setProductName] = useState("");
  const [category, setCategory] = useState("Packaged Food");
  const [location, setLocation] = useState("");
  const [metaLoading, setMetaLoading] = useState(false);
  const [metaError, setMetaError] = useState<string | null>(null);

  // ── Step 2: Upload ────────────────────────────────────────────────
  const [inspectionId, setInspectionId] = useState<string | null>(null);
  const [slots, setSlots] = useState<Record<string, SlotState>>({
    front: { result: null },
    back: { result: null },
    label: { result: null },
  });
  const [finalizing, setFinalizing] = useState(false);
  const [finalizeError, setFinalizeError] = useState<string | null>(null);
  const [pipelineStatus, setPipelineStatus] = useState<string | null>(null);

  // ── Step 1 submit ─────────────────────────────────────────────────
  const handleMetaSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setMetaLoading(true);
    setMetaError(null);
    try {
      const inspection = await createInspection({
        product_name: productName,
        category,
        location: location || undefined,
      });
      setInspectionId(inspection.id);
      setStep("upload");
    } catch {
      setMetaError(
        "Failed to create inspection record. Ensure the backend is running."
      );
    } finally {
      setMetaLoading(false);
    }
  };

  // ── Upload helpers ────────────────────────────────────────────────
  const handleUploadStart = useCallback(
    (imageType: "front" | "back" | "label") =>
      async (file: File, onProgress: (progress: number) => void): Promise<ImageUploadResponse> => {
        if (!inspectionId) throw new Error("Inspection ID missing.");
        return uploadInspectionImage(inspectionId, imageType, file, onProgress);
      },
    [inspectionId]
  );

  const handleUploadComplete = useCallback(
    (imageType: string) => (result: ImageUploadResponse) => {
      setSlots((prev) => ({
        ...prev,
        [imageType]: { result },
      }));
    },
    []
  );

  // Label slot must pass quality gate to enable analysis
  const labelResult = slots["label"].result;
  const labelQualityPassed = labelResult?.quality_issues?.passed ?? false;
  const canRunAnalysis = labelQualityPassed;

  // ── Finalize: set status → trigger Celery pipeline → navigate ─────
  const handleRunAnalysis = async () => {
    if (!inspectionId) return;
    setFinalizing(true);
    setFinalizeError(null);
    setPipelineStatus("Updating inspection status…");
    try {
      // Step A: mark as analyzing in DB
      await updateInspectionStatus(inspectionId, "analyzing");

      // Step B: enqueue Celery task
      setPipelineStatus("Queuing AI CV/OCR pipeline on worker…");
      const taskResult = await triggerAnalysis(inspectionId);
      setPipelineStatus(
        `Pipeline queued — Task ID: ${taskResult.task_id.slice(0, 8)}…`
      );

      // Brief pause so the user can see the status, then navigate
      await new Promise((res) => setTimeout(res, 800));
      router.push(`/inspections/${inspectionId}/compliance`);
    } catch {
      setFinalizeError(
        "Could not queue the AI pipeline. Ensure the Celery worker is running."
      );
      setFinalizing(false);
      setPipelineStatus(null);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* ── Page header ──────────────────────────────────────────── */}
      <div>
        <h2 className="text-xl font-bold text-slate-900">
          Initiate New Inspection
        </h2>
        <p className="text-xs text-slate-500">
          Enter commodity metadata and upload label images for AI analysis
        </p>
      </div>

      {/* ── Step indicator ───────────────────────────────────────── */}
      <div className="flex items-center gap-2 text-xs font-semibold">
        <span
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border ${
            step === "metadata"
              ? "bg-indigo-600 text-white border-indigo-600"
              : "bg-emerald-50 text-emerald-700 border-emerald-300"
          }`}
        >
          {step === "upload" ? (
            <CheckCircle2 className="w-3.5 h-3.5" />
          ) : (
            <span className="w-4 h-4 flex items-center justify-center rounded-full bg-white/30 text-[10px]">
              1
            </span>
          )}
          Inspection Metadata
        </span>
        <ChevronRight className="w-4 h-4 text-slate-400" />
        <span
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full border ${
            step === "upload"
              ? "bg-indigo-600 text-white border-indigo-600"
              : "bg-slate-100 text-slate-400 border-slate-200"
          }`}
        >
          <span className="w-4 h-4 flex items-center justify-center rounded-full bg-white/30 text-[10px]">
            2
          </span>
          Image Upload &amp; Quality Gate
        </span>
      </div>

      {/* ══════════════════════════════════════════════════════════ */}
      {/*  STEP 1 — Metadata Form                                   */}
      {/* ══════════════════════════════════════════════════════════ */}
      {step === "metadata" && (
        <form
          onSubmit={handleMetaSubmit}
          className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4"
        >
          {metaError && <ErrorBanner message={metaError} />}

          {/* Product Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Product / Commodity Name{" "}
              <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <Package className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                id="product-name"
                type="text"
                value={productName}
                onChange={(e) => setProductName(e.target.value)}
                placeholder="e.g. Crisp Delight Biscuits 200g"
                className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                required
              />
            </div>
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Commodity Category
            </label>
            <div className="relative">
              <Tag className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <select
                id="category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none bg-white"
              >
                <option value="Packaged Food">Packaged Food</option>
                <option value="Cosmetics & Personal Care">
                  Cosmetics &amp; Personal Care
                </option>
                <option value="Electronics & Appliances">
                  Electronics &amp; Appliances
                </option>
                <option value="Household Commodities">
                  Household Commodities
                </option>
              </select>
            </div>
          </div>

          {/* Location */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Inspection Location / Retailer
            </label>
            <div className="relative">
              <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                id="location"
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g. Sector 18 Wholesale Mart, Noida"
                className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="pt-2 flex justify-end">
            <button
              id="continue-to-upload"
              type="submit"
              disabled={metaLoading}
              className="inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white text-xs font-semibold rounded-lg shadow transition-colors"
            >
              {metaLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
                  Creating…
                </>
              ) : (
                <>
                  Continue to Image Upload{" "}
                  <ArrowRight className="w-4 h-4 ml-1.5" />
                </>
              )}
            </button>
          </div>
        </form>
      )}

      {/* ══════════════════════════════════════════════════════════ */}
      {/*  STEP 2 — Image Upload                                    */}
      {/* ══════════════════════════════════════════════════════════ */}
      {step === "upload" && inspectionId && (
        <div className="space-y-5">
          {/* Inspection ID badge */}
          <div className="flex items-center gap-2 text-xs text-slate-500 bg-slate-100 px-3 py-2 rounded-lg">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            Inspection created:{" "}
            <span className="font-mono font-bold text-slate-700">
              {inspectionId}
            </span>
          </div>

          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-6">
            <div>
              <h3 className="text-sm font-bold text-slate-800">
                Upload Product &amp; Label Images
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Capture front, back, and a close-up declaration panel. The label
                image is required to proceed.
              </p>
            </div>

            {/* Three upload slots */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
              {SLOT_CONFIGS.map(({ key, label }) => (
                <ImageUploadSlot
                  key={key}
                  label={label}
                  imageType={key}
                  onUploadStart={handleUploadStart(key)}
                  onUploadComplete={handleUploadComplete(key)}
                />
              ))}
            </div>

            {/* Hint about required slot */}
            {!canRunAnalysis && (
              <p className="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
                Upload the <strong>Declaration Label</strong> image and ensure
                it passes the quality gate before proceeding.
              </p>
            )}
          </div>

          {finalizeError && <ErrorBanner message={finalizeError} />}

          {/* Pipeline status indicator */}
          {pipelineStatus && (
            <div className="flex items-center gap-2 text-xs text-indigo-700 bg-indigo-50 border border-indigo-200 rounded-lg px-3 py-2">
              <Loader2 className="w-3.5 h-3.5 animate-spin shrink-0" />
              {pipelineStatus}
            </div>
          )}

          <div className="flex justify-between items-center">
            <button
              type="button"
              onClick={() => setStep("metadata")}
              className="text-xs text-slate-500 hover:text-slate-800 font-medium"
            >
              ← Back to Metadata
            </button>
            <button
              id="run-analysis-btn"
              type="button"
              disabled={!canRunAnalysis || finalizing}
              onClick={handleRunAnalysis}
              className="inline-flex items-center px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-300 disabled:text-slate-500 text-white text-xs font-semibold rounded-lg shadow transition-colors"
            >
              {finalizing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-1.5 animate-spin" />
                  Queuing Pipeline…
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-1.5" />
                  Run AI CV/OCR Pipeline{" "}
                  <ArrowRight className="w-4 h-4 ml-1.5" />
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
