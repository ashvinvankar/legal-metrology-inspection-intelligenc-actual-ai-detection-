"use client";

import React, { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { Search, Filter, Plus } from "lucide-react";
import { StatusPill } from "@/components/compliance/StatusPill";
import { SkeletonRow } from "@/components/ui/SkeletonRow";
import { ErrorBanner } from "@/components/ui/ErrorBanner";
import { listInspections } from "@/lib/api";
import type { Inspection } from "@/types";

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  } catch {
    return iso;
  }
}

export default function InspectionRepositoryPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [inspections, setInspections] = useState<Inspection[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchInspections = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await listInspections();
      setInspections(data);
    } catch {
      setError("Could not load inspections from the server.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchInspections();
  }, [fetchInspections]);

  // Client-side search filter across product name, category, status
  const filtered = inspections.filter((insp) => {
    if (!searchTerm.trim()) return true;
    const q = searchTerm.toLowerCase();
    return (
      insp.product_name?.toLowerCase().includes(q) ||
      insp.category?.toLowerCase().includes(q) ||
      insp.id?.toLowerCase().includes(q) ||
      insp.location?.toLowerCase().includes(q) ||
      insp.status?.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-slate-900">
            Inspection Repository
          </h2>
          <p className="text-xs text-slate-500">
            Searchable repository across products, manufacturers, violations
            (PRD Section 14)
          </p>
        </div>
        <Link
          href="/inspections/new"
          className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs rounded-lg shadow transition-colors"
        >
          <Plus className="w-3.5 h-3.5" />
          New Inspection
        </Link>
      </div>

      {error && <ErrorBanner message={error} onRetry={fetchInspections} />}

      {/* Search & Filters */}
      <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-sm flex gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by product name, ID, location, category, status…"
            className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
        <button className="px-3 py-2 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 flex items-center hover:bg-slate-50 transition-colors">
          <Filter className="w-3.5 h-3.5 mr-1.5" /> Filters
        </button>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase">
            <tr>
              <th className="px-4 py-3">Inspection ID</th>
              <th className="px-4 py-3">Product Name</th>
              <th className="px-4 py-3">Category</th>
              <th className="px-4 py-3">Location</th>
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3">Result</th>
              <th className="px-4 py-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {loading &&
              Array.from({ length: 4 }).map((_, i) => (
                <SkeletonRow key={i} cols={7} />
              ))}

            {!loading && filtered.length === 0 && (
              <tr>
                <td
                  colSpan={7}
                  className="px-4 py-10 text-center text-xs text-slate-400"
                >
                  {inspections.length === 0
                    ? "No inspections found. Start by initiating a new inspection."
                    : "No inspections match your search."}
                </td>
              </tr>
            )}

            {!loading &&
              filtered.map((insp) => (
                <tr key={insp.id} className="hover:bg-slate-50/60">
                  <td className="px-4 py-3 font-mono font-semibold text-indigo-700 text-[11px]">
                    {insp.id.slice(0, 8).toUpperCase()}…
                  </td>
                  <td className="px-4 py-3 font-medium text-slate-800">
                    {insp.product_name ?? (
                      <span className="text-slate-400 italic">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-slate-600">{insp.category}</td>
                  <td className="px-4 py-3 text-slate-500">
                    {insp.location ?? (
                      <span className="text-slate-300">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-slate-500">
                    {formatDate(insp.inspection_date)}
                  </td>
                  <td className="px-4 py-3">
                    {insp.overall_result ? (
                      <StatusPill status={insp.overall_result} />
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-1 rounded-full text-[10px] font-semibold bg-slate-100 text-slate-500 border border-slate-200">
                        {insp.status.toUpperCase()}
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <Link
                      href={`/inspections/${insp.id}/compliance`}
                      className="text-indigo-600 hover:text-indigo-800 font-semibold"
                    >
                      View Report →
                    </Link>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
