import type { Metadata } from "next";
import "./globals.css";
import { AuthProvider } from "@/contexts/AuthContext";
import { ClientLayoutShell } from "@/components/layout/ClientLayoutShell";

export const metadata: Metadata = {
  title: "NeuraCheck | Packaged Commodity Compliance",
  description:
    "Evidence-led packaged commodity compliance inspection for SIH Problem Statement 26034.",
  icons: {
    icon: "/brand/neuracheck-logo.jpeg",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="antialiased min-h-screen">
        <AuthProvider>
          <ClientLayoutShell>{children}</ClientLayoutShell>
        </AuthProvider>
      </body>
    </html>
  );
}
