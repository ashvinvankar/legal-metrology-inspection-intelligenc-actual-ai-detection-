"use client";

import React, { useState } from "react";
import { Lock, User, Loader2, AlertCircle } from "lucide-react";
import Link from "next/link";
import { useAuth } from "@/contexts/AuthContext";

export default function LoginPage() {
  const { login, loginError } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    try {
      await login(username, password);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="app-panel max-w-md w-full mx-4 overflow-hidden">
      <div className="flex justify-center bg-[#071214] py-6">
        <img src="/brand/neuracheck-logo.jpeg" alt="NeuraCheck" className="h-36 w-36 object-contain" />
      </div>
      <div className="p-8">
      <div className="text-center mb-6">
        <h1 className="text-xl font-bold text-slate-900">Secure inspection access</h1>
        <p className="text-xs text-slate-500 mt-0.5">
          NeuraCheck · Legal Metrology compliance workspace
        </p>
      </div>

      {/* Backend error banner */}
      {loginError && (
        <div className="mb-4 flex items-start gap-2.5 bg-rose-50 border border-rose-200 rounded-lg px-3 py-2.5 text-xs text-rose-700">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{loginError}</span>
        </div>
      )}

      <form onSubmit={handleLogin} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Government ID / Username
          </label>
          <div className="relative">
            <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="e.g. officer.sharma"
              className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
              autoComplete="username"
              disabled={isLoading}
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Password
          </label>
          <div className="relative">
            <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full pl-9 pr-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              required
              autoComplete="current-password"
              disabled={isLoading}
            />
          </div>
        </div>

        <button
          id="login-submit"
          type="submit"
          disabled={isLoading}
          className="w-full py-2.5 px-4 bg-teal-700 hover:bg-teal-800 disabled:bg-teal-400 text-white font-semibold rounded-lg text-sm transition-colors shadow inline-flex items-center justify-center gap-2"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              Authenticating…
            </>
          ) : (
            "Authenticate & Proceed"
          )}
        </button>
      </form>

        <p className="mt-5 flex items-center justify-center gap-1 text-xs text-slate-500">
          Don't have an account? 
          <Link href="/register" className="font-semibold text-teal-700 hover:text-teal-800 transition-colors">
            Register here
          </Link>
        </p>

        <p className="mt-5 text-[11px] text-center text-slate-400">
          NeuraCheck · SIH-26034 · All access is logged and audited
        </p>
      </div>
    </div>
  );
}
