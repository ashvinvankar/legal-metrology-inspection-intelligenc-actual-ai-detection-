import Link from "next/link";
import { ArrowRight, CheckCircle2, FileSearch, ScanLine, ShieldCheck } from "lucide-react";
import type { LucideIcon } from "lucide-react";

const CAPABILITIES: Array<{ icon: LucideIcon; title: string; text: string }> = [
  { icon: ScanLine, title: "Scan & extract", text: "Capture a package label and route it through the existing OCR pipeline." },
  { icon: FileSearch, title: "Review with evidence", text: "Inspect the original image, detected fields, confidence, and available regions." },
  { icon: CheckCircle2, title: "Validate decisively", text: "See compliant, non-compliant, and review-needed findings from the rules engine." },
];

export default function HomePage() {
  return (
    <div className="py-10 sm:py-16 px-4 max-w-6xl mx-auto">
      <section className="app-panel overflow-hidden">
        <div className="grid lg:grid-cols-[1.1fr_.9fr]">
          <div className="p-8 sm:p-12">
            <span className="inline-flex items-center gap-2 rounded-full border border-teal-200 bg-teal-50 px-3 py-1 text-xs font-bold text-teal-800">
              <ShieldCheck className="h-3.5 w-3.5" /> Legal Metrology · SIH 26034
            </span>
            <h1 className="mt-5 max-w-xl text-4xl font-bold tracking-tight text-slate-950 sm:text-5xl">
              Evidence-led label compliance, made clear.
            </h1>
            <p className="mt-5 max-w-xl text-base leading-7 text-slate-600">
              NeuraCheck helps inspectors scan packaged commodities, extract declared information, and review rule-engine findings alongside their source evidence.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
          <Link
            href="/inspections/new"
            className="btn-primary text-sm"
          >
            Scan product <ArrowRight className="h-4 w-4" />
          </Link>
          <Link
            href="/inspections"
            className="btn-ghost text-sm"
          >
            View scan history
          </Link>
            </div>
          </div>
          <div className="flex min-h-[330px] items-center justify-center bg-[#071214] p-8">
            <img src="/brand/neuracheck-logo.jpeg" alt="NeuraCheck" className="h-64 w-64 max-w-full object-contain" />
          </div>
        </div>
      </section>
      <section className="mt-6 grid gap-4 md:grid-cols-3">
        {CAPABILITIES.map(({ icon: Icon, title, text }) => {
          return <article key={title} className="app-panel p-5"><Icon className="h-5 w-5 text-teal-700" /><h2 className="mt-4 font-bold text-slate-900">{title}</h2><p className="mt-2 text-sm leading-6 text-slate-600">{text}</p></article>;
        })}
      </section>
    </div>
  );
}
