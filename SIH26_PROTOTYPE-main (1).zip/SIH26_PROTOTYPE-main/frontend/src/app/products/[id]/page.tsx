"use client";

import React from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { Package, ShieldAlert, History, ArrowLeft } from "lucide-react";
import { StatusPill } from "@/components/compliance/StatusPill";

export default function ProductHistoryPage() {
  const params = useParams();

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <Link href="/dashboard" className="p-2 border border-slate-200 rounded-lg bg-white hover:bg-slate-50">
          <ArrowLeft className="w-4 h-4 text-slate-600" />
        </Link>
        <div>
          <h2 className="text-xl font-bold text-slate-900">Product Enforcement History</h2>
          <p className="text-xs text-slate-500">Cross-inspection history & repeat violation analysis (PRD Section 14)</p>
        </div>
      </div>

      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Package className="w-8 h-8 text-indigo-600" />
            <div>
              <h3 className="text-base font-bold text-slate-800">Apex Crisp Biscuits 200g</h3>
              <p className="text-xs text-slate-500">Manufacturer: Apex Foods Ltd • Category: Packaged Food</p>
            </div>
          </div>
          <span className="px-3 py-1 bg-rose-100 text-rose-800 font-bold text-xs rounded-full border border-rose-200 flex items-center">
            <ShieldAlert className="w-3.5 h-3.5 mr-1" /> Repeat Offender Flagged
          </span>
        </div>

        <div className="mt-6 border-t border-slate-100 pt-4">
          <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Historical Inspection Records</h4>
          <div className="divide-y divide-slate-100 text-xs">
            <div className="py-3 flex items-center justify-between">
              <div>
                <p className="font-semibold text-slate-800">Inspection #INSP-2026-091</p>
                <p className="text-slate-500 text-[11px]">12 Sept 2026 • Officer Sharma • Noida Hub</p>
              </div>
              <StatusPill status="NON_COMPLIANT" />
            </div>
            <div className="py-3 flex items-center justify-between">
              <div>
                <p className="font-semibold text-slate-800">Inspection #INSP-2026-074</p>
                <p className="text-slate-500 text-[11px]">28 Aug 2026 • Officer Verma • Delhi Retail</p>
              </div>
              <StatusPill status="NON_COMPLIANT" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
