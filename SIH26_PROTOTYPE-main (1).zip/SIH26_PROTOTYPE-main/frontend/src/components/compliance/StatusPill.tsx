import React from "react";
import { ComplianceState } from "@/types";
import { CheckCircle2, AlertTriangle, XCircle, HelpCircle } from "lucide-react";

interface StatusPillProps {
  status: ComplianceState;
  showIcon?: boolean;
}

export const StatusPill: React.FC<StatusPillProps> = ({ status, showIcon = true }) => {
  const configs = {
    COMPLIANT: {
      label: "COMPLIANT",
      bg: "bg-emerald-50 border-emerald-300 text-emerald-700",
      icon: <CheckCircle2 className="w-4 h-4 text-emerald-600 mr-1.5" />,
    },
    NON_COMPLIANT: {
      label: "NON-COMPLIANT",
      bg: "bg-rose-50 border-rose-300 text-rose-700",
      icon: <XCircle className="w-4 h-4 text-rose-600 mr-1.5" />,
    },
    NEEDS_REVIEW: {
      label: "NEEDS REVIEW",
      bg: "bg-amber-50 border-amber-300 text-amber-700",
      icon: <AlertTriangle className="w-4 h-4 text-amber-600 mr-1.5" />,
    },
    NOT_APPLICABLE: {
      label: "NOT APPLICABLE",
      bg: "bg-slate-50 border-slate-300 text-slate-600",
      icon: <HelpCircle className="w-4 h-4 text-slate-500 mr-1.5" />,
    },
  };

  const config = configs[status] || configs.NOT_APPLICABLE;

  return (
    <span
      className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold border ${config.bg}`}
    >
      {showIcon && config.icon}
      {config.label}
    </span>
  );
};
