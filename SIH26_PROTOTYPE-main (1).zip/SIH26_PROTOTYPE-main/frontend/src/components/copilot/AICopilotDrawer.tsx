"use client";

import React, { useState, useRef, useEffect } from "react";
import {
  Bot,
  Send,
  X,
  Sparkles,
  Loader2,
  BookOpen,
  Copy,
  Check,
  Maximize2,
  Minimize2,
  Scale,
} from "lucide-react";
import { queryAICopilot } from "@/lib/api";
import type { CopilotChatMessage } from "@/types";

interface AICopilotDrawerProps {
  inspectionId: string;
  productName?: string;
}

const SUGGESTED_PROMPTS = [
  "Explain Rule 6(1)(ea) Country of Origin requirement",
  "Check Unit Sale Price calculation under Rule 6(11)",
  "Draft a formal Show-Cause Notice to the manufacturer",
  "Is this product exempt under Rule 26?",
  "Check FSSAI license format and mandatory font height",
];

export const AICopilotDrawer: React.FC<AICopilotDrawerProps> = ({
  inspectionId,
  productName,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const [messages, setMessages] = useState<CopilotChatMessage[]>([
    {
      id: "welcome",
      sender: "copilot",
      text: `Hello Officer! I am your Legal Metrology AI Copilot (powered by Gemini 3.8 Flash). I have analyzed this product inspection${
        productName ? ` for **${productName}**` : ""
      }. Ask me about mandatory declarations, statutory violations, or penalty provisions under the Legal Metrology Act, 2009 & Packaged Commodities Rules, 2011.`,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      references: [
        "Legal Metrology (Packaged Commodities) Rules, 2011",
        "Legal Metrology Act, 2009 - Section 18",
      ],
    },
  ]);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const handleSend = async (queryText?: string) => {
    const textToSend = (queryText || input).trim();
    if (!textToSend || loading) return;

    const userMsg: CopilotChatMessage = {
      id: Date.now().toString(),
      sender: "user",
      text: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!queryText) setInput("");
    setLoading(true);

    try {
      // Build brief history for multi-turn context
      const history = messages
        .filter((m) => m.id !== "welcome")
        .map((m) => ({
          role: m.sender === "user" ? "user" : "model",
          text: m.text,
        }));

      const res = await queryAICopilot(inspectionId, textToSend, history);

      const copilotMsg: CopilotChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: "copilot",
        text: res.answer,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        references: res.rule_references,
      };

      setMessages((prev) => [...prev, copilotMsg]);
    } catch {
      const errorMsg: CopilotChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: "copilot",
        text: "I apologize, but I encountered an error retrieving the legal analysis. Please ensure the backend is running.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <>
      {/* Floating Trigger Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-40 flex items-center gap-2.5 px-4 py-3 bg-gradient-to-r from-indigo-600 via-indigo-700 to-violet-700 hover:from-indigo-500 hover:to-violet-600 text-white rounded-full shadow-2xl hover:shadow-indigo-500/25 transition-all duration-300 transform hover:-translate-y-0.5 border border-indigo-400/30 group"
          aria-label="Open AI Copilot"
        >
          <div className="relative">
            <Sparkles className="w-5 h-5 animate-pulse text-amber-300" />
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-emerald-400 rounded-full animate-ping" />
          </div>
          <span className="text-xs font-bold tracking-wide">AI Legal Copilot</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-white/20 font-medium">3.8 Flash</span>
        </button>
      )}

      {/* Drawer Overlay & Panel */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex justify-end pointer-events-none">
          {/* Backdrop blur */}
          <div
            onClick={() => setIsOpen(false)}
            className="fixed inset-0 bg-slate-900/30 backdrop-blur-sm pointer-events-auto transition-opacity"
          />

          {/* Drawer Body */}
          <div
            className={`pointer-events-auto relative flex flex-col h-full bg-white border-l border-slate-200 shadow-2xl transition-all duration-300 ease-in-out ${
              isExpanded ? "w-full md:w-[720px]" : "w-full sm:w-[440px]"
            }`}
          >
            {/* Header */}
            <div className="px-5 py-4 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white border-b border-indigo-900/50 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-indigo-600/30 border border-indigo-400/30 flex items-center justify-center text-indigo-300">
                  <Scale className="w-4 h-4 text-indigo-300" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-sm font-bold tracking-tight">Legal Metrology AI Copilot</h3>
                    <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 font-semibold">
                      Gemini 3.8
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400">
                    Grounded in inspection evidence & PC Rules, 2011
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => setIsExpanded(!isExpanded)}
                  className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                  title={isExpanded ? "Collapse width" : "Expand width"}
                >
                  {isExpanded ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
                </button>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                  title="Close Copilot"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Messages Scroll Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex flex-col ${msg.sender === "user" ? "items-end" : "items-start"}`}
                >
                  <div
                    className={`max-w-[90%] rounded-2xl px-4 py-3 text-xs leading-relaxed shadow-sm ${
                      msg.sender === "user"
                        ? "bg-indigo-600 text-white rounded-br-none"
                        : "bg-white text-slate-800 border border-slate-200/80 rounded-bl-none"
                    }`}
                  >
                    {msg.sender === "copilot" && (
                      <div className="flex items-center justify-between mb-1.5 pb-1 border-b border-slate-100">
                        <span className="text-[10px] font-bold text-indigo-600 uppercase tracking-wider flex items-center gap-1">
                          <Bot className="w-3 h-3" /> Legal Assistant
                        </span>
                        <button
                          onClick={() => copyToClipboard(msg.id, msg.text)}
                          className="text-slate-400 hover:text-slate-700 p-0.5 transition-colors"
                          title="Copy response"
                        >
                          {copiedId === msg.id ? (
                            <Check className="w-3 h-3 text-emerald-600" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </div>
                    )}

                    <div className="whitespace-pre-wrap font-sans">{msg.text}</div>

                    {msg.references && msg.references.length > 0 && (
                      <div className="mt-3 pt-2 border-t border-slate-100 space-y-1">
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                          <BookOpen className="w-3 h-3" /> Statutory Citations
                        </p>
                        <div className="flex flex-wrap gap-1">
                          {msg.references.map((ref, idx) => (
                            <span
                              key={idx}
                              className="text-[10px] px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-200 font-medium"
                            >
                              {ref}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                  <span className="text-[10px] text-slate-400 mt-1 px-1">
                    {msg.timestamp}
                  </span>
                </div>
              ))}

              {loading && (
                <div className="flex items-center gap-2 p-3 bg-white border border-slate-200 rounded-2xl max-w-[80%] shadow-sm text-xs text-slate-500">
                  <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
                  <span>AI Copilot is analyzing legal metrology rules…</span>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Suggested Prompts Pill Carousel */}
            <div className="px-4 py-2 border-t border-slate-200 bg-white">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                Quick Inquiries
              </p>
              <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
                {SUGGESTED_PROMPTS.map((prompt, i) => (
                  <button
                    key={i}
                    onClick={() => handleSend(prompt)}
                    disabled={loading}
                    className="shrink-0 text-[11px] px-2.5 py-1 rounded-full bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-600 border border-slate-200 hover:border-indigo-200 transition-colors whitespace-nowrap"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            </div>

            {/* Input Form */}
            <div className="p-3 bg-white border-t border-slate-200">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSend();
                }}
                className="flex items-center gap-2"
              >
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Ask about Rule 6, MRP, USP math, notice draft…"
                  className="flex-1 text-xs px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
                  disabled={loading}
                />
                <button
                  type="submit"
                  disabled={!input.trim() || loading}
                  className="p-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-slate-200 text-white disabled:text-slate-400 rounded-xl transition-colors shadow-sm"
                  aria-label="Send message"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
