import React from "react";

interface BoundingBoxDef {
  bbox: [number, number, number, number]; // normalized [x1, y1, x2, y2]
  label?: string;
  confidence?: number;
  isActive?: boolean;
  color?: string; // tailwind border color class e.g. "border-emerald-500"
}

interface BoundingBoxViewerProps {
  imageUrl: string;
  // Multi-box API (new)
  boxes?: BoundingBoxDef[];
  onBoxClick?: (index: number) => void;
  // Single-box API (legacy, kept for backward compat)
  bbox?: [number, number, number, number];
  label?: string;
  confidence?: number;
}

const DEFAULT_COLOR = "border-emerald-500 bg-emerald-500/20";
const ACTIVE_COLOR = "border-indigo-500 bg-indigo-500/25";
const INACTIVE_COLOR = "border-slate-400 bg-slate-400/10";

export const BoundingBoxViewer: React.FC<BoundingBoxViewerProps> = ({
  imageUrl,
  boxes,
  onBoxClick,
  // legacy single-box props
  bbox,
  label,
  confidence,
}) => {
  // Normalise: support both multi-box and legacy single-box
  const resolvedBoxes: BoundingBoxDef[] =
    boxes && boxes.length > 0
      ? boxes
      : bbox
      ? [{ bbox, label, confidence, isActive: true }]
      : [];

  return (
    <div className="relative border border-slate-200 rounded-lg overflow-hidden bg-slate-900 flex items-center justify-center p-2">
      <div className="relative max-w-full max-h-96">
        <img
          src={imageUrl}
          alt="Evidence Label"
          className="max-h-96 w-auto object-contain rounded"
        />
        {resolvedBoxes.map((box, idx) => {
          const [x1, y1, x2, y2] = box.bbox;
          const colorClass =
            box.isActive === false
              ? INACTIVE_COLOR
              : box.isActive === true
              ? ACTIVE_COLOR
              : DEFAULT_COLOR;

          return (
            <div
              key={idx}
              className={`absolute border-2 rounded pointer-events-none ${colorClass} ${
                onBoxClick ? "cursor-pointer pointer-events-auto" : ""
              }`}
              style={{
                left: `${x1 * 100}%`,
                top: `${y1 * 100}%`,
                width: `${(x2 - x1) * 100}%`,
                height: `${(y2 - y1) * 100}%`,
              }}
              onClick={() => onBoxClick?.(idx)}
            >
              {box.label && (
                <span className="absolute -top-5 left-0 bg-indigo-700 text-white text-[10px] font-bold px-1.5 py-0.5 rounded shadow whitespace-nowrap">
                  {box.label}{" "}
                  {box.confidence
                    ? `(${(box.confidence * 100).toFixed(0)}%)`
                    : ""}
                </span>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
