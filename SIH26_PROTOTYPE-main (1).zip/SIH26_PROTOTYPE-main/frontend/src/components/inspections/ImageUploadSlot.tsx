"use client";

import React, { useRef, useState, useCallback } from "react";
import { UploadCloud, CheckCircle2, XCircle, Loader2, Image as ImageIcon, RotateCcw } from "lucide-react";
import type { ImageUploadResponse } from "@/types";

export type SlotStatus = "idle" | "uploading" | "success" | "error";

interface ImageUploadSlotProps {
  label: string;
  imageType: "front" | "back" | "label";
  onUploadComplete: (result: ImageUploadResponse) => void;
  onUploadStart: (file: File, onProgress: (progress: number) => void) => Promise<ImageUploadResponse>;
  disabled?: boolean;
  initialImageUri?: string;
}

export const ImageUploadSlot: React.FC<ImageUploadSlotProps> = ({
  label,
  imageType,
  onUploadComplete,
  onUploadStart,
  disabled = false,
  initialImageUri,
}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [status, setStatus] = useState<SlotStatus>("idle");
  const [progress, setProgress] = useState(0);
  const [preview, setPreview] = useState<string | null>(() => {
    if (!initialImageUri) return null;
    if (initialImageUri.startsWith("http")) return initialImageUri;
    const base = process.env.NEXT_PUBLIC_API_URL?.replace("/api/v1", "") ?? "http://localhost:8000";
    return `${base}${initialImageUri}`;
  });
  const [qualityResult, setQualityResult] = useState<ImageUploadResponse | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const processFile = useCallback(
    async (file: File) => {
      if (!file.type.startsWith("image/")) {
        setErrorMsg("Please upload a JPEG or PNG image.");
        return;
      }
      if (file.size > 10 * 1024 * 1024) {
        setErrorMsg("Image must be under 10 MB.");
        return;
      }

      // Show local preview immediately
      const objectUrl = URL.createObjectURL(file);
      setPreview(objectUrl);
      setStatus("uploading");
      setProgress(0);
      setErrorMsg(null);

      try {
        const result = await onUploadStart(file, setProgress);
        setQualityResult(result);
        setStatus("success");
        onUploadComplete(result);
      } catch (err: unknown) {
        setStatus("error");
        const message =
          err instanceof Error ? err.message : "Upload failed. Please try again.";
        setErrorMsg(message);
      }
    },
    [onUploadStart, onUploadComplete]
  );

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) processFile(file);
  };

  const qualityPassed = qualityResult?.quality_issues?.passed ?? null;

  return (
    <div className="flex flex-col gap-2">
      {/* Slot label */}
      <p className="text-xs font-semibold text-slate-700 uppercase tracking-wide">
        {label}
        {imageType === "label" && (
          <span className="ml-1 text-rose-500">*</span>
        )}
      </p>

      {/* Drop zone */}
      <div
        className={`relative rounded-xl border-2 transition-colors ${
          isDragging
            ? "border-indigo-400 bg-indigo-50"
            : status === "success" && qualityPassed
            ? "border-emerald-400 bg-emerald-50/50"
            : status === "error" || qualityPassed === false
            ? "border-rose-400 bg-rose-50/50"
            : "border-dashed border-slate-300 bg-white hover:bg-slate-50"
        } ${disabled ? "opacity-50 pointer-events-none" : "cursor-pointer"}`}
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={handleDrop}
      >
        <input
          ref={inputRef}
          type="file"
          accept="image/jpeg,image/png"
          className="hidden"
          onChange={handleFileChange}
          disabled={disabled}
        />

        {preview ? (
          <div className="relative">
            <img
              src={preview}
              alt={`${label} preview`}
              className="w-full h-40 object-cover rounded-xl"
            />
            {/* Status overlay */}
            <div className="absolute inset-0 rounded-xl bg-black/30 flex flex-col items-center justify-center">
              {status === "uploading" && (
                <>
                  <Loader2 className="h-8 w-8 text-white animate-spin" />
                  <p className="text-white text-xs mt-2 font-semibold">
                    Uploading… {progress}%
                  </p>
                </>
              )}
              {status === "success" && qualityPassed && (
                <CheckCircle2 className="h-10 w-10 text-emerald-400" />
              )}
              {(status === "error" || qualityPassed === false) && (
                <XCircle className="h-10 w-10 text-rose-400" />
              )}
            </div>
            {status !== "uploading" && (
              <span className="absolute right-2 top-2 inline-flex items-center gap-1 rounded-md bg-slate-950/75 px-2 py-1 text-[10px] font-semibold text-white">
                <RotateCcw className="h-3 w-3" /> Replace
              </span>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-10 px-4 text-center">
            <UploadCloud className="h-8 w-8 text-slate-400 mb-2" />
            <p className="text-xs font-medium text-slate-600">
              Drop image here
            </p>
            <p className="text-[11px] text-slate-400 mt-0.5">
              JPEG / PNG — max 10 MB
            </p>
          </div>
        )}
      </div>

      {/* Quality gate result */}
      {qualityResult && (
        <div
          className={`rounded-lg border px-3 py-2 text-[11px] space-y-0.5 ${
            qualityPassed
              ? "border-emerald-200 bg-emerald-50 text-emerald-700"
              : "border-rose-200 bg-rose-50 text-rose-700"
          }`}
        >
          <div className="flex items-center gap-1.5 font-semibold">
            {qualityPassed ? (
              <CheckCircle2 className="h-3.5 w-3.5" />
            ) : (
              <XCircle className="h-3.5 w-3.5" />
            )}
            Quality Gate:{" "}
            {qualityPassed ? "Passed" : "Failed"}
            {qualityResult.quality_score !== undefined && (
              <span className="ml-auto font-mono">
                Score: {(qualityResult.quality_score * 100).toFixed(0)}%
              </span>
            )}
          </div>
          {qualityResult.quality_issues?.issues?.map((issue, i) => (
            <p key={i} className="pl-5 text-rose-600">
              • {issue}
            </p>
          ))}
        </div>
      )}

      {/* Error message */}
      {errorMsg && (
        <p className="text-[11px] text-rose-600 font-medium">{errorMsg}</p>
      )}
    </div>
  );
};
