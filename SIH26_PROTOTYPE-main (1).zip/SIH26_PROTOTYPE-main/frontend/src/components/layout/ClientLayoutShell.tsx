"use client";

/**
 * ClientLayoutShell — conditionally renders the navigation chrome.
 * On /login and /register routes the full-screen layout is used.
 * All other routes get the Header + Sidebar app shell.
 */

import React, { useState, useEffect } from "react";
import { usePathname, useRouter } from "next/navigation";
import { Header } from "@/components/layout/Header";
import { Sidebar } from "@/components/layout/Sidebar";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/contexts/AuthContext";

const NO_SHELL_ROUTES = ["/login", "/register"];

export function ClientLayoutShell({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const { isAuthenticated, isLoading } = useAuth();
  const [isNavigationOpen, setIsNavigationOpen] = useState(false);
  const isShellless = NO_SHELL_ROUTES.some((r) => pathname?.startsWith(r));

  useEffect(() => {
    if (!isLoading && !isAuthenticated && !isShellless) {
      router.push("/login");
    }
  }, [isLoading, isAuthenticated, isShellless, router]);

  if (isLoading && !isShellless) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-slate-500 font-medium animate-pulse">Authenticating...</div>
      </div>
    );
  }

  if (!isAuthenticated && !isShellless) {
    return null;
  }

  if (isShellless) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        {children}
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Header onMenuClick={() => setIsNavigationOpen(true)} />
      <div className="flex flex-1">
        <Sidebar isOpen={isNavigationOpen} onClose={() => setIsNavigationOpen(false)} />
        <main className="min-w-0 flex-1 p-4 sm:p-6 xl:p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={pathname}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="h-full"
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
