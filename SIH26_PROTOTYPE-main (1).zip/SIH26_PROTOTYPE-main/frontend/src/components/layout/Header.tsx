"use client";

import Link from "next/link";
import { Bell, Menu, ShieldCheck } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

const ROLE_LABELS: Record<string, string> = {
  Officer: "Enforcement officer",
  Reviewer: "Senior reviewer",
  DeptAdmin: "Department administrator",
  SysAdmin: "System administrator",
};

export function Header({ onMenuClick }: { onMenuClick?: () => void }) {
  const { user } = useAuth();

  return (
    <header className="sticky top-0 z-40 h-16 border-b border-slate-800 bg-[#071214] px-4 text-white sm:px-6">
      <div className="mx-auto flex h-full max-w-[1600px] items-center justify-between gap-4">
        <div className="flex min-w-0 items-center gap-3">
          <button type="button" onClick={onMenuClick} aria-label="Open navigation" className="rounded-lg p-2 text-slate-300 hover:bg-white/10 lg:hidden">
            <Menu className="h-5 w-5" />
          </button>
          <Link href="/" className="flex items-center gap-3" aria-label="NeuraCheck home">
            <img src="/brand/neuracheck-logo.jpeg" alt="NeuraCheck" className="h-12 w-12 rounded-lg object-contain" />
            <div className="hidden sm:block">
              <p className="text-sm font-bold tracking-wide">NeuraCheck</p>
              <p className="text-[10px] text-slate-400">Packaged commodity compliance</p>
            </div>
          </Link>
        </div>
        <div className="flex items-center gap-2 sm:gap-3">
          <div className="hidden items-center gap-2 rounded-full border border-teal-800 bg-teal-950/60 px-3 py-1.5 text-[11px] font-semibold text-teal-100 md:flex">
            <ShieldCheck className="h-3.5 w-3.5 text-teal-300" /> PC Rules 2011
          </div>
          <button type="button" aria-label="Notifications" className="rounded-lg p-2 text-slate-300 hover:bg-white/10 hover:text-white"><Bell className="h-4 w-4" /></button>
          <div className="flex items-center gap-2 border-l border-slate-700 pl-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-teal-600 text-xs font-bold">{user ? user.username.slice(0, 2).toUpperCase() : "NC"}</div>
            <div className="hidden text-left sm:block">
              <p className="max-w-28 truncate text-xs font-semibold">{user?.username ?? "Inspector workspace"}</p>
              <p className="text-[10px] text-slate-400">{user ? ROLE_LABELS[user.role] ?? user.role : "Secure workspace"}</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
