"use client";

import React from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Upload,
  Cpu,
  FileText,
  Search,
  Scale,
  ClipboardCheck,
  FileBarChart,
  CheckCircle2,
} from "lucide-react";
import clsx from "clsx";

interface Step {
  key: string;
  label: string;
  sublabel: string;
  icon: React.ReactNode;
  href: (id: string) => string;
  matchSegments: string[];
}

const STEPS: Step[] = [
  {
    key: "upload",
    label: "Upload",
    sublabel: "Evidence",
    icon: <Upload className="w-3.5 h-3.5" />,
    href: (id) => `/inspections/${id}/upload`,
    matchSegments: ["upload"],
  },
  {
    key: "progress",
    label: "Analysis",
    sublabel: "Pipeline",
    icon: <Cpu className="w-3.5 h-3.5" />,
    href: (id) => `/inspections/${id}/progress`,
    matchSegments: ["progress"],
  },
  {
    key: "declarations",
    label: "Declarations",
    sublabel: "OCR Output",
    icon: <FileText className="w-3.5 h-3.5" />,
    href: (id) => `/inspections/${id}/declarations`,
    matchSegments: ["declarations"],
  },
  {
    key: "evidence",
    label: "Evidence",
    sublabel: "Bounding Boxes",
    icon: <Search className="w-3.5 h-3.5" />,
    href: (id) => `/inspections/${id}/evidence`,
    matchSegments: ["evidence"],
  },
  {
    key: "compliance",
    label: "Compliance",
    sublabel: "Rule Engine",
    icon: <Scale className="w-3.5 h-3.5" />,
    href: (id) => `/inspections/${id}/compliance`,
    matchSegments: ["compliance"],
  },
  {
    key: "review",
    label: "Review",
    sublabel: "Officer Sign-off",
    icon: <ClipboardCheck className="w-3.5 h-3.5" />,
    href: (id) => `/inspections/${id}/review`,
    matchSegments: ["review"],
  },
  {
    key: "report",
    label: "Report",
    sublabel: "Certificate",
    icon: <FileBarChart className="w-3.5 h-3.5" />,
    href: (id) => `/inspections/${id}/report`,
    matchSegments: ["report"],
  },
];

interface InspectionStepperProps {
  inspectionId: string;
  completedSteps?: string[];
}

export const InspectionStepper: React.FC<InspectionStepperProps> = ({
  inspectionId,
  completedSteps = [],
}) => {
  const pathname = usePathname();

  const getCurrentStepIndex = () => {
    for (let i = 0; i < STEPS.length; i++) {
      if (STEPS[i].matchSegments.some((seg) => pathname.endsWith(seg))) {
        return i;
      }
    }
    return -1;
  };

  const currentIdx = getCurrentStepIndex();

  const getStepState = (stepIdx: number): "done" | "active" | "pending" => {
    const stepKey = STEPS[stepIdx].key;
    if (completedSteps.includes(stepKey)) return "done";
    if (stepIdx < currentIdx) return "done";
    if (stepIdx === currentIdx) return "active";
    return "pending";
  };

  return (
    <div className="w-full bg-white border border-slate-200/80 rounded-2xl px-5 py-3.5 shadow-sm">
      <div className="flex items-center justify-between gap-1 overflow-x-auto">
        {STEPS.map((step, idx) => {
          const state = getStepState(idx);
          const isLast = idx === STEPS.length - 1;

          return (
            <React.Fragment key={step.key}>
              {/* Step node */}
              <Link
                href={step.href(inspectionId)}
                className={clsx(
                  "flex flex-col items-center gap-1 min-w-[52px] group transition-opacity",
                  state === "pending" && "opacity-45 pointer-events-none"
                )}
              >
                {/* Icon circle */}
                <div
                  className={clsx(
                    "w-8 h-8 rounded-xl flex items-center justify-center transition-all duration-200 shrink-0",
                    state === "done" &&
                      "bg-emerald-100 text-emerald-700 group-hover:bg-emerald-200",
                    state === "active" &&
                      "gradient-brand text-white shadow-lg shadow-indigo-500/30 animate-glow-pulse",
                    state === "pending" &&
                      "bg-slate-100 text-slate-400"
                  )}
                >
                  {state === "done" ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    step.icon
                  )}
                </div>

                {/* Label */}
                <div className="text-center">
                  <p
                    className={clsx(
                      "text-[10px] font-bold leading-none whitespace-nowrap",
                      state === "done" && "text-emerald-700",
                      state === "active" && "text-indigo-700",
                      state === "pending" && "text-slate-400"
                    )}
                  >
                    {step.label}
                  </p>
                  <p className="text-[9px] text-slate-400 whitespace-nowrap hidden sm:block mt-0.5">
                    {step.sublabel}
                  </p>
                </div>
              </Link>

              {/* Connector */}
              {!isLast && (
                <div
                  className={clsx(
                    "stepper-connector flex-1 mx-1",
                    getStepState(idx) === "done" && "stepper-connector-active",
                    getStepState(idx) === "active" && "stepper-connector-progress"
                  )}
                />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};
