"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { BookOpen, FileSearch, History, LayoutDashboard, LogOut, PlusCircle, Scale, Users, X, HelpCircle } from "lucide-react";
import clsx from "clsx";
import { useAuth } from "@/contexts/AuthContext";

const NAV_ITEMS = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard, roles: null },
  { label: "Scan product", href: "/inspections/new", icon: PlusCircle, roles: null },
  { label: "Scan history", href: "/inspections", icon: FileSearch, roles: null },
  { label: "FAQ & About", href: "/faq", icon: HelpCircle, roles: null },
  { label: "Rule management", href: "/admin/rules", icon: BookOpen, roles: ["Reviewer", "DeptAdmin", "SysAdmin"] },
  { label: "User management", href: "/admin/users", icon: Users, roles: ["DeptAdmin", "SysAdmin"] },
  { label: "Audit logs", href: "/admin/audit", icon: History, roles: ["Reviewer", "DeptAdmin", "SysAdmin"] },
];

export function Sidebar({ isOpen = false, onClose }: { isOpen?: boolean; onClose?: () => void }) {
  const pathname = usePathname();
  const { user, logout } = useAuth();
  const items = NAV_ITEMS.filter((item) => !item.roles || (user && item.roles.includes(user.role)));

  return (
    <>
      {isOpen && <button type="button" aria-label="Close navigation" onClick={onClose} className="fixed inset-0 z-40 bg-slate-950/45 lg:hidden" />}
      <aside className={clsx("fixed inset-y-0 left-0 z-50 flex h-screen w-72 flex-col justify-between bg-[#0a1c1e] p-4 text-white transition-transform lg:sticky lg:top-16 lg:h-[calc(100vh-4rem)] lg:w-64 lg:translate-x-0", isOpen ? "translate-x-0" : "-translate-x-full")}>
        <div>
          <div className="mb-4 flex items-center justify-between lg:hidden"><span className="text-xs font-bold uppercase tracking-[.16em] text-slate-400">Navigation</span><button type="button" aria-label="Close navigation" onClick={onClose} className="rounded-lg p-2 text-slate-300 hover:bg-white/10"><X className="h-4 w-4" /></button></div>
          <p className="px-3 pb-2 text-[10px] font-bold uppercase tracking-[.16em] text-slate-400">Inspection workspace</p>
          <nav className="space-y-1" aria-label="Main navigation">
            {items.map((item) => {
              const active = pathname === item.href || (item.href === "/inspections" && pathname?.startsWith("/inspections/") && !pathname.startsWith("/inspections/new"));
              return <Link key={item.href} href={item.href} onClick={onClose} className={clsx("flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition", active ? "bg-teal-500/15 text-white ring-1 ring-inset ring-teal-400/20" : "text-slate-400 hover:bg-white/5 hover:text-slate-100")}>
                <item.icon className={clsx("h-4 w-4", active ? "text-teal-300" : "text-slate-500")} />{item.label}{active && <span className="ml-auto h-1.5 w-1.5 rounded-full bg-teal-300" />}
              </Link>;
            })}
          </nav>
        </div>
        <div className="space-y-3">
          <div className="rounded-xl border border-white/10 bg-white/5 p-3 text-xs text-slate-300"><div className="mb-1 flex items-center gap-1.5 font-semibold text-white"><Scale className="h-4 w-4 text-teal-300" /> Deterministic rule engine</div>PC Rules 2011 · version 1.0</div>
          {user && <div className="rounded-xl border border-white/10 bg-white/5 p-3"><div className="mb-2 flex items-center gap-2"><div className="flex h-8 w-8 items-center justify-center rounded-full bg-teal-500/20 text-xs font-bold text-teal-200">{user.username.slice(0, 2).toUpperCase()}</div><div className="min-w-0"><p className="truncate text-xs font-semibold text-slate-100">{user.username}</p><p className="text-[10px] text-slate-400">{user.role}</p></div></div><button id="sidebar-logout-btn" onClick={logout} className="flex w-full items-center gap-1.5 rounded-lg px-2 py-1.5 text-xs font-semibold text-rose-300 hover:bg-rose-500/10"><LogOut className="h-3.5 w-3.5" /> Sign out</button></div>}
        </div>
      </aside>
    </>
  );
}
