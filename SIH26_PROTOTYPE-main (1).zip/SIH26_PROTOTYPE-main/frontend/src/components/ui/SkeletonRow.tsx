import React from "react";

interface SkeletonRowProps {
  cols?: number;
}

export const SkeletonRow: React.FC<SkeletonRowProps> = ({ cols = 6 }) => (
  <tr className="animate-pulse">
    {Array.from({ length: cols }).map((_, i) => (
      <td key={i} className="px-4 py-3">
        <div className="h-3 bg-slate-200 rounded w-3/4" />
      </td>
    ))}
  </tr>
);

interface SkeletonCardProps {
  className?: string;
}

export const SkeletonCard: React.FC<SkeletonCardProps> = ({ className = "" }) => (
  <div className={`animate-pulse rounded-xl border border-slate-200 bg-white p-5 shadow-sm ${className}`}>
    <div className="h-3 bg-slate-200 rounded w-1/2 mb-3" />
    <div className="h-8 bg-slate-200 rounded w-1/4" />
  </div>
);
