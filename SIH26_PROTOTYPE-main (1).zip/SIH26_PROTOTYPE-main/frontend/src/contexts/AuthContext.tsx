"use client";

/**
 * AuthContext — global authentication state for SLM-CIP.
 *
 * Provides:
 *   - user: decoded JWT claims (username, role, id)
 *   - isAuthenticated: boolean
 *   - login(username, password): calls POST /auth/login, stores tokens
 *   - logout(): clears tokens and redirects to /login
 *   - isLoading: true while restoring session from localStorage on mount
 */

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import { useRouter } from "next/navigation";
import { loginUser, logoutUser } from "@/lib/api";
import { decodeJwtPayload, tokenStorage, type JwtClaims } from "@/lib/authUtils";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface AuthUser {
  id: string;
  username: string;
  role: "Officer" | "Reviewer" | "DeptAdmin" | "SysAdmin";
  department_id?: string;
}

interface AuthContextValue {
  user: AuthUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  loginError: string | null;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
}

// ─── Context ──────────────────────────────────────────────────────────────────

const AuthContext = createContext<AuthContextValue>({
  user: null,
  isAuthenticated: false,
  isLoading: true,
  loginError: null,
  login: async () => {},
  logout: () => {},
});

// ─── Provider ─────────────────────────────────────────────────────────────────

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [loginError, setLoginError] = useState<string | null>(null);

  // On mount: attempt to restore session from localStorage
  useEffect(() => {
    const token = tokenStorage.getAccess();
    if (token) {
      const claims = decodeJwtPayload(token);
      if (claims && claims.exp && claims.exp * 1000 > Date.now()) {
        setUser({
          id: claims.sub,
          username: claims.username,
          role: claims.role,
          department_id: claims.department_id,
        });
      } else {
        // Token expired — clear stale data
        tokenStorage.clear();
      }
    }
    setIsLoading(false);
  }, []);

  const login = useCallback(
    async (username: string, password: string) => {
      setLoginError(null);
      try {
        const tokens = await loginUser(username, password);
        tokenStorage.set(tokens.access_token, tokens.refresh_token);

        const claims: JwtClaims | null = decodeJwtPayload(tokens.access_token);
        if (!claims) throw new Error("Malformed token received.");

        setUser({
          id: claims.sub,
          username: claims.username,
          role: claims.role,
          department_id: claims.department_id,
        });
        router.push("/dashboard");
      } catch (err: unknown) {
        // Extract backend error detail
        const axiosErr = err as {
          response?: { data?: { detail?: string } };
          message?: string;
        };
        const detail =
          axiosErr?.response?.data?.detail ??
          axiosErr?.message ??
          "Authentication failed. Please check your credentials.";
        setLoginError(detail);
      }
    },
    [router]
  );

  const logout = useCallback(async () => {
    try {
      await logoutUser();
    } catch (e) {
      console.error("Logout API failed", e);
    }
    tokenStorage.clear();
    setUser(null);
    router.push("/login");
  }, [router]);

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: user !== null,
        isLoading,
        loginError,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useAuth(): AuthContextValue {
  return useContext(AuthContext);
}
