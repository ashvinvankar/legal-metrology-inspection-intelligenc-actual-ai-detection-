export type ComplianceState =
  | "COMPLIANT"
  | "NON_COMPLIANT"
  | "NEEDS_REVIEW"
  | "NOT_APPLICABLE";

export type RuleSeverity = "Critical" | "Major" | "Minor";

export interface User {
  id: string;
  username: string;
  email: string;
  role: "Officer" | "Reviewer" | "DeptAdmin" | "SysAdmin";
}

export interface Inspection {
  id: string;
  product_id?: string;
  product_name?: string;
  category: string;
  location?: string;
  officer_id: string;
  reviewer_id?: string;
  status: "draft" | "analyzing" | "needs_review" | "completed" | "reported";
  overall_result?: ComplianceState;
  inspection_date: string;
  created_at: string;
  updated_at?: string;
}

// Payload for POST /inspections
export interface InspectionCreatePayload {
  product_name?: string;
  category?: string;
  location?: string;
}

export interface ProductImage {
  id: string;
  inspection_id: string;
  image_type: "front" | "back" | "side" | "label" | "ecommerce";
  original_uri: string;
  processed_uri?: string;
  quality_score?: number;
  quality_issues?: {
    passed: boolean;
    issues: string[];
  };
  created_at: string;
}

// Matches backend ImageUploadResponse schema
export interface ImageUploadResponse {
  id: string;
  inspection_id: string;
  image_type: "front" | "back" | "side" | "label" | "ecommerce";
  original_uri: string;
  quality_score?: number;
  quality_issues?: {
    passed: boolean;
    issues: string[];
  };
  created_at: string;
}

export interface ExtractedField {
  id: string;
  field_name: string;
  raw_value: string;
  normalized_value?: Record<string, unknown>;
  confidence: number;
  officer_confirmed: boolean;
  officer_corrected_value?: Record<string, unknown>;
  bbox?: [number, number, number, number];
}

// Matches backend EvidenceDTO
export interface EvidenceItem {
  id: string;
  image_id?: string;
  region_id?: string;
  ocr_result_id?: string;
  cropped_image_uri?: string;
}

// Matches backend ViolationDTO
export interface ViolationItem {
  id: string;
  severity: string;
  description: string;
}

// Matches backend ComplianceCheckDTO
export interface ComplianceFindingAPI {
  id: string;
  inspection_id: string;
  rule_version_id: string;
  rule_key?: string;
  requirement?: string;
  legal_reference?: string;
  input_fields?: string[];
  result: ComplianceState;
  confidence?: number;
  system_generated: boolean;
  officer_decision?: "confirmed" | "overridden";
  override_justification?: string;
  violations: ViolationItem[];
  evidence_items: EvidenceItem[];
  created_at: string;
}

// Kept for backward compatibility with existing components
export interface ComplianceFinding {
  id: string;
  rule_id: string;
  rule_key: string;
  legal_reference: string;
  requirement: string;
  severity: RuleSeverity;
  result: ComplianceState;
  confidence?: number;
  system_generated: boolean;
  officer_decision?: "confirmed" | "overridden";
  override_justification?: string;
  explanation: string;
  evidence_thumbnail_url?: string;
}

export interface DashboardSummaryMetrics {
  total_inspections: number;
  compliant_count: number;
  non_compliant_count: number;
  needs_review_count: number;
  draft_count: number;
}

// Matches backend ViolationCategoryBreakdown
export interface DashboardViolation {
  category_name: string;
  rule_key: string;
  violation_count: number;
  percentage: number;
}

// Response from PATCH /compliance/{id}/review
export interface OfficerReviewResponse {
  compliance_check_id: string;
  decision: "confirmed" | "overridden";
  justification?: string;
  reviewed_by: string;
  status: string;
}

// ─── Dashboard Trends (GET /dashboard/trends) ─────────────────────────────────

export interface DailyDataPoint {
  date: string;                 // ISO date string e.g. "2026-09-15"
  inspection_count: number;
  compliant_count: number;
  non_compliant_count: number;
}

export interface DashboardTrendsResponse {
  days: number;
  daily_data: DailyDataPoint[];
}

// ─── Celery Task Result ───────────────────────────────────────────────────────

export interface AnalysisTaskResponse {
  inspection_id: string;
  task_id: string;
  status: "QUEUED" | "STARTED" | "SUCCESS" | "FAILURE";
}

// ─── Analysis Task Status (GET /inspections/{id}/analysis) ────────────────────

export interface AnalysisStatusResponse {
  inspection_id: string;
  task_id: string;
  status: "queued" | "running" | "completed" | "failed";
  stage: string;
  progress_percent: number;
  attempt?: number;
  error_message?: string;
  completed: boolean;
}

// ─── Evidence & OCR Detail Types (GET /inspections/{id}/evidence) ──────────────

export interface OCRResultDTO {
  id: string;
  region_id: string;
  text: string;
  confidence: number;
  bbox: [number, number, number, number];
  language?: string;
}

export interface DetectedRegionDTO {
  id: string;
  image_id: string;
  region_type: string;
  bbox: [number, number, number, number];
  confidence: number;
  model_version?: string;
}

export interface RegionEvidenceItem {
  region: DetectedRegionDTO;
  ocr_spans: OCRResultDTO[];
  crop_uri?: string;
}

export interface EvidenceDetailResponse {
  inspection_id: string;
  image_id: string;
  image_uri: string;
  image_type: "front" | "back" | "side" | "label" | "ecommerce";
  quality_score?: number;
  regions: RegionEvidenceItem[];
}

// ─── AI Copilot Types (POST /inspections/{id}/copilot) ─────────────────────────

export interface CopilotResponse {
  answer: string;
  source: string;
  rule_references: string[];
}

export interface CopilotChatMessage {
  id: string;
  sender: "user" | "copilot";
  text: string;
  timestamp: string;
  references?: string[];
}

export interface GeneratedReport {
  id: string;
  inspection_id: string;
  report_type: string;
  pdf_uri?: string;
  docx_uri?: string;
  qr_reference: string;
  generated_at: string;
}
