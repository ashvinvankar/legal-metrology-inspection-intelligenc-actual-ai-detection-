import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        compliant: {
          light: "#ecfdf5",
          DEFAULT: "#10b981",
          dark: "#047857",
        },
        non_compliant: {
          light: "#fff1f2",
          DEFAULT: "#f43f5e",
          dark: "#be123c",
        },
        needs_review: {
          light: "#fffbeb",
          DEFAULT: "#f59e0b",
          dark: "#b45309",
        },
        not_applicable: {
          light: "#f8fafc",
          DEFAULT: "#94a3b8",
          dark: "#475569",
        },
      },
    },
  },
  plugins: [],
};
export default config;
