"""Database Initialization Script. Creates all tables defined in models."""

import sys
from pathlib import Path

# Add backend directory to sys.path
sys.path.append(str(Path(__file__).resolve().parents[1] / "backend"))

from app.core.database import Base, sync_engine
import app.models  # load all models into Base.metadata


def init_db():
    print("Creating all tables in database...")
    try:
        Base.metadata.create_all(bind=sync_engine)
        print("Database schema successfully created!")
    except Exception as e:
        print(f"Error initializing database: {e}")
        print("Note: Ensure PostgreSQL is running or run via Docker Compose.")


if __name__ == "__main__":
    init_db()
