"""Seed script to populate initial roles, admin user, and Legal Metrology rules."""

import json
import sys
import uuid
from pathlib import Path

# Add backend directory to sys.path
sys.path.append(str(Path(__file__).resolve().parents[1] / "backend"))

from app.core.database import SyncSessionLocal
from app.core.security import get_password_hash
from app.models.user import Role, User
from app.models.rule import Rule, RuleVersion


def seed():
    print("Seeding initial database fixtures...")
    session = SyncSessionLocal()
    try:
        # 1. Seed Roles
        roles_data = [
            ("Officer", "Enforcement field and desk inspection officer"),
            ("Reviewer", "Senior reviewing officer with escalation approval authority"),
            ("DeptAdmin", "Department administrator managing department officers & rules"),
            ("SysAdmin", "System administrator managing platform, rules, and global configuration"),
        ]

        roles_map = {}
        for r_name, r_desc in roles_data:
            existing = session.query(Role).filter_by(name=r_name).first()
            if not existing:
                new_role = Role(id=uuid.uuid4(), name=r_name, description=r_desc)
                session.add(new_role)
                session.flush()
                roles_map[r_name] = new_role
            else:
                roles_map[r_name] = existing

        # 2. Seed Default Admin User
        admin_user = session.query(User).filter_by(username="admin").first()
        if not admin_user:
            admin_user = User(
                id=uuid.uuid4(),
                username="admin",
                email="admin@legalmetrology.gov.in",
                password_hash=get_password_hash("Admin@12345"),
                role_id=roles_map["SysAdmin"].id,
                status="active"
            )
            session.add(admin_user)
            print("Created default admin user: admin / Admin@12345")

        # 3. Seed Seed Rules from rules/pc_rules_2011_v1.json
        rules_path = Path(__file__).resolve().parents[1] / "rules" / "pc_rules_2011_v1.json"
        if rules_path.exists():
            with open(rules_path, "r", encoding="utf-8") as f:
                rules_json = json.load(f)

            for item in rules_json:
                existing_rule = session.query(Rule).filter_by(rule_key=item["rule_key"]).first()
                if not existing_rule:
                    rule = Rule(
                        id=uuid.uuid4(),
                        rule_key=item["rule_key"],
                        legal_reference=item["legal_reference"],
                        requirement=item["requirement"],
                        severity=item["severity"],
                        source_document=item.get("source_document"),
                        created_by=admin_user.id
                    )
                    session.add(rule)
                    session.flush()

                    version = RuleVersion(
                        id=uuid.uuid4(),
                        rule_id=rule.id,
                        version=item.get("version", 1),
                        applicability_conditions=item["applicability_conditions"],
                        input_fields=item["input_fields"],
                        validation_logic=item["validation_logic"],
                        evidence_requirements=item["evidence_requirements"],
                        explanation_template=item["explanation_template"],
                        status="published",
                        published_by=admin_user.id
                    )
                    session.add(version)
            print(f"Seeded {len(rules_json)} Legal Metrology (PC Rules 2011) rules.")

        session.commit()
        print("Database seeding completed successfully!")
    except Exception as e:
        session.rollback()
        print(f"Error seeding database: {e}")
    finally:
        session.close()


if __name__ == "__main__":
    seed()
