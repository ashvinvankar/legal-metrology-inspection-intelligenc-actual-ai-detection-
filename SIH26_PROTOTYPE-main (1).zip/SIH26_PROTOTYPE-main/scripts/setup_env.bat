@echo off
REM ==============================================================================
REM SLM-CIP Platform - Windows Environment Setup Runner
REM ==============================================================================

echo [1/3] Setting up Python virtual environment...
if not exist "venv" (
    python -m venv venv
)
call venv\Scripts\activate.bat

echo [2/3] Installing backend dependencies...
python -m pip install --upgrade pip
pip install -r backend\requirements.txt

echo [3/3] Setting up Frontend dependencies...
cd frontend
call npm install
cd ..

echo ==============================================================================
echo Environment setup completed!
echo To run backend:
echo    call venv\Scripts\activate
echo    uvicorn backend.app.main:app --reload --port 8000
echo To run frontend:
echo    cd frontend && npm run dev
echo ==============================================================================
pause
